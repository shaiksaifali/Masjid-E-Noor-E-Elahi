#!/usr/bin/env python3
"""Build the two Drive update files from this repository.

    python3 tools/make-bundles.py

Creates  dist/masjid-committee-app.json  and  dist/masjid-website.json.
Upload both to Google Drive, then run  updateEverything  in the committee app's Apps Script editor.
"""
import json, os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VERSION = re.search(r"VERSION: '([\d.]+)'", open(os.path.join(ROOT, 'committee-app', 'Config.gs'), encoding='utf-8').read()).group(1)

def bundle(folder, kind):
    files = []
    d = os.path.join(ROOT, folder)
    for f in sorted(os.listdir(d)):
        src = open(os.path.join(d, f), encoding='utf-8').read() if f.endswith(('.gs', '.html', '.json')) else None
        if f.endswith('.gs'): files.append({'name': f[:-3], 'type': 'SERVER_JS', 'source': src})
        elif f.endswith('.html'): files.append({'name': f[:-5], 'type': 'HTML', 'source': src})
        elif f == 'appsscript.json': files.append({'name': 'appsscript', 'type': 'JSON', 'source': src})
    return {'kind': kind, 'version': VERSION, 'files': files}

os.makedirs(os.path.join(ROOT, 'dist'), exist_ok=True)
for folder, kind, out in [('committee-app', 'committee', 'masjid-committee-app.json'), ('community-website', 'website', 'masjid-website.json')]:
    b = bundle(folder, kind)
    with open(os.path.join(ROOT, 'dist', out), 'w', encoding='utf-8') as fh:
        json.dump(b, fh, ensure_ascii=False)
    print(f'dist/{out}: {len(b["files"])} files, v{VERSION}')
