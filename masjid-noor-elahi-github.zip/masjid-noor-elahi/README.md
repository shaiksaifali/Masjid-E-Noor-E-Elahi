# Masjid-E-Noor-Elahi — Masjid Management System

A **zero-cost** system for Masjid-E-Noor-Elahi, built only on free Google services
(Apps Script, Sheets, Drive, Calendar). Developed by **Arhaan Agencies**.

> ⚠️ **Keep this repository PRIVATE.** It contains no passwords or data, but there is no reason
> to publish how the masjid's accounts system works.

## What is in here

| Folder | What it is | Apps Script project |
|---|---|---|
| `committee-app/` | Management system (ERP): receipts, membership, expenses, approvals, Zakat & funds, reports, users, audit log, backups, community admin, **Updater** | the committee app project |
| `community-website/` | Public website: prayer & jamaat times, Ramadan, Quran, Hadith & Sunnah, daily duas, Wudu & Salah guide, Dawat, events, janazah, donate, requests (English + Arabic) | the project bound to the **Public Website Data** sheet |
| `tests/` | Automated tests that run on a computer with Node.js (`node tests/run.js committee-app`) | — |
| `tools/make-bundles.py` | Builds the two Drive update files from this code | — |
| `docs/` | Setup guide and security audit | — |

**Your data is never in this repository.** It lives only in your Google Sheets and Google Drive.

## How the live system is updated

GitHub is only the **safe copy and history** of the code. GitHub does not run anything.

1. Get the two update files (`masjid-committee-app.json`, `masjid-website.json`), from Claude or by running `tools/make-bundles.py`.
2. Upload both to **Google Drive** (any folder).
3. Open the **committee app** project at script.google.com, choose **updateEverything**, then click **Run**.
   This replaces the code in both projects and moves the existing web links to the new version. The URLs stay the same.

One-time setup for the Updater:
- Turn on **Google Apps Script API**: https://script.google.com/home/usersettings
- In the committee project, go to **Project Settings › Script properties** and add `WEBSITE_SCRIPT_ID` = the website project's Script ID.

## Keeping this repository up to date (browser only, no installs)

After each new version:
1. Open the repository on github.com.
2. Click **Add file › Upload files**.
3. Drag the folders `committee-app`, `community-website`, `tests`, `tools` and `docs` from the new version into the page.
   Files with the same name are replaced.
4. Write a short message, such as `v1.4.2 – Hadith library`, and click **Commit changes**.

To see what changed between versions, open **Commits**. To get an older file back, open it and click **History**.

## Versions

See `VERSION` in `committee-app/Config.gs`. The current version is in the commit history.

## Security notes

- Never upload exported Sheets, backups, receipts, member lists or screenshots containing real data.
- The committee app refuses to be shown inside other websites, and the Updater only runs for the owner.
- See `docs/SECURITY-AUDIT.md`.
