/**
 * Setup.gs — one-time installation. Run setup() from the Apps Script editor (owner only).
 * Safe to run again: it only adds what is missing (sheets, columns, defaults, triggers).
 */

function setup() {
  assertOwner_();
  var p = props_();
  var lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    // 1. Private Drive folder tree
    var root = null, rootId = p.getProperty('ROOT_FOLDER_ID');
    if (rootId) { try { root = DriveApp.getFolderById(rootId); } catch (e) { root = null; } }
    if (!root) {
      root = DriveApp.createFolder('Masjid-E-Noor-Elahi — Accounts (Private)');
      p.setProperty('ROOT_FOLDER_ID', root.getId());
    }
    Object.keys(FOLDERS).forEach(function (k) {
      var id = p.getProperty('FOLDER_' + k), f = null;
      if (id) { try { f = DriveApp.getFolderById(id); } catch (e) { f = null; } }
      if (!f) { f = root.createFolder(FOLDERS[k]); p.setProperty('FOLDER_' + k, f.getId()); }
    });

    // 2. Database spreadsheet
    var ss = null, ssId = p.getProperty('SPREADSHEET_ID');
    if (ssId) { try { ss = SpreadsheetApp.openById(ssId); } catch (e) { ss = null; } }
    if (!ss) {
      ss = SpreadsheetApp.create('Masjid-E-Noor-Elahi — Database (Private)');
      DriveApp.getFileById(ss.getId()).moveTo(root);
      p.setProperty('SPREADSHEET_ID', ss.getId());
    }
    ss.setSpreadsheetTimeZone(tz_());
    _memo.ss = ss;

    // 3. Sheets + columns (adds missing columns at the end, never removes data)
    Object.keys(SH).forEach(function (k) { ensureSheet_(ss, SH[k]); });
    var def = ss.getSheetByName('Sheet1');
    if (def && ss.getSheets().length > 1 && def.getLastRow() === 0) ss.deleteSheet(def);

    // 4. Default masters
    seedDefaults_();

    // 4b. Public website data sheet (the ONLY file the public website can open)
    var pub = null, pubId = p.getProperty('PUBLIC_SS_ID');
    if (pubId) { try { pub = SpreadsheetApp.openById(pubId); } catch (e) { pub = null; } }
    if (!pub) {
      pub = SpreadsheetApp.create('Masjid-E-Noor-Elahi — Public Website Data');
      DriveApp.getFileById(pub.getId()).moveTo(DriveApp.getFolderById(p.getProperty('FOLDER_COMMUNITY')));
      p.setProperty('PUBLIC_SS_ID', pub.getId());
    }
    var snapSh = pub.getSheetByName('Snapshot') || pub.insertSheet('Snapshot');
    snapSh.getRange(1, 1, snapSh.getMaxRows(), 2).setNumberFormat('@');
    var reqSh = pub.getSheetByName('Requests') || pub.insertSheet('Requests');
    reqSh.getRange(1, 1, 1, REQ_HEADERS.length).setValues([REQ_HEADERS]).setFontWeight('bold');
    reqSh.getRange(1, 1, reqSh.getMaxRows(), REQ_HEADERS.length).setNumberFormat('@');
    reqSh.setFrozenRows(1);
    var s1 = pub.getSheetByName('Sheet1'); if (s1 && pub.getSheets().length > 2) pub.deleteSheet(s1);

    // 5. First admin
    var msg = '';
    if (!read_(SH.USERS).length) {
      var email = String(Session.getEffectiveUser().getEmail()).toLowerCase();
      var temp = genPassword_(), salt = newSalt_();
      append_(SH.USERS, [{ UserID: newId_('USR'), Email: email, Name: 'Administrator', Role: 'ADMIN', Salt: salt,
        PasswordHash: hashPw_(temp, salt), Status: 'Active', MustChangePassword: 'YES', FailedAttempts: 0,
        CreatedAt: nowStr_(), CreatedBy: 'setup' }]);
      msg = '\n\nFIRST LOGIN\n  Email:    ' + email + '\n  Password: ' + temp + '\n  (You will be asked to change it.)';
    }

    // 6. Free time-driven triggers (daily backup, monthly dues)
    installTriggers_();
    p.setProperty('SCHEMA_VERSION', APP.SCHEMA_VERSION);
    try { publishPublic_({ now: nowStr_(), audit: [], user: { Email: 'setup', Role: 'ADMIN' } }); } catch (e) { Logger.log('Publish skipped: ' + e); }
    CacheService.getScriptCache().removeAll(CACHED_TABLES.map(function (n) { return 'TBL_' + n; }));

    var out = 'Setup complete.\nDatabase: ' + ss.getUrl() + '\nPrivate folder: ' + root.getUrl() + msg +
      '\n\nNEXT: Deploy > New deployment > Web app > Execute as: Me, Who has access: Anyone with Google account.' +
      '\n\nCOMMUNITY WEBSITE: open ' + pub.getUrl() + ' > Extensions > Apps Script, paste the files from the "community" folder, then Deploy > Web app > Execute as: Me, Who has access: Anyone.';
    Logger.log(out);
    return out;
  } finally {
    SpreadsheetApp.flush();
    lock.releaseLock();
  }
}

function ensureSheet_(ss, name) {
  var cols = SCHEMA[name], sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    // keep the grid small to save the 10M-cell quota
    if (sh.getMaxColumns() > cols.length) sh.deleteColumns(cols.length + 1, sh.getMaxColumns() - cols.length);
    if (sh.getMaxRows() > 300) sh.deleteRows(301, sh.getMaxRows() - 300);
  }
  var lastCol = sh.getLastColumn();
  var existing = lastCol ? sh.getRange(1, 1, 1, lastCol).getValues()[0].map(String) : [];
  var missing = cols.filter(function (c) { return existing.indexOf(c) < 0; });
  if (missing.length) {
    var start = existing.length + 1;
    if (sh.getMaxColumns() < existing.length + missing.length) sh.insertColumnsAfter(sh.getMaxColumns(), existing.length + missing.length - sh.getMaxColumns());
    sh.getRange(1, start, 1, missing.length).setValues([missing]);
    existing = existing.concat(missing);
  }
  // Text format for every non-numeric column (stops formula injection + date auto-conversion)
  existing.forEach(function (h, i) {
    sh.getRange(1, i + 1, sh.getMaxRows(), 1).setNumberFormat(NUMERIC_COLS[h] ? '#,##0.00' : '@');
  });
  sh.getRange(1, 1, 1, existing.length).setFontWeight('bold').setBackground('#0f5132').setFontColor('#ffffff');
  sh.setFrozenRows(1);
  delete _memo.h[name];
  return sh;
}

function seedDefaults_() {
  var now = nowStr_();
  var have = {};
  read_(SH.SETTINGS).forEach(function (r) { have[r.Key] = 1; });
  var fyStart = (function () {
    var t = today_(), y = +t.slice(0, 4), m = +t.slice(5, 7);
    return (m >= 4 ? y : y - 1) + '-04-01';
  })();
  var addS = DEFAULT_SETTINGS.filter(function (d) { return !have[d[0]]; }).map(function (d) {
    return { Key: d[0], Value: d[0] === 'BOOKS_BEGIN_DATE' ? fyStart : d[1], Description: d[2], UpdatedAt: now, UpdatedBy: 'setup' };
  });
  append_(SH.SETTINGS, addS);

  if (!read_(SH.FUNDS).length) {
    append_(SH.FUNDS, DEFAULT_FUNDS.map(function (f) {
      return { FundID: f[0], Name: f[1], Type: f[2], RestrictSpending: f[3], Description: f[4], Status: 'Active', CreatedAt: now, CreatedBy: 'setup' };
    }));
  }
  if (!read_(SH.LEDGERS).length) {
    append_(SH.LEDGERS, DEFAULT_LEDGERS.map(function (l) {
      return { LedgerID: l[0], Name: l[1], Group: l[2], Nature: GROUPS[l[2]], FundID: l[3], OpeningBalance: 0, OpeningType: 'Dr',
        IsSystem: l[0] === CORPUS ? 'YES' : 'NO', Status: 'Active', CreatedAt: now, CreatedBy: 'setup' };
    }));
  }
  if (!read_(SH.ACCOUNTS).length) {
    append_(SH.ACCOUNTS, [{ AccountID: 'ACC-CASH', Name: 'Cash in Hand', Type: 'Cash', OpeningBalance: 0, OpeningDate: fyStart,
      Status: 'Active', CreatedAt: now, CreatedBy: 'setup' }]);
  }
  if (!read_(SH.PLANS).length) {
    append_(SH.PLANS, [{ PlanID: 'PLN-DEFAULT', Name: 'Monthly Membership', Frequency: 'Monthly', Amount: 100,
      IncomeLedgerID: 'LED-D01', Description: 'Default plan — edit the amount as needed', Status: 'Active', CreatedAt: now, CreatedBy: 'setup' }]);
  }
}

function installTriggers_() {
  var names = ScriptApp.getProjectTriggers().map(function (t) { return t.getHandlerFunction(); });
  if (names.indexOf('dailyBackupTrigger') < 0) ScriptApp.newTrigger('dailyBackupTrigger').timeBased().everyDays(1).atHour(2).create();
  if (names.indexOf('monthlyDuesTrigger') < 0) ScriptApp.newTrigger('monthlyDuesTrigger').timeBased().onMonthDay(1).atHour(6).create();
}

/** OWNER-ONLY (editor): reset a user's password if everyone is locked out. */
function adminResetPassword(email) {
  assertOwner_();
  email = String(email || Session.getEffectiveUser().getEmail()).toLowerCase();
  return withLock_(function () {
    var u = userByEmail_(email);
    if (!u) throw new Error('No user with email ' + email);
    var temp = genPassword_();
    u.Salt = newSalt_(); u.PasswordHash = hashPw_(temp, u.Salt);
    u.MustChangePassword = 'YES'; u.FailedAttempts = 0; u.LockedUntil = ''; u.Status = 'Active';
    update_(SH.USERS, u);
    CacheService.getScriptCache().remove(lfKey_(email));
    Logger.log('Temporary password for ' + email + ': ' + temp);
    return temp;
  });
}

/** OWNER-ONLY (editor): switch the live database to a copy of a backup file. */
function restoreFromBackup(backupFileId) {
  assertOwner_();
  if (!backupFileId) throw new Error('Pass the Drive file ID of a backup spreadsheet.');
  var p = props_();
  var src = DriveApp.getFileById(backupFileId);
  var root = DriveApp.getFolderById(p.getProperty('ROOT_FOLDER_ID'));
  var copy = src.makeCopy('Masjid MS — Database (Restored ' + nowStr_() + ')', root);
  p.setProperty('PREVIOUS_SPREADSHEET_ID', p.getProperty('SPREADSHEET_ID'));
  p.setProperty('SPREADSHEET_ID', copy.getId());
  CacheService.getScriptCache().removeAll(CACHED_TABLES.map(function (n) { return 'TBL_' + n; }).concat(['DASH', 'QUOTA']));
  Logger.log('Restored. Live database is now: ' + copy.getUrl() + '\nThe previous database was kept (not deleted).');
  return copy.getId();
}

/**
 * Run this ONCE from the Apps Script editor after updating appsscript.json
 * (or whenever you see "The script does not have permission…").
 * It touches every Google service the app uses, so Google shows the
 * permission screen and asks you to Allow. It changes no data.
 */
function authorizeAll() {
  var id = PropertiesService.getScriptProperties().getProperty("SPREADSHEET_ID"); if (id) SpreadsheetApp.openById(id).getName();
  DriveApp.getRootFolder().getName();
  CalendarApp.getDefaultCalendar().getName();
  try { Calendar.CalendarList.list({ maxResults: 1 }); } catch (e) { Logger.log('Calendar advanced service is off: ' + e.message); }
  ScriptApp.getProjectTriggers();
  MailApp.getRemainingDailyQuota();
  Logger.log('All permissions granted. Now redeploy: Deploy > Manage deployments > Edit > Version: New version > Deploy.');
}
