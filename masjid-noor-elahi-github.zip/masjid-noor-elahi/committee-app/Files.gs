/**
 * Files.gs — Google Drive storage (bills, payment proofs, receipts, reports) and receipt PDFs.
 * Files stay private in the owner's Drive; the app streams them to authorised users only.
 * Only the Drive file ID is stored in the sheets.
 */

function folder_(key) {
  var id = props_().getProperty('FOLDER_' + key);
  if (!id) fail_('Drive folders are not set up. The owner should run setup().');
  return DriveApp.getFolderById(id);
}

var UPLOAD_TYPES = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'application/pdf': 'pdf' };

function magicOk_(bytes, mime) {
  var b = [0, 1, 2, 3].map(function (i) { return bytes[i] & 0xff; });
  if (mime === 'application/pdf') return b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46; // %PDF
  if (mime === 'image/jpeg') return b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff;
  if (mime === 'image/png') return b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47;
  if (mime === 'image/webp') return b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && // RIFF....WEBP
    (bytes[8] & 0xff) === 0x57 && (bytes[9] & 0xff) === 0x45 && (bytes[10] & 0xff) === 0x42 && (bytes[11] & 0xff) === 0x50;
  return false;
}

/** f = {name, mimeType, data(base64)} — returns Drive file ID or ''. */
function saveUpload_(ctx, f, key, label) {
  if (!f || !f.data) return '';
  var mime = String(f.mimeType || '');
  if (!UPLOAD_TYPES[mime]) fail_('Only JPG, PNG, WEBP or PDF files can be uploaded.');
  var bytes;
  try { bytes = Utilities.base64Decode(String(f.data)); } catch (e) { fail_('Upload is corrupted. Please try again.'); }
  var max = Math.min(10, num_(setting_('MAX_UPLOAD_MB')) || 5);
  if (bytes.length > max * 1048576) fail_('File is too large (max ' + max + ' MB).');
  if (bytes.length < 12 || !magicOk_(bytes, mime)) fail_('File content does not match its type.');
  if (mime === 'application/pdf' && /\/(JavaScript|Launch|EmbeddedFile)\b/.test(Utilities.newBlob(bytes).getDataAsString('ISO-8859-1')))
    fail_('This PDF contains scripts or embedded files and cannot be uploaded. Please print it to PDF again or upload a photo.');
  dailyCap_('UPLOAD_MB', ctx.user.UserID, 200, 'MB of uploads', bytes.length / 1048576);
  var name = label + '_' + Utilities.formatDate(new Date(), tz_(), 'yyyyMMdd_HHmmss') + '.' + UPLOAD_TYPES[mime];
  var file = folder_(key).createFile(Utilities.newBlob(bytes, mime, name));
  audit_(ctx, 'UPLOAD', 'File', file.getId(), { folder: FOLDERS[key], for: label, bytes: bytes.length });
  return file.getId();
}

/** Stream a stored file to an authorised user — only files inside the app's own folders. */
function getFile_(ctx, p) {
  var id = V.str(p.FileID, 'File', { req: true, max: 100 });
  if (!/^[\w-]{10,100}$/.test(id)) fail_('Invalid file reference.');
  var file;
  try { file = DriveApp.getFileById(id); } catch (e) { fail_('File not found.'); }
  var allowed = ['BILLS', 'PROOFS', 'RECEIPTS', 'REPORTS'].map(function (k) { return props_().getProperty('FOLDER_' + k); });
  var ok = false, it = file.getParents();
  while (it.hasNext()) if (allowed.indexOf(it.next().getId()) >= 0) ok = true;
  if (!ok) fail_('Access denied.');
  var blob = file.getBlob(), bytes = blob.getBytes();
  if (bytes.length > 10 * 1048576) fail_('File is too large to preview here.');
  return { name: file.getName(), mimeType: blob.getContentType(), data: Utilities.base64Encode(bytes) };
}

/* ---------------- Receipts ---------------- */

function listReceipts_(ctx, p) {
  var from = p.From ? V.date(p.From, 'From') : '0000-00-00', to = p.To ? V.date(p.To, 'To') : '9999-12-31';
  var own = !can_(ctx.user, 'vouchers.view'), me = String(ctx.user.Email).toLowerCase();
  return read_(SH.RECEIPTS).filter(function (r) {
    return r.Date >= from && r.Date <= to && (!own || String(r.CreatedBy).toLowerCase() === me);
  }).slice(-2000).map(strip_).reverse();
}

function receiptFor_(ctx, id) {
  var r = findById_(SH.RECEIPTS, V.id(id, 'Receipt'));
  if (!r) fail_('Receipt not found.');
  if (!can_(ctx.user, 'vouchers.view') && String(r.CreatedBy).toLowerCase() !== String(ctx.user.Email).toLowerCase()) fail_('Access denied.');
  return r;
}

function getReceipt_(ctx, p) {
  var r = receiptFor_(ctx, p.ReceiptID);
  var src = r.SourceType === 'COLLECTION' ? findById_(SH.COLLECTIONS, r.SourceID) : findById_(SH.INCOME, r.SourceID);
  return { receipt: strip_(r), voucherNo: src ? src.VoucherNo : '', reference: src ? src.Reference : '', org: receiptOrg_() };
}

function receiptOrg_() {
  return { name: setting_('MASJID_NAME'), address: setting_('MASJID_ADDRESS'), phone: setting_('MASJID_PHONE'), email: setting_('MASJID_EMAIL'),
    reg: setting_('REG_NO'), tax: setting_('TAX_EXEMPTION_NOTE'), footer: setting_('RECEIPT_FOOTER'), cc: setting_('WHATSAPP_COUNTRY_CODE') };
}

function receiptHtml_(r, voucherNo, o) {
  var cancelled = r.Status === 'CANCELLED';
  return '<html><head><style>body{font-family:Arial,sans-serif;color:#111}.box{border:2px solid #0f5132;padding:18px;max-width:640px;margin:auto}' +
    'h1{margin:0;color:#0f5132;font-size:18pt;text-align:center}.sub{text-align:center;font-size:9pt;color:#444}h2{text-align:center;font-size:12pt;letter-spacing:3px;margin:12px 0}' +
    'table{width:100%;border-collapse:collapse}td{padding:6px 4px;border-bottom:1px dotted #999;font-size:10.5pt}td.k{width:34%;color:#555}' +
    '.amt{font-size:15pt;font-weight:bold}.f{margin-top:22px;display:flex;justify-content:space-between;font-size:9pt}.void{color:#c00;font-size:22pt;text-align:center;font-weight:bold}</style></head><body><div class="box">' +
    '<h1>' + escHtml_(o.name) + '</h1><div class="sub">' + escHtml_(o.address) + (o.phone ? ' · ' + escHtml_(o.phone) : '') + (o.reg ? '<br>Reg. No: ' + escHtml_(o.reg) : '') + '</div>' +
    '<h2>RECEIPT</h2>' + (cancelled ? '<div class="void">CANCELLED</div>' : '') + '<table>' +
    '<tr><td class="k">Receipt No</td><td><b>' + escHtml_(r.ReceiptNo) + '</b></td></tr>' +
    '<tr><td class="k">Date</td><td>' + escHtml_(r.Date) + '</td></tr>' +
    '<tr><td class="k">Received from</td><td>' + escHtml_(r.PartyName) + '</td></tr>' +
    '<tr><td class="k">Towards</td><td>' + escHtml_(r.Purpose) + '</td></tr>' +
    '<tr><td class="k">Mode</td><td>' + escHtml_(r.Mode) + '</td></tr>' +
    '<tr><td class="k">Amount</td><td class="amt">₹ ' + money_(r.Amount) + '</td></tr>' +
    '<tr><td class="k">In words</td><td>' + escHtml_(r.AmountWords) + '</td></tr>' +
    '<tr><td class="k">Voucher</td><td>' + escHtml_(voucherNo) + '</td></tr></table>' +
    (o.tax ? '<p style="font-size:9pt">' + escHtml_(o.tax) + '</p>' : '') +
    '<div class="f"><span>' + escHtml_(o.footer) + '</span><span>Authorised Signatory</span></div>' +
    '<p style="font-size:7.5pt;color:#777;text-align:center">Computer-generated receipt.</p></div></body></html>';
}

function receiptPdf_(ctx, p) {
  var r = receiptFor_(ctx, p.ReceiptID);
  var info = getReceipt_(ctx, p);
  if (r.PdfFileID) {
    try {
      var f = DriveApp.getFileById(r.PdfFileID);
      return { name: f.getName(), mimeType: 'application/pdf', data: Utilities.base64Encode(f.getBlob().getBytes()) };
    } catch (e) { /* regenerate */ }
  }
  var name = String(r.ReceiptNo).replace(/\//g, '-') + '.pdf';
  var blob = Utilities.newBlob(receiptHtml_(r, info.voucherNo, info.org), 'text/html', 'r.html').getAs('application/pdf').setName(name);
  var file = folder_('RECEIPTS').createFile(blob);
  r.PdfFileID = file.getId();
  update_(SH.RECEIPTS, r);
  return { name: name, mimeType: 'application/pdf', data: Utilities.base64Encode(blob.getBytes()) };
}

/** Per-user daily limits kept in Script Properties (only reached inside the write lock). */
function dailyCap_(kind, uid, max, label, add) {
  var p = props_(), day = today_().replace(/-/g, ''), k = 'CAP_' + kind + '_' + day + '_' + uid;
  var used = num_(p.getProperty(k)), inc = add === undefined ? 1 : add;
  if (used + inc > max) fail_('Daily limit reached (' + max + ' ' + label + ' per person per day). Try again tomorrow.');
  p.setProperty(k, String(round2_(used + inc)));
  // tidy up yesterday's counters
  var all = p.getProperties();
  Object.keys(all).forEach(function (x) { if (x.indexOf('CAP_') === 0 && x.indexOf('_' + day + '_') < 0) p.deleteProperty(x); });
}

function emailReceipt_(ctx, p) {
  if (!yes_(setting_('EMAIL_RECEIPTS'))) fail_('Emailing receipts is turned off in Settings.');
  var rr = receiptFor_(ctx, p.ReceiptID);
  if (rr.Status === 'CANCELLED') fail_('Cancelled receipts cannot be emailed.');
  var to = V.email(p.Email, 'Email', true);
  // Collectors may only send to the member's email on record; others are capped and audited.
  var mem = rr.SourceType === 'COLLECTION' ? findById_(SH.MEMBERS, (findById_(SH.COLLECTIONS, rr.SourceID) || {}).MemberID) : null;
  if (ctx.user.Role === 'COLLECTOR' && !(mem && String(mem.Email).toLowerCase() === to)) fail_('Collectors can only email a receipt to the member\'s email on record.');
  dailyCap_('EMAIL', ctx.user.UserID, 20, 'receipt emails');
  var left = MailApp.getRemainingDailyQuota();
  if (left <= 5) fail_('Daily free email quota is almost used up (' + left + ' left). Use WhatsApp or download the PDF instead.');
  var pdf = receiptPdf_(ctx, p);
  var r = findById_(SH.RECEIPTS, p.ReceiptID);
  MailApp.sendEmail({
    to: to, subject: 'Receipt ' + r.ReceiptNo + ' — ' + setting_('MASJID_NAME'),
    htmlBody: '<p>Assalamu Alaikum,</p><p>Please find attached your receipt <b>' + escHtml_(r.ReceiptNo) + '</b> for ₹' + money_(r.Amount) + '.</p><p>' + escHtml_(setting_('RECEIPT_FOOTER')) + '</p>',
    attachments: [Utilities.newBlob(Utilities.base64Decode(pdf.data), 'application/pdf', pdf.name)],
    name: String(setting_('MASJID_NAME')).slice(0, 60)
  });
  audit_(ctx, 'EMAIL', 'Receipt', r.ReceiptID, { to: to });
  return { sent: true, remaining: left - 1 };
}
