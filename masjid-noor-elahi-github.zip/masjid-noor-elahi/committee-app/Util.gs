/**
 * Util.gs — dates, numbers, validation, amount-in-words.
 */

function tz_() { return Session.getScriptTimeZone() || 'Asia/Kolkata'; }
function today_() { return Utilities.formatDate(new Date(), tz_(), 'yyyy-MM-dd'); }
function nowStr_() { return Utilities.formatDate(new Date(), tz_(), 'yyyy-MM-dd HH:mm:ss'); }
function fmtTs_(ms) { return Utilities.formatDate(new Date(ms), tz_(), 'yyyy-MM-dd HH:mm:ss'); }
function pad_(n, w) { n = String(n); while (n.length < w) n = '0' + n; return n; }
function round2_(x) { return Math.round((Number(x) + Number.EPSILON) * 100) / 100; }
function num_(x) { var n = Number(x); return isFinite(n) ? n : 0; }
/** User-facing error. Anything else that is thrown is reported to the browser as a generic message. */
function fail_(msg) { var e = new Error(msg); e.userFacing = true; throw e; }
/** Constant-time string comparison. */
function constEq_(a, b) {
  a = String(a); b = String(b);
  var diff = a.length ^ b.length;
  for (var i = 0; i < Math.max(a.length, b.length); i++) diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return diff === 0;
}
/** Look-alike-proof key for name uniqueness (folds case, spacing, accents and common Cyrillic/Greek homoglyphs). */
var HOMOGLYPHS_ = { 'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'у': 'y', 'х': 'x', 'і': 'i', 'ј': 'j', 'ѕ': 's', 'ԁ': 'd', 'ɡ': 'g', 'һ': 'h', 'к': 'k', 'м': 'm', 'н': 'h', 'т': 't', 'в': 'b', 'ο': 'o', 'α': 'a', 'ε': 'e', 'ι': 'i', 'κ': 'k', 'ν': 'v', 'ρ': 'p', 'τ': 't', 'υ': 'u', 'χ': 'x', '0': 'o', '1': 'l' };
function nameKey_(s) {
  s = String(s || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  s = s.replace(/./g, function (c) { return HOMOGLYPHS_[c] || c; });
  return s.replace(/[^a-z0-9\u0600-\u06ff]+/g, '');
}

function addDays_(d, k) {
  var p = d.split('-');
  return new Date(Date.UTC(+p[0], +p[1] - 1, +p[2] + k)).toISOString().slice(0, 10);
}
function daysBetween_(a, b) {
  return Math.round((Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / 86400000);
}
function addMonths_(ym, k) { // 'yyyy-MM' -> 'yyyy-MM'
  var y = +ym.slice(0, 4), m = +ym.slice(5, 7) - 1 + k;
  y += Math.floor(m / 12); m = ((m % 12) + 12) % 12;
  return y + '-' + pad_(m + 1, 2);
}

function fyStartMonth_() {
  var m = parseInt(setting_('FY_START_MONTH'), 10);
  return m >= 1 && m <= 12 ? m : 4;
}
/** Financial-year label, e.g. '2026-27' (or '2026' if FY = calendar year). */
function fyLabel_(d) {
  var y = +d.slice(0, 4), m = +d.slice(5, 7), s = fyStartMonth_();
  if (s === 1) return String(y);
  var start = m >= s ? y : y - 1;
  return start + '-' + String(start + 1).slice(2);
}
function fyRange_(label) {
  var s = fyStartMonth_(), y = +String(label).slice(0, 4);
  var from = y + '-' + pad_(s, 2) + '-01';
  var to = addDays_((s === 1 ? y + 1 : y + 1) + '-' + pad_(s, 2) + '-01', -1);
  return { from: from, to: to };
}

function pick_(o, keys) { var r = {}; keys.forEach(function (k) { r[k] = o[k]; }); return r; }
function strip_(o) { var r = {}; Object.keys(o).forEach(function (k) { if (k.charAt(0) !== '_') r[k] = o[k]; }); return r; }
function yes_(v) { return String(v).toUpperCase() === 'YES'; }

/** Server-side validators — every financial input passes through these. */
var V = {
  str: function (v, label, o) {
    o = o || {};
    if (v !== null && v !== undefined && typeof v === 'object') fail_(label + ' must be text.');
    v = (v === null || v === undefined) ? '' : String(v);
    v = v.normalize('NFKC')
      .replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u2069\uFEFF\u00AD]/g, '')   // zero-width & bidi controls
      .replace(/\r\n?/g, '\n')
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '');
    v = o.multi ? v.replace(/\t/g, ' ').replace(/\n{3,}/g, '\n\n') : v.replace(/[\n\t]+/g, ' ').replace(/ {2,}/g, ' ');
    v = v.trim();
    var max = o.max || 200;
    if (o.req && !v) fail_(label + ' is required.');
    if (v.length > max) fail_(label + ' is too long (max ' + max + ' characters).');
    if (o.min && v && v.length < o.min) fail_(label + ' must be at least ' + o.min + ' characters.');
    return v;
  },
  amount: function (v, label, o) {
    o = o || {};
    if (v === '' || v === null || v === undefined) { if (o.allowZero) return 0; fail_(label + ' is required.'); }
    if (typeof v === 'string') { v = v.trim(); if (!/^\d{1,11}(\.\d{1,2})?$/.test(v)) fail_(label + ' must be a plain number with at most 2 decimals.'); }
    else if (typeof v !== 'number') fail_(label + ' must be a number.');
    var n = Number(v);
    if (!isFinite(n)) fail_(label + ' must be a number.');
    if (Math.abs(Math.round(n * 100) - n * 100) > 1e-6) fail_(label + ' can have at most 2 decimal places.');
    n = round2_(n);
    if (o.allowZero ? n < 0 : n <= 0) fail_(label + ' must be greater than zero.');
    if (n > 1e10) fail_(label + ' is too large.');
    return n;
  },
  date: function (v, label) {
    v = String(v || '').trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(v) || isNaN(Date.parse(v + 'T00:00:00Z')) ||
        new Date(v + 'T00:00:00Z').toISOString().slice(0, 10) !== v) fail_(label + ' must be a valid date (YYYY-MM-DD).');
    return v;
  },
  month: function (v, label) {
    v = String(v || '').trim();
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(v)) fail_(label + ' must be a month (YYYY-MM).');
    return v;
  },
  oneOf: function (v, list, label) {
    if (list.indexOf(v) < 0) fail_(label + ' is invalid.');
    return v;
  },
  email: function (v, label, req) {
    v = V.str(v, label || 'Email', { max: 120, req: req }).toLowerCase();
    if (v && !/^[^\s@<>"']+@[^\s@<>"']+\.[a-z]{2,}$/i.test(v)) fail_((label || 'Email') + ' is not valid.');
    return v;
  },
  phone: function (v, label) {
    v = V.str(v, label || 'Phone', { max: 20 });
    if (v && !/^\+?[0-9 \-]{7,18}$/.test(v)) fail_((label || 'Phone') + ' is not valid.');
    return v;
  },
  id: function (v, label) { return V.str(v, label, { req: true, max: 60 }); }
};

/** Voucher-date rules: no future dates, respect lock date, limit back-dating. */
function checkVoucherDate_(ctx, d) {
  V.date(d, 'Date');
  var t = today_();
  if (d > t) fail_('Future-dated entries are not allowed.');
  checkLock_(d);
  if (ctx.user.Role !== 'ADMIN') {
    var days = parseInt(setting_('BACKDATE_DAYS'), 10);
    if (days >= 0 && daysBetween_(d, t) > days) fail_('You can only enter vouchers up to ' + days + ' days back. Please ask an Admin.');
  }
}
function checkLock_(d) {
  var lock = String(setting_('LOCK_DATE') || '');
  if (lock && d <= lock) fail_('Books are locked up to ' + lock + '. No entries or cancellations on or before this date.');
}

/** Indian-system amount in words (Lakh / Crore). */
function amountWords_(n) {
  n = round2_(n);
  var rupees = Math.floor(n), paise = Math.round((n - rupees) * 100);
  var a = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve',
    'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  var b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  function two(x) { return x < 20 ? a[x] : b[Math.floor(x / 10)] + (x % 10 ? ' ' + a[x % 10] : ''); }
  function three(x) { var h = Math.floor(x / 100), r = x % 100; return (h ? a[h] + ' Hundred' + (r ? ' ' : '') : '') + (r ? two(r) : ''); }
  function words(x) {
    if (x === 0) return 'Zero';
    var out = [], crore = Math.floor(x / 1e7); x %= 1e7;
    var lakh = Math.floor(x / 1e5); x %= 1e5;
    var th = Math.floor(x / 1000); x %= 1000;
    if (crore) out.push(words(crore) + ' Crore');
    if (lakh) out.push(two(lakh) + ' Lakh');
    if (th) out.push(two(th) + ' Thousand');
    if (x) out.push(three(x));
    return out.join(' ');
  }
  return 'Rupees ' + words(rupees) + (paise ? ' and ' + two(paise) + ' Paise' : '') + ' Only';
}

function genPassword_() {
  var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
  var raw = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
  var out = '';
  for (var i = 0; i < 10; i++) out += chars.charAt(parseInt(raw.substr(i * 2, 2), 16) % chars.length);
  return out + (parseInt(raw.substr(30, 2), 16) % 10); // always contains a digit
}

function escHtml_(s) {
  return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
function money_(n) {
  n = round2_(n);
  var neg = n < 0; n = Math.abs(n);
  var s = n.toFixed(2), int = s.split('.')[0], dec = s.split('.')[1];
  var last3 = int.slice(-3), rest = int.slice(0, -3);
  if (rest) last3 = ',' + last3;
  rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  return (neg ? '-' : '') + rest + last3 + '.' + dec;
}
