/**
 * Reports.gs — Tally-equivalent books and statements, computed from "Ledger Entries" in one read.
 * Every report returns a printable "doc": { title, subtitle, org, sections:[{heading, columns, rows}], warning }
 * which the browser renders, exports to CSV/print, and the server can save as a PDF in Drive.
 */

function doc_(title, subtitle) {
  return { title: title, subtitle: subtitle || '', org: setting_('MASJID_NAME'), address: setting_('MASJID_ADDRESS'), generatedAt: nowStr_(), sections: [] };
}
function sec_(doc, heading, columns) { var s = { heading: heading || '', columns: columns, rows: [] }; doc.sections.push(s); return s; }
function row_(s, cells, style) { s.rows.push({ c: cells, s: style || '' }); }
function nz_(x) { x = round2_(x); return x === 0 ? '' : x; }
function groupsOf_(nature) { return Object.keys(GROUPS).filter(function (g) { return GROUPS[g] === nature; }); }
function range_(p) {
  var t = today_(), fy = fyRange_(fyLabel_(t));
  var from = p.From ? V.date(p.From, 'From date') : fy.from;
  var to = p.To ? V.date(p.To, 'To date') : t;
  if (from > to) fail_('From date must be before To date.');
  return { from: from, to: to };
}
function balances_(filterFn) {
  var b = {};
  glActive_().forEach(function (e) { if (filterFn(e)) b[e.LedgerID] = (b[e.LedgerID] || 0) + num_(e.Debit) - num_(e.Credit); });
  return b;
}
function sortedIds_(lm, ids) { return ids.sort(function (a, b) { return String(lm[a].name).localeCompare(String(lm[b].name)); }); }

function runReport_(ctx, p) {
  var fns = {
    trialBalance: rptTrialBalance_, incomeExpenditure: rptIncomeExpenditure_, receiptsPayments: rptReceiptsPayments_,
    balanceSheet: rptBalanceSheet_, ledger: rptLedger_, dayBook: rptDayBook_, funds: rptFunds_, budget: rptBudget_,
    outstanding: rptOutstanding_, memberStatement: rptMemberStatement_, brs: rptBrs_
  };
  var fn = fns[p.Report];
  if (!fn) fail_('Unknown report.');
  return fn(p, ctx);
}

/* ---- Trial Balance ---- */
function rptTrialBalance_(p) {
  var asOf = p.AsOf ? V.date(p.AsOf, 'As on') : today_();
  var lm = ledgerMap_(), bal = balances_(function (e) { return e.Date <= asOf; });
  var doc = doc_('Trial Balance', 'As on ' + asOf);
  var s = sec_(doc, '', [['Particulars', 'text'], ['Debit (₹)', 'money'], ['Credit (₹)', 'money']]);
  var tdr = 0, tcr = 0;
  NATURES.forEach(function (nat) {
    groupsOf_(nat).forEach(function (g) {
      var ids = sortedIds_(lm, Object.keys(bal).filter(function (id) { return lm[id] && lm[id].group === g && round2_(bal[id]) !== 0; }));
      if (!ids.length) return;
      var gdr = 0, gcr = 0;
      ids.forEach(function (id) { var b = round2_(bal[id]); if (b > 0) gdr += b; else gcr -= b; });
      row_(s, [g, nz_(gdr), nz_(gcr)], 'head');
      ids.forEach(function (id) { var b = round2_(bal[id]); row_(s, [lm[id].name, b > 0 ? b : '', b < 0 ? -b : ''], 'sub'); });
      tdr += gdr; tcr += gcr;
    });
  });
  row_(s, ['Grand Total', round2_(tdr), round2_(tcr)], 'total');
  if (round2_(tdr) !== round2_(tcr)) doc.warning = 'Trial Balance does not tally. Difference: ₹' + money_(tdr - tcr);
  return doc;
}

/* ---- Income & Expenditure Account (non-profit P&L) ---- */
function rptIncomeExpenditure_(p) {
  var r = range_(p), fund = p.FundID || '';
  var lm = ledgerMap_();
  var bal = balances_(function (e) { return e.Date >= r.from && e.Date <= r.to && (!fund || (e.FundID || GEN_FUND) === fund); });
  var fname = fund ? (findById_(SH.FUNDS, fund) || {}).Name : '';
  var doc = doc_('Income & Expenditure Account', r.from + ' to ' + r.to + (fname ? ' — ' + fname : ''));
  var totals = {};
  ['Income', 'Expense'].forEach(function (nat) {
    var s = sec_(doc, nat === 'Income' ? 'Income' : 'Expenditure', [['Particulars', 'text'], ['Amount (₹)', 'money']]);
    var t = 0;
    groupsOf_(nat).forEach(function (g) {
      var ids = sortedIds_(lm, Object.keys(bal).filter(function (id) { return lm[id] && lm[id].group === g && round2_(bal[id]) !== 0; }));
      if (!ids.length) return;
      var gt = 0;
      ids.forEach(function (id) { gt += nat === 'Income' ? -bal[id] : bal[id]; });
      row_(s, [g, round2_(gt)], 'head');
      ids.forEach(function (id) { row_(s, [lm[id].name, round2_(nat === 'Income' ? -bal[id] : bal[id])], 'sub'); });
      t += gt;
    });
    row_(s, ['Total ' + (nat === 'Income' ? 'Income' : 'Expenditure'), round2_(t)], 'total');
    totals[nat] = round2_(t);
  });
  var sum = sec_(doc, 'Result', [['Particulars', 'text'], ['Amount (₹)', 'money']]);
  var surplus = round2_(totals.Income - totals.Expense);
  row_(sum, [surplus >= 0 ? 'Excess of Income over Expenditure (Surplus)' : 'Excess of Expenditure over Income (Deficit)', Math.abs(surplus)], 'total');
  return doc;
}

/* ---- Receipts & Payments Account (cash-basis summary, standard for trusts) ---- */
function rptReceiptsPayments_(p) {
  var r = range_(p), lm = ledgerMap_(), gl = glActive_();
  var cashIds = Object.keys(lm).filter(function (id) { return lm[id].cash; });
  var open = {}, close = {};
  cashIds.forEach(function (id) { open[id] = 0; close[id] = 0; });
  var bySrc = {};
  gl.forEach(function (e) {
    var l = lm[e.LedgerID];
    if (l && l.cash) {
      var v = num_(e.Debit) - num_(e.Credit);
      if (e.Date < r.from) open[e.LedgerID] += v;
      if (e.Date <= r.to) close[e.LedgerID] += v;
    }
    if (e.Date >= r.from && e.Date <= r.to) (bySrc[e.SourceID] = bySrc[e.SourceID] || []).push(e);
  });
  var rec = {}, pay = {};
  Object.keys(bySrc).forEach(function (src) {
    var lines = bySrc[src];
    if (!lines.some(function (e) { return lm[e.LedgerID] && lm[e.LedgerID].cash; })) return; // no cash movement
    lines.forEach(function (e) {
      var l = lm[e.LedgerID];
      if (!l || l.cash) return; // contra lines between cash/bank are excluded
      var net = num_(e.Credit) - num_(e.Debit);
      if (net > 0) rec[e.LedgerID] = (rec[e.LedgerID] || 0) + net;
      else if (net < 0) pay[e.LedgerID] = (pay[e.LedgerID] || 0) - net;
    });
  });
  var doc = doc_('Receipts & Payments Account', r.from + ' to ' + r.to);
  var cols = [['Particulars', 'text'], ['Amount (₹)', 'money']];
  var s1 = sec_(doc, 'Receipts', cols), t1 = 0;
  row_(s1, ['Opening Balance', ''], 'head');
  cashIds.forEach(function (id) { if (round2_(open[id])) { row_(s1, [lm[id].name, round2_(open[id])], 'sub'); t1 += open[id]; } });
  function block(s, map) {
    var t = 0;
    NATURES.forEach(function (nat) {
      groupsOf_(nat).forEach(function (g) {
        var ids = sortedIds_(lm, Object.keys(map).filter(function (id) { return lm[id].group === g && round2_(map[id]); }));
        if (!ids.length) return;
        var gt = ids.reduce(function (a, id) { return a + map[id]; }, 0);
        row_(s, [g, round2_(gt)], 'head');
        ids.forEach(function (id) { row_(s, [lm[id].name, round2_(map[id])], 'sub'); });
        t += gt;
      });
    });
    return t;
  }
  t1 += block(s1, rec);
  row_(s1, ['Total', round2_(t1)], 'total');
  var s2 = sec_(doc, 'Payments', cols);
  var t2 = block(s2, pay);
  row_(s2, ['Closing Balance', ''], 'head');
  cashIds.forEach(function (id) { if (round2_(close[id])) { row_(s2, [lm[id].name, round2_(close[id])], 'sub'); t2 += close[id]; } });
  row_(s2, ['Total', round2_(t2)], 'total');
  if (round2_(t1) !== round2_(t2)) doc.warning = 'Receipts and Payments do not agree (difference ₹' + money_(t1 - t2) + ').';
  return doc;
}

/* ---- Balance Sheet ---- */
function rptBalanceSheet_(p) {
  var asOf = p.AsOf ? V.date(p.AsOf, 'As on') : today_();
  var lm = ledgerMap_(), bal = balances_(function (e) { return e.Date <= asOf; });
  var funds = fundBalances_(asOf), fundRows = read_(SH.FUNDS);
  var doc = doc_('Balance Sheet', 'As on ' + asOf);
  var cols = [['Particulars', 'text'], ['Amount (₹)', 'money']];
  var s1 = sec_(doc, 'Funds & Liabilities', cols), t1 = 0;
  row_(s1, ['Funds (Corpus + accumulated surplus)', ''], 'head');
  var fsum = 0;
  fundRows.forEach(function (f) { var v = round2_(funds[f.FundID] || 0); if (v) { row_(s1, [f.Name, v], 'sub'); fsum += v; } });
  Object.keys(funds).forEach(function (fid) { if (!findById_(SH.FUNDS, fid) && round2_(funds[fid])) { row_(s1, [fid, round2_(funds[fid])], 'sub'); fsum += funds[fid]; } });
  t1 += fsum;
  groupsOf_('Liability').filter(function (g) { return FUND_GROUPS.indexOf(g) < 0; }).forEach(function (g) {
    var ids = sortedIds_(lm, Object.keys(bal).filter(function (id) { return lm[id] && lm[id].group === g && round2_(bal[id]); }));
    if (!ids.length) return;
    var gt = ids.reduce(function (a, id) { return a - bal[id]; }, 0);
    row_(s1, [g, round2_(gt)], 'head');
    ids.forEach(function (id) { row_(s1, [lm[id].name, round2_(-bal[id])], 'sub'); });
    t1 += gt;
  });
  row_(s1, ['Total', round2_(t1)], 'total');
  var s2 = sec_(doc, 'Assets', cols), t2 = 0;
  groupsOf_('Asset').forEach(function (g) {
    var ids = sortedIds_(lm, Object.keys(bal).filter(function (id) { return lm[id] && lm[id].group === g && round2_(bal[id]); }));
    if (!ids.length) return;
    var gt = ids.reduce(function (a, id) { return a + bal[id]; }, 0);
    row_(s2, [g, round2_(gt)], 'head');
    ids.forEach(function (id) { row_(s2, [lm[id].name, round2_(bal[id])], 'sub'); });
    t2 += gt;
  });
  row_(s2, ['Total', round2_(t2)], 'total');
  if (round2_(t1) !== round2_(t2)) doc.warning = 'Balance Sheet does not tally (difference ₹' + money_(t1 - t2) + ').';
  return doc;
}

/* ---- Ledger statement / Cash Book / Bank Book ---- */
function rptLedger_(p) {
  var r = range_(p), lm = ledgerMap_(), id = V.id(p.LedgerID, 'Ledger'), l = lm[id];
  if (!l) fail_('Ledger not found.');
  var gl = glActive_(), bySrc = {}, opening = 0, list = [];
  gl.forEach(function (e) { (bySrc[e.SourceID] = bySrc[e.SourceID] || []).push(e); });
  gl.forEach(function (e) {
    if (e.LedgerID !== id) return;
    if (e.Date < r.from) opening += num_(e.Debit) - num_(e.Credit);
    else if (e.Date <= r.to) list.push(e);
  });
  list.sort(function (a, b) { return a.Date < b.Date ? -1 : a.Date > b.Date ? 1 : (a.CreatedAt < b.CreatedAt ? -1 : 1); });
  var title = l.cash ? (l.type === 'Bank' ? 'Bank Book' : 'Cash Book') : 'Ledger Account';
  var doc = doc_(title + ': ' + l.name, r.from + ' to ' + r.to + ' · Group: ' + l.group);
  var s = sec_(doc, '', [['Date', 'date'], ['Voucher', 'text'], ['Type', 'text'], ['Particulars', 'text'], ['Debit (₹)', 'money'], ['Credit (₹)', 'money'], ['Balance', 'text']]);
  var bal = round2_(opening), tdr = 0, tcr = 0;
  function bs(b) { b = round2_(b); return b === 0 ? '0.00' : money_(Math.abs(b)) + (b > 0 ? ' Dr' : ' Cr'); }
  row_(s, [r.from, '', '', 'Opening Balance', '', '', bs(bal)], 'head');
  list.forEach(function (e) {
    var others = (bySrc[e.SourceID] || []).filter(function (o) { return o.LedgerID !== id; })
      .map(function (o) { return (lm[o.LedgerID] || { name: o.LedgerID }).name; });
    var dr = num_(e.Debit), cr = num_(e.Credit);
    bal += dr - cr; tdr += dr; tcr += cr;
    var part = (others.length ? (dr ? 'By ' : 'To ') + others.filter(function (x, i, a) { return a.indexOf(x) === i; }).join(', ') : '') +
      (e.Narration ? ' — ' + e.Narration : '');
    row_(s, [e.Date, e.VoucherNo, e.VoucherType, part, nz_(dr), nz_(cr), bs(bal)]);
  });
  row_(s, ['', '', '', 'Total for period', round2_(tdr), round2_(tcr), ''], 'total');
  row_(s, [r.to, '', '', 'Closing Balance', '', '', bs(bal)], 'total');
  return doc;
}

/* ---- Day Book ---- */
function rptDayBook_(p) {
  var r = range_({ From: p.From || today_(), To: p.To || today_() }), lm = ledgerMap_();
  var vt = p.VoucherType || '';
  var map = {}, order = [];
  read_(SH.GL).forEach(function (e) {
    if (e.Date < r.from || e.Date > r.to || (vt && e.VoucherType !== vt)) return;
    if (!map[e.SourceID]) { map[e.SourceID] = []; order.push(e.SourceID); }
    map[e.SourceID].push(e);
  });
  order.sort(function (a, b) { var x = map[a][0], y = map[b][0]; return x.Date < y.Date ? -1 : x.Date > y.Date ? 1 : (x.CreatedAt < y.CreatedAt ? -1 : 1); });
  var doc = doc_('Day Book', r.from + ' to ' + r.to + (vt ? ' · ' + vt + ' vouchers' : ''));
  var s = sec_(doc, '', [['Date', 'date'], ['Voucher', 'text'], ['Type', 'text'], ['Particulars', 'text'], ['Debit (₹)', 'money'], ['Credit (₹)', 'money']]);
  var tdr = 0, tcr = 0;
  order.forEach(function (src) {
    var lines = map[src], first = lines[0], cancelled = first.Status === 'CANCELLED';
    lines.forEach(function (e, i) {
      var dr = num_(e.Debit), cr = num_(e.Credit);
      if (!cancelled) { tdr += dr; tcr += cr; }
      row_(s, [i === 0 ? e.Date : '', i === 0 ? e.VoucherNo + (cancelled ? ' (CANCELLED)' : '') : '', i === 0 ? e.VoucherType : '',
        (dr ? 'Dr ' : '   Cr ') + (lm[e.LedgerID] || { name: e.LedgerID }).name + (i === 0 && e.Narration ? ' — ' + e.Narration : ''),
        nz_(dr), nz_(cr)], cancelled ? 'muted' : (i === 0 ? '' : 'sub'));
    });
  });
  row_(s, ['', '', '', 'Total (' + order.length + ' vouchers)', round2_(tdr), round2_(tcr)], 'total');
  return doc;
}

/* ---- Fund statement (Zakat / Sadaqah / Construction …) ---- */
function rptFunds_(p) {
  var r = range_(p), lm = ledgerMap_(), stats = {};
  read_(SH.FUNDS).forEach(function (f) { stats[f.FundID] = { name: f.Name, type: f.Type, open: 0, inc: 0, exp: 0 }; });
  glActive_().forEach(function (e) {
    var l = lm[e.LedgerID];
    if (!l || !(l.nature === 'Income' || l.nature === 'Expense' || FUND_GROUPS.indexOf(l.group) >= 0)) return;
    var f = e.FundID || GEN_FUND, st = stats[f] || (stats[f] = { name: f, type: '', open: 0, inc: 0, exp: 0 });
    var v = num_(e.Credit) - num_(e.Debit);
    if (e.Date < r.from) st.open += v;
    else if (e.Date <= r.to) { if (v >= 0) st.inc += v; else st.exp -= v; }
  });
  var doc = doc_('Fund Statement', r.from + ' to ' + r.to);
  var s = sec_(doc, '', [['Fund', 'text'], ['Type', 'text'], ['Opening (₹)', 'money'], ['Received (₹)', 'money'], ['Spent (₹)', 'money'], ['Closing (₹)', 'money']]);
  var T = [0, 0, 0, 0];
  Object.keys(stats).forEach(function (k) {
    var st = stats[k], c = st.open + st.inc - st.exp;
    row_(s, [st.name, st.type, round2_(st.open), round2_(st.inc), round2_(st.exp), round2_(c)], c < 0 ? 'neg' : '');
    T[0] += st.open; T[1] += st.inc; T[2] += st.exp; T[3] += c;
  });
  row_(s, ['Total', '', round2_(T[0]), round2_(T[1]), round2_(T[2]), round2_(T[3])], 'total');
  return doc;
}

/* ---- Budget vs Actual ---- */
function rptBudget_(p) {
  var fy = String(p.FY || fyLabel_(today_()));
  if (!/^\d{4}(-\d{2})?$/.test(fy)) fail_('Financial year must look like 2026-27.');
  var r = fyRange_(fy), lm = ledgerMap_();
  var act = balances_(function (e) { return e.Date >= r.from && e.Date <= r.to; });
  var bud = {};
  read_(SH.BUDGETS).forEach(function (b) { if (b.FY === fy) bud[b.LedgerID] = num_(b.Amount); });
  var doc = doc_('Budget vs Actual', 'Financial Year ' + fy + ' (' + r.from + ' to ' + r.to + ')');
  ['Income', 'Expense'].forEach(function (nat) {
    var s = sec_(doc, nat === 'Income' ? 'Income' : 'Expenditure', [['Ledger', 'text'], ['Budget (₹)', 'money'], ['Actual (₹)', 'money'], ['Variance (₹)', 'money'], ['Used %', 'text']]);
    var ids = Object.keys(lm).filter(function (id) { return lm[id].nature === nat && (bud[id] || round2_(act[id] || 0)); });
    var tb = 0, ta = 0;
    sortedIds_(lm, ids).forEach(function (id) {
      var a = round2_(nat === 'Income' ? -(act[id] || 0) : (act[id] || 0)), b = bud[id] || 0;
      tb += b; ta += a;
      row_(s, [lm[id].name, b, a, round2_(b - a), b ? Math.round(a / b * 100) + '%' : '—'], nat === 'Expense' && b && a > b ? 'neg' : '');
    });
    row_(s, ['Total', round2_(tb), round2_(ta), round2_(tb - ta), tb ? Math.round(ta / tb * 100) + '%' : '—'], 'total');
  });
  return doc;
}

/* ---- Membership outstanding (Tally: Bills Receivable / Outstanding) ---- */
function rptOutstanding_(p) {
  var asOf = p.AsOf ? V.date(p.AsOf, 'As on') : today_();
  var mem = {};
  read_(SH.MEMBERS).forEach(function (m) { mem[m.MemberID] = m; });
  var agg = {};
  read_(SH.SCHEDULE).forEach(function (s) {
    if (s.Status !== 'Due' && s.Status !== 'Partial') return;
    if (s.DueDate > asOf) return;
    var a = agg[s.MemberID] || (agg[s.MemberID] = { n: 0, bal: 0, oldest: s.Period });
    a.n++; a.bal += num_(s.Amount) - num_(s.PaidAmount);
    if (s.Period < a.oldest) a.oldest = s.Period;
  });
  var doc = doc_('Membership Dues Outstanding', 'Dues falling due on or before ' + asOf);
  var s = sec_(doc, '', [['Member No', 'text'], ['Name', 'text'], ['Phone', 'text'], ['Periods Due', 'text'], ['Oldest', 'text'], ['Outstanding (₹)', 'money']]);
  var t = 0, ids = Object.keys(agg).sort(function (a, b) { return agg[b].bal - agg[a].bal; });
  ids.forEach(function (id) {
    var m = mem[id] || {};
    row_(s, [m.MemberNo || id, m.Name || '', m.Phone || '', String(agg[id].n), agg[id].oldest, round2_(agg[id].bal)]);
    t += agg[id].bal;
  });
  row_(s, ['', ids.length + ' members', '', '', '', round2_(t)], 'total');
  return doc;
}

function rptMemberStatement_(p) {
  var m = findById_(SH.MEMBERS, V.id(p.MemberID, 'Member'));
  if (!m) fail_('Member not found.');
  var doc = doc_('Member Statement: ' + m.Name + ' (' + m.MemberNo + ')', (m.Phone || '') + (m.Address ? ' · ' + m.Address : ''));
  var s1 = sec_(doc, 'Dues', [['Period', 'text'], ['Due Date', 'date'], ['Amount (₹)', 'money'], ['Paid (₹)', 'money'], ['Balance (₹)', 'money'], ['Status', 'text']]);
  var ta = 0, tp = 0;
  read_(SH.SCHEDULE).filter(function (x) { return x.MemberID === m.MemberID; }).sort(function (a, b) { return a.Period < b.Period ? -1 : 1; })
    .forEach(function (x) {
      var bal = x.Status === 'Waived' ? 0 : num_(x.Amount) - num_(x.PaidAmount);
      if (x.Status !== 'Waived') { ta += num_(x.Amount); tp += num_(x.PaidAmount); }
      row_(s1, [x.Period, x.DueDate, num_(x.Amount), num_(x.PaidAmount), round2_(bal), x.Status], x.Status === 'Waived' ? 'muted' : '');
    });
  row_(s1, ['Total', '', round2_(ta), round2_(tp), round2_(ta - tp), ''], 'total');
  var s2 = sec_(doc, 'Payments', [['Date', 'date'], ['Voucher', 'text'], ['Mode', 'text'], ['Amount (₹)', 'money'], ['Status', 'text']]);
  read_(SH.COLLECTIONS).filter(function (c) { return c.MemberID === m.MemberID; }).forEach(function (c) {
    row_(s2, [c.Date, c.VoucherNo, c.Mode, num_(c.Amount), c.Status], c.Status === 'CANCELLED' ? 'muted' : '');
  });
  return doc;
}

/* ---- Bank Reconciliation Statement ---- */
function rptBrs_(p) {
  var asOf = p.AsOf ? V.date(p.AsOf, 'As on') : today_();
  var acc = activeAccount_(V.id(p.LedgerID, 'Bank account'));
  if (acc.type !== 'Bank') fail_('Choose a bank account.');
  var lm = ledgerMap_(), bySrc = {}, book = 0, items = [];
  var gl = glActive_();
  gl.forEach(function (e) { (bySrc[e.SourceID] = bySrc[e.SourceID] || []).push(e); });
  gl.forEach(function (e) {
    if (e.LedgerID !== acc.id || e.Date > asOf) return;
    book += num_(e.Debit) - num_(e.Credit);
    if (!e.ClearedDate || e.ClearedDate > asOf) {
      var other = (bySrc[e.SourceID] || []).filter(function (o) { return o.LedgerID !== acc.id; }).map(function (o) { return (lm[o.LedgerID] || {}).name; });
      items.push({ EntryID: e.EntryID, Date: e.Date, VoucherNo: e.VoucherNo, Particulars: other.join(', ') + (e.Narration ? ' — ' + e.Narration : ''),
        Debit: num_(e.Debit), Credit: num_(e.Credit), ClearedDate: e.ClearedDate });
    }
  });
  var dep = items.reduce(function (a, i) { return a + i.Debit; }, 0), chq = items.reduce(function (a, i) { return a + i.Credit; }, 0);
  var bank = round2_(book - dep + chq);
  var doc = doc_('Bank Reconciliation: ' + acc.name, 'As on ' + asOf);
  var s = sec_(doc, '', [['Particulars', 'text'], ['Amount (₹)', 'money']]);
  row_(s, ['Balance as per books', round2_(book)], 'head');
  row_(s, ['Less: Deposits not yet credited by bank', round2_(dep)], 'sub');
  row_(s, ['Add: Payments / cheques not yet presented', round2_(chq)], 'sub');
  row_(s, ['Expected balance as per bank statement', bank], 'total');
  var s2 = sec_(doc, 'Un-reconciled entries', [['Date', 'date'], ['Voucher', 'text'], ['Particulars', 'text'], ['Deposit (₹)', 'money'], ['Withdrawal (₹)', 'money']]);
  items.forEach(function (i) { row_(s2, [i.Date, i.VoucherNo, i.Particulars, nz_(i.Debit), nz_(i.Credit)]); });
  doc.items = items;
  return doc;
}

function brsClear_(ctx, p) {
  var ids = Array.isArray(p.EntryIDs) ? p.EntryIDs.map(String) : [];
  if (!ids.length || ids.length > 500) fail_('Select between 1 and 500 entries.');
  var cleared = p.ClearedDate ? V.date(p.ClearedDate, 'Bank date') : '';
  if (cleared && cleared > today_()) fail_('Bank date cannot be in the future.');
  var lm = ledgerMap_();
  var rows = read_(SH.GL).filter(function (e) { return ids.indexOf(e.EntryID) >= 0; });
  if (rows.length !== ids.length) fail_('Some entries were not found.');
  rows.forEach(function (e) {
    var l = lm[e.LedgerID];
    if (!l || !l.cash || l.type !== 'Bank') fail_('Only bank entries can be reconciled.');
    if (e.Status === 'CANCELLED') fail_('Cancelled entries cannot be reconciled.');
    if (cleared && cleared < e.Date) fail_('Bank date cannot be before the voucher date (' + e.VoucherNo + ').');
    checkLock_(e.Date);
    if (e.ClearedDate) checkLock_(e.ClearedDate);
    e.ClearedDate = cleared;
  });
  updateMany_(SH.GL, rows);
  audit_(ctx, cleared ? 'RECONCILE' : 'UNRECONCILE', 'LedgerEntry', '', { entries: ids.length, bankDate: cleared });
  return { updated: rows.length };
}

/* ---- Dashboard ---- */
function dashboard_(ctx) {
  var cache = CacheService.getScriptCache(), hit = cache.get('DASH'), d;
  if (hit) d = JSON.parse(hit);
  else { d = computeDashboard_(); try { cache.put('DASH', JSON.stringify(d), 600); } catch (e) { } }
  if (!can_(ctx.user, 'dashboard.finance')) {
    var me = String(ctx.user.Email).toLowerCase(), t = today_(), mine = { count: 0, amount: 0 };
    [SH.INCOME, SH.COLLECTIONS].forEach(function (n) {
      read_(n).forEach(function (r) {
        if (r.Date === t && r.Status === 'POSTED' && String(r.CreatedBy).toLowerCase() === me) { mine.count++; mine.amount += num_(r.Amount); }
      });
    });
    return { limited: true, myToday: mine, activeMembers: d.activeMembers, dues: d.dues };
  }
  d.warnings = ctx.user.Role === 'ADMIN' ? quotaWarnings_().concat(selfApprovalWarning_()) : unlockWarning_();
  return d;
}

/** Trustees and auditors are always told when someone re-opened closed books. */
function unlockWarning_() {
  var out = [];
  try {
    var u = JSON.parse(props_().getProperty('LAST_UNLOCK') || 'null');
    if (u && daysBetween_(u.at.slice(0, 10), today_()) <= 30) out.push('Books were unlocked by ' + u.by + ' on ' + u.at + ' (lock date ' + u.from + ' → ' + u.to + ').');
  } catch (e) { }
  out = out.concat(selfApprovalWarning_());
  return out;
}
function selfApprovalWarning_() {
  if (!yes_(setting_('SELF_APPROVE_ALERT'))) return [];
  try {
    var list = JSON.parse(props_().getProperty('SELF_APPROVALS') || '[]').filter(function (x) { return daysBetween_(x.at.slice(0, 10), today_()) <= 30; });
    if (!list.length) return [];
    var total = list.filter(function (x) { return x.decision === 'APPROVED'; }).reduce(function (a, x) { return a + num_(x.amount); }, 0);
    return [list.length + ' voucher(s) were approved/rejected by the same Admin who entered them in the last 30 days (₹' + money_(total) + ' approved). See Approvals › History or the Audit Log ("ADMIN_SELF_APPROVE").'];
  } catch (e) { return []; }
}

function computeDashboard_() {
  var lm = ledgerMap_(), t = today_(), ym = t.slice(0, 7), fy = fyLabel_(t), fr = fyRange_(fy);
  var accounts = {}, inc = { today: 0, month: 0, fy: 0 }, exp = { today: 0, month: 0, fy: 0 }, months = {}, expGroups = {};
  var startYm = addMonths_(ym, -11);
  for (var i = 0; i < 12; i++) months[addMonths_(startYm, i)] = { inc: 0, exp: 0 };
  Object.keys(lm).forEach(function (id) { if (lm[id].cash && lm[id].status === 'Active') accounts[id] = 0; });
  glActive_().forEach(function (e) {
    var l = lm[e.LedgerID];
    if (!l) return;
    var dr = num_(e.Debit), cr = num_(e.Credit), m = e.Date.slice(0, 7);
    if (l.cash) accounts[e.LedgerID] = (accounts[e.LedgerID] || 0) + dr - cr;
    if (l.nature === 'Income' || l.nature === 'Expense') {
      var v = l.nature === 'Income' ? cr - dr : dr - cr, bucket = l.nature === 'Income' ? inc : exp;
      if (e.Date === t) bucket.today += v;
      if (m === ym) bucket.month += v;
      if (e.Date >= fr.from && e.Date <= fr.to) {
        bucket.fy += v;
        if (l.nature === 'Expense') expGroups[l.group] = (expGroups[l.group] || 0) + v;
      }
      if (months[m]) months[m][l.nature === 'Income' ? 'inc' : 'exp'] += v;
    }
  });
  var dues = { amount: 0, members: 0 }, dm = {};
  read_(SH.SCHEDULE).forEach(function (s) {
    if ((s.Status === 'Due' || s.Status === 'Partial') && s.DueDate <= t) { dues.amount += num_(s.Amount) - num_(s.PaidAmount); dm[s.MemberID] = 1; }
  });
  dues.members = Object.keys(dm).length; dues.amount = round2_(dues.amount);
  var fb = fundBalances_();
  var recent = [], seen = {}, gl = read_(SH.GL);
  for (var j = gl.length - 1; j >= 0 && recent.length < 10; j--) {
    var e = gl[j];
    if (seen[e.SourceID] || e.Status === 'CANCELLED' || e.VoucherType === 'OPENING') continue;
    seen[e.SourceID] = 1;
    var amt = gl.filter(function (x) { return x.SourceID === e.SourceID; }).reduce(function (a, x) { return a + num_(x.Debit); }, 0);
    recent.push({ date: e.Date, no: e.VoucherNo, type: e.VoucherType, narration: e.Narration, amount: round2_(amt) });
  }
  function r2(o) { Object.keys(o).forEach(function (k) { o[k] = round2_(o[k]); }); return o; }
  return {
    generatedAt: nowStr_(), fy: fy,
    accounts: Object.keys(accounts).map(function (id) { return { id: id, name: lm[id].name, type: lm[id].type, balance: round2_(accounts[id]) }; }),
    income: r2(inc), expense: r2(exp),
    months: Object.keys(months).map(function (k) { return [k, round2_(months[k].inc), round2_(months[k].exp)]; }),
    expenseGroups: Object.keys(expGroups).map(function (g) { return [g, round2_(expGroups[g])]; }),
    funds: read_(SH.FUNDS).map(function (f) { return { id: f.FundID, name: f.Name, restricted: f.Type === 'Restricted', balance: round2_(fb[f.FundID] || 0) }; }),
    pendingApprovals: read_(SH.APPROVALS).filter(function (a) { return a.Decision === 'PENDING'; }).length,
    activeMembers: read_(SH.MEMBERS).filter(function (m) { return m.Status === 'Active'; }).length,
    dues: dues, recent: recent
  };
}

/* ---- Server-side HTML for PDFs (reports & receipts) ---- */
function docHtml_(doc) {
  var css = 'body{font-family:Arial,sans-serif;font-size:10pt;color:#111}h1{font-size:15pt;margin:0}h2{font-size:12pt;margin:14px 0 4px}' +
    '.c{text-align:center}.m{text-align:right}table{width:100%;border-collapse:collapse;margin-top:6px}td,th{border:1px solid #bbb;padding:4px 6px}' +
    'th{background:#e8f3ec}tr.head td{font-weight:bold;background:#f5f5f5}tr.total td{font-weight:bold;border-top:2px solid #333}tr.sub td:first-child{padding-left:18px}' +
    'tr.muted td{color:#888;text-decoration:line-through}.warn{color:#b00;font-weight:bold}';
  var h = '<html><head><style>' + css + '</style></head><body><div class="c"><h1>' + escHtml_(doc.org) + '</h1><div>' + escHtml_(doc.address || '') +
    '</div><h2>' + escHtml_(doc.title) + '</h2><div>' + escHtml_(doc.subtitle) + '</div></div>';
  if (doc.warning) h += '<p class="warn">' + escHtml_(doc.warning) + '</p>';
  doc.sections.forEach(function (s) {
    if (s.heading) h += '<h2>' + escHtml_(s.heading) + '</h2>';
    h += '<table><tr>' + s.columns.map(function (c) { return '<th' + (c[1] === 'money' ? ' class="m"' : '') + '>' + escHtml_(c[0]) + '</th>'; }).join('') + '</tr>';
    s.rows.forEach(function (r) {
      h += '<tr class="' + escHtml_(r.s) + '">' + r.c.map(function (v, i) {
        var money = s.columns[i] && s.columns[i][1] === 'money';
        return '<td' + (money ? ' class="m"' : '') + '>' + (money && v !== '' ? money_(v) : escHtml_(v)) + '</td>';
      }).join('') + '</tr>';
    });
    h += '</table>';
  });
  h += '<p style="font-size:8pt;color:#666;margin-top:16px">Generated ' + escHtml_(doc.generatedAt) + ' · ' + APP.NAME + '</p></body></html>';
  return h;
}

function reportPdf_(ctx, p) {
  var doc = runReport_(ctx, p);
  var name = (doc.title + ' ' + doc.subtitle).replace(/[^\w\- ]+/g, ' ').replace(/\s+/g, '_').slice(0, 90) + '.pdf';
  var blob = Utilities.newBlob(docHtml_(doc), 'text/html', 'r.html').getAs('application/pdf').setName(name);
  var fileId = '';
  // Saving a copy to Drive is optional, limited to roles with reports.save, and capped per day (protects free Drive space).
  if (p.Save === true) {
    if (!can_(ctx.user, 'reports.save')) fail_('You can download reports, but only the Treasurer or Admin can save copies to Drive.');
    dailyCap_('RPTSAVE', ctx.user.UserID, 30, 'saved reports');
    fileId = folder_('REPORTS').createFile(blob).getId();
  }
  audit_(ctx, 'EXPORT_PDF', 'Report', fileId, { report: p.Report, title: doc.title, saved: !!fileId });
  return { name: name, mimeType: 'application/pdf', data: Utilities.base64Encode(blob.getBytes()), fileId: fileId };
}
