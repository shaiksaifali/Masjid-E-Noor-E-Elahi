/**
 * Code.gs — web app entry point (served free by Google Apps Script HTML Service).
 */

function doGet() {
  var t = HtmlService.createTemplateFromFile('Index');
  var name = 'Masjid-E-Noor-Elahi';
  try { if (props_().getProperty('SPREADSHEET_ID')) name = setting_('MASJID_NAME') || name; } catch (e) { }
  t.appTitle = name;
  t.siteUrl = '';
  try { var su = String(setting_('PUBLIC_SITE_URL') || ''); if (/^https:\/\/script\.google\.com\/(a\/[^\/\s]+\/)?macros\/s\/[\w-]+\/exec$/.test(su)) t.siteUrl = su; } catch (e) { }
  return t.evaluate()
    .setTitle(name)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.DEFAULT); // cannot be embedded in other sites
}

/** Used by <?!= include_('File') ?> in templates. */
function include_(name) {
  return HtmlService.createHtmlOutputFromFile(name).getContent();
}
