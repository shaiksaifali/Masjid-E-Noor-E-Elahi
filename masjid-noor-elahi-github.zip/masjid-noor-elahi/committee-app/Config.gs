/**
 * Config.gs — constants, sheet schemas, roles, default masters.
 * Masjid Management System — zero-cost Google Apps Script edition.
 */

var APP = {
  NAME: 'Masjid Management System',
  VERSION: '1.4.2',
  SCHEMA_VERSION: '3',            // bump when sheet columns change; owner must re-run setup()
  CELL_LIMIT: 10000000,          // Google Sheets per-spreadsheet cell limit
  TRIGGER_MS_PER_DAY: 90 * 60000, // consumer account trigger runtime / day
  EXEC_LIMIT_MS: 6 * 60000        // max runtime of one execution
};

/** Sheet names (the 13 required + 5 accounting sheets needed for Tally-style books). */
var SH = {
  MEMBERS: 'Members',
  PLANS: 'Membership Plans',
  SCHEDULE: 'Payment Schedule',
  COLLECTIONS: 'Membership Collections',
  INCOME: 'Income',
  EXPENSES: 'Expenses',
  ACCOUNTS: 'Cash & Bank Accounts',
  TRANSFERS: 'Account Transfers',
  RECEIPTS: 'Receipts',
  APPROVALS: 'Expense Approvals',
  AUDIT: 'Audit Logs',
  USERS: 'User Roles',
  SETTINGS: 'Settings',
  LEDGERS: 'Ledgers',            // Chart of Accounts (Tally: Ledger masters)
  GL: 'Ledger Entries',          // Double-entry postings (Tally: voucher lines)
  JOURNAL: 'Journal Vouchers',   // Tally: Journal (F7)
  FUNDS: 'Funds',                // Zakat / Sadaqah / General / Construction (Tally: Cost Centres)
  BUDGETS: 'Budgets',            // Tally: Budgets
  JAMAAT: 'Jamaat Times',        // Community: jamaat (iqamah) time rules with effective dates
  ANNOUNCE: 'Announcements',     // Community: notices
  EVENTS: 'Events',              // Community: one-off events, special nights, Eid
  PROGRAMS: 'Programs',          // Community: weekly Dawat / Gasht / Taleem / classes
  JANAZAH: 'Janazah'             // Community: funeral prayer notices
};

var SCHEMA = {};
SCHEMA[SH.MEMBERS] = ['MemberID', 'MemberNo', 'Name', 'Phone', 'Email', 'Address', 'FamilySize', 'PlanID', 'JoinDate', 'Status', 'Notes', 'CreatedAt', 'CreatedBy', 'UpdatedAt', 'UpdatedBy'];
SCHEMA[SH.PLANS] = ['PlanID', 'Name', 'Frequency', 'Amount', 'IncomeLedgerID', 'Description', 'Status', 'CreatedAt', 'CreatedBy', 'UpdatedAt', 'UpdatedBy'];
SCHEMA[SH.SCHEDULE] = ['ScheduleID', 'MemberID', 'PlanID', 'Period', 'DueDate', 'Amount', 'PaidAmount', 'Status', 'LastCollectionID', 'Remarks', 'CreatedAt', 'UpdatedAt', 'UpdatedBy'];
SCHEMA[SH.COLLECTIONS] = ['CollectionID', 'VoucherNo', 'Date', 'MemberID', 'Amount', 'AccountID', 'Mode', 'Reference', 'Allocations', 'ReceiptID', 'ProofFileID', 'Narration', 'Status', 'CreatedAt', 'CreatedBy', 'CancelReason', 'CancelledAt', 'CancelledBy'];
SCHEMA[SH.INCOME] = ['IncomeID', 'VoucherNo', 'Date', 'LedgerID', 'FundID', 'Amount', 'AccountID', 'Mode', 'Reference', 'DonorName', 'DonorPhone', 'Narration', 'ReceiptID', 'ProofFileID', 'Status', 'CreatedAt', 'CreatedBy', 'CancelReason', 'CancelledAt', 'CancelledBy'];
SCHEMA[SH.EXPENSES] = ['ExpenseID', 'VoucherNo', 'Date', 'LedgerID', 'FundID', 'Amount', 'AccountID', 'Mode', 'Reference', 'PayeeName', 'Narration', 'BillFileID', 'NoBillReason', 'Status', 'ApprovalID', 'PostedAt', 'CreatedAt', 'CreatedBy', 'CancelReason', 'CancelledAt', 'CancelledBy', 'CreatedByID'];
SCHEMA[SH.ACCOUNTS] = ['AccountID', 'Name', 'Type', 'BankName', 'AccountNoMasked', 'IFSC', 'OpeningBalance', 'OpeningDate', 'Status', 'CreatedAt', 'CreatedBy', 'UpdatedAt', 'UpdatedBy'];
SCHEMA[SH.TRANSFERS] = ['TransferID', 'VoucherNo', 'Date', 'FromAccountID', 'ToAccountID', 'Amount', 'Mode', 'Reference', 'Narration', 'Status', 'CreatedAt', 'CreatedBy', 'CancelReason', 'CancelledAt', 'CancelledBy', 'ApprovalID', 'CreatedByID'];
SCHEMA[SH.RECEIPTS] = ['ReceiptID', 'ReceiptNo', 'Date', 'SourceType', 'SourceID', 'PartyName', 'PartyPhone', 'Amount', 'AmountWords', 'Purpose', 'Mode', 'PdfFileID', 'Status', 'CreatedAt', 'CreatedBy'];
SCHEMA[SH.APPROVALS] = ['ApprovalID', 'ExpenseID', 'Amount', 'RequestedBy', 'RequestedAt', 'Decision', 'DecidedBy', 'DecidedAt', 'Remarks', 'SourceType', 'RequestedByID'];
SCHEMA[SH.AUDIT] = ['LogID', 'Timestamp', 'UserEmail', 'Role', 'Action', 'Entity', 'EntityID', 'Details'];
SCHEMA[SH.USERS] = ['UserID', 'Email', 'Name', 'Role', 'PasswordHash', 'Salt', 'Status', 'MustChangePassword', 'FailedAttempts', 'LockedUntil', 'LastLogin', 'CreatedAt', 'CreatedBy', 'UpdatedAt', 'UpdatedBy'];
SCHEMA[SH.SETTINGS] = ['Key', 'Value', 'Description', 'UpdatedAt', 'UpdatedBy'];
SCHEMA[SH.LEDGERS] = ['LedgerID', 'Name', 'Group', 'Nature', 'FundID', 'OpeningBalance', 'OpeningType', 'IsSystem', 'Status', 'CreatedAt', 'CreatedBy', 'UpdatedAt', 'UpdatedBy'];
SCHEMA[SH.GL] = ['EntryID', 'Date', 'VoucherType', 'VoucherNo', 'SourceID', 'LedgerID', 'FundID', 'Debit', 'Credit', 'Narration', 'Status', 'ClearedDate', 'CreatedAt', 'CreatedBy'];
SCHEMA[SH.JOURNAL] = ['JournalID', 'VoucherNo', 'Date', 'Lines', 'Total', 'Narration', 'Status', 'CreatedAt', 'CreatedBy', 'CancelReason', 'CancelledAt', 'CancelledBy', 'ApprovalID', 'CreatedByID'];
SCHEMA[SH.FUNDS] = ['FundID', 'Name', 'Type', 'RestrictSpending', 'Description', 'Status', 'CreatedAt', 'CreatedBy'];
SCHEMA[SH.BUDGETS] = ['BudgetID', 'FY', 'LedgerID', 'Amount', 'Notes', 'CreatedAt', 'CreatedBy', 'UpdatedAt', 'UpdatedBy'];

SCHEMA[SH.JAMAAT] = ['RuleID', 'Prayer', 'Mode', 'Time', 'OffsetMin', 'EffectiveFrom', 'Notes', 'Status', 'CreatedAt', 'CreatedBy', 'UpdatedAt', 'UpdatedBy'];
SCHEMA[SH.ANNOUNCE] = ['AnnID', 'Title', 'TitleUr', 'Body', 'BodyUr', 'Priority', 'StartDate', 'EndDate', 'Status', 'CreatedAt', 'CreatedBy', 'UpdatedAt', 'UpdatedBy'];
SCHEMA[SH.EVENTS] = ['EventID', 'Category', 'Title', 'TitleUr', 'Description', 'DescriptionUr', 'Date', 'StartTime', 'EndTime', 'Venue', 'Status', 'CalendarEventID', 'CreatedAt', 'CreatedBy', 'UpdatedAt', 'UpdatedBy'];
SCHEMA[SH.PROGRAMS] = ['ProgramID', 'Category', 'Title', 'TitleUr', 'Days', 'TimeMode', 'Time', 'AfterPrayer', 'DurationMin', 'Venue', 'Contact', 'Description', 'DescriptionUr', 'StartDate', 'EndDate', 'Status', 'CalendarEventID', 'CreatedAt', 'CreatedBy', 'UpdatedAt', 'UpdatedBy'];
SCHEMA[SH.JANAZAH] = ['JanazahID', 'DeceasedName', 'DeceasedNameUr', 'Details', 'Date', 'TimeMode', 'Time', 'AfterPrayer', 'Venue', 'BurialPlace', 'Status', 'CalendarEventID', 'CreatedAt', 'CreatedBy', 'UpdatedAt', 'UpdatedBy'];

/** Columns stored as numbers. Every other column is formatted as plain text ('@'),
 *  so user input is never interpreted as a formula or auto-converted to a date. */
var NUMERIC_COLS = { Amount: 1, PaidAmount: 1, OpeningBalance: 1, Debit: 1, Credit: 1, Total: 1, FamilySize: 1, FailedAttempts: 1, OffsetMin: 1, DurationMin: 1 };

/** Small master tables cached in CacheService to save Sheets reads. */
var CACHED_TABLES = [SH.SETTINGS, SH.LEDGERS, SH.ACCOUNTS, SH.FUNDS, SH.PLANS, SH.USERS];

/** Tally-style account groups for a non-profit (Income & Expenditure basis). */
var GROUPS = {
  'Cash-in-Hand': 'Asset',
  'Bank Accounts': 'Asset',
  'Fixed Assets': 'Asset',
  'Investments & Deposits': 'Asset',
  'Loans & Advances (Asset)': 'Asset',
  'Sundry Debtors': 'Asset',
  'Corpus / Capital Fund': 'Liability',
  'Earmarked Funds': 'Liability',
  'Current Liabilities': 'Liability',
  'Sundry Creditors': 'Liability',
  'Loans (Liability)': 'Liability',
  'Donations & Contributions': 'Income',
  'Membership Income': 'Income',
  'Other Income': 'Income',
  'Salaries & Honorarium': 'Expense',
  'Utilities': 'Expense',
  'Repairs & Maintenance': 'Expense',
  'Charity & Welfare': 'Expense',
  'Event & Program Expenses': 'Expense',
  'Administrative Expenses': 'Expense'
};
var CASH_GROUPS = ['Cash-in-Hand', 'Bank Accounts'];
var FUND_GROUPS = ['Corpus / Capital Fund', 'Earmarked Funds'];
var NATURES = ['Asset', 'Liability', 'Income', 'Expense'];
var GEN_FUND = 'FND-GEN';
var CORPUS = 'LED-CORPUS';

var DEFAULT_FUNDS = [
  ['FND-GEN', 'General Fund', 'Unrestricted', 'NO', 'Day-to-day masjid operations'],
  ['FND-ZAKAT', 'Zakat Fund', 'Restricted', 'YES', 'Zakat — spend only on eligible recipients'],
  ['FND-SADAQAH', 'Sadaqah Fund', 'Restricted', 'YES', 'Sadaqah / charity for the needy'],
  ['FND-CONST', 'Construction Fund', 'Restricted', 'YES', 'Building & construction donations'],
  ['FND-RAMADAN', 'Ramadan Fund', 'Restricted', 'NO', 'Iftar, Taraweeh and Ramadan programs']
];

/** [LedgerID, Name, Group, FundID] */
var DEFAULT_LEDGERS = [
  [CORPUS, 'General Fund (Corpus)', 'Corpus / Capital Fund', 'FND-GEN'],
  ['LED-D01', 'Membership Fees', 'Membership Income', 'FND-GEN'],
  ['LED-D02', 'Jumu\'ah Collection', 'Donations & Contributions', 'FND-GEN'],
  ['LED-D03', 'General Donations', 'Donations & Contributions', 'FND-GEN'],
  ['LED-D04', 'Zakat Received', 'Donations & Contributions', 'FND-ZAKAT'],
  ['LED-D05', 'Sadaqah Received', 'Donations & Contributions', 'FND-SADAQAH'],
  ['LED-D06', 'Construction Donations', 'Donations & Contributions', 'FND-CONST'],
  ['LED-D07', 'Ramadan / Iftar Contributions', 'Donations & Contributions', 'FND-RAMADAN'],
  ['LED-D08', 'Rent Income', 'Other Income', 'FND-GEN'],
  ['LED-D09', 'Bank Interest', 'Other Income', 'FND-GEN'],
  ['LED-D20', 'Imam Salary', 'Salaries & Honorarium', 'FND-GEN'],
  ['LED-D21', 'Muezzin Salary', 'Salaries & Honorarium', 'FND-GEN'],
  ['LED-D22', 'Staff / Khadim Salary', 'Salaries & Honorarium', 'FND-GEN'],
  ['LED-D23', 'Electricity', 'Utilities', 'FND-GEN'],
  ['LED-D24', 'Water', 'Utilities', 'FND-GEN'],
  ['LED-D25', 'Repairs & Maintenance', 'Repairs & Maintenance', 'FND-GEN'],
  ['LED-D26', 'Cleaning & Sanitation', 'Repairs & Maintenance', 'FND-GEN'],
  ['LED-D27', 'Zakat Disbursement', 'Charity & Welfare', 'FND-ZAKAT'],
  ['LED-D28', 'Sadaqah / Welfare Disbursement', 'Charity & Welfare', 'FND-SADAQAH'],
  ['LED-D29', 'Iftar & Ramadan Expenses', 'Event & Program Expenses', 'FND-RAMADAN'],
  ['LED-D30', 'Construction Expenses', 'Repairs & Maintenance', 'FND-CONST'],
  ['LED-D31', 'Stationery & Printing', 'Administrative Expenses', 'FND-GEN'],
  ['LED-D32', 'Bank Charges', 'Administrative Expenses', 'FND-GEN'],
  ['LED-D33', 'Miscellaneous Expenses', 'Administrative Expenses', 'FND-GEN'],
  ['LED-D40', 'Furniture & Fixtures', 'Fixed Assets', 'FND-GEN'],
  ['LED-D41', 'Advances to Staff', 'Loans & Advances (Asset)', 'FND-GEN'],
  ['LED-D42', 'Outstanding Expenses', 'Current Liabilities', 'FND-GEN']
];

/** [Key, Default, Description, Type] — type drives server-side validation. */
var DEFAULT_SETTINGS = [
  ['MASJID_NAME', 'Masjid-E-Noor-Elahi', 'Name printed on receipts and reports', 'text'],
  ['MASJID_ADDRESS', '', 'Address printed on receipts', 'text'],
  ['MASJID_PHONE', '', 'Contact phone', 'text'],
  ['MASJID_EMAIL', '', 'Contact email', 'text'],
  ['REG_NO', '', 'Trust / Waqf registration number', 'text'],
  ['TAX_EXEMPTION_NOTE', '', 'e.g. 80G registration text (leave blank if not applicable)', 'text'],
  ['FY_START_MONTH', '4', 'Financial year start month (4 = April)', 'month'],
  ['BOOKS_BEGIN_DATE', '', 'Date opening balances are posted on (YYYY-MM-DD)', 'date'],
  ['LOCK_DATE', '', 'Books locked up to this date (no entry/cancel on or before it)', 'date'],
  ['BACKDATE_DAYS', '30', 'Max days a non-admin may back-date a voucher', 'int'],
  ['APPROVAL_THRESHOLD', '5000', 'Payments at or above this amount need approval (0 = all)', 'money'],
  ['BILL_REQUIRED_ABOVE', '1000', 'Payments above this need a bill upload or a reason', 'money'],
  ['ALLOW_SELF_APPROVAL', 'NO', 'Allow the person who entered a payment/contra to approve it (never for journals)', 'yesno'],
  ['ADMIN_SELF_APPROVE', 'YES', 'Admins may approve their own payments, contras and journals (always logged and shown to Trustees/Auditors)', 'yesno'],
  ['SELF_APPROVE_ALERT', 'NO', 'Show a red alert on dashboards when an Admin approved his own entry (it is always kept in Approvals › History and the Audit Log)', 'yesno'],
  ['ALLOW_NEGATIVE_CASH', 'NO', 'Allow cash/bank balance to go below zero', 'yesno'],
  ['ENFORCE_FUND_BALANCE', 'YES', 'Block any fund from spending more money than it holds (protects Zakat etc.)', 'yesno'],
  ['DUE_DAY', '10', 'Day of month membership dues fall due', 'int'],
  ['AUTO_GENERATE_DUES', 'YES', 'Generate membership dues automatically on the 1st of each month', 'yesno'],
  ['RECEIPT_FOOTER', 'JazakAllahu Khairan for your contribution.', 'Footer text on receipts', 'text'],
  ['WHATSAPP_COUNTRY_CODE', '91', 'Country code for WhatsApp share links', 'int'],
  ['EMAIL_RECEIPTS', 'NO', 'Allow emailing receipts (uses the free daily email quota)', 'yesno'],
  ['MAX_UPLOAD_MB', '5', 'Maximum upload size in MB', 'int'],
  ['BACKUP_KEEP', '30', 'Number of daily backups to keep', 'int'],
  ['QUOTA_WARN_PCT', '80', 'Warn when a quota reaches this percentage', 'int'],
  ['SESSION_HOURS', '6', 'Login session length in hours (max 6)', 'int'],
  // ---- Community website (group 'community': editable by the Community Manager) ----
  ['MASJID_NAME_UR', 'مسجد نور الٰہی', 'Masjid name in Urdu', 'text', 'community'],
  ['LATITUDE', '', 'Masjid latitude (e.g. 17.385044)', 'coord', 'community'],
  ['LONGITUDE', '', 'Masjid longitude (e.g. 78.486671)', 'coord', 'community'],
  ['MAPS_LINK', '', 'Google Maps link to the masjid', 'url', 'community'],
  ['ASR_METHOD', 'Hanafi', 'Asr calculation (Hanafi / Shafi)', 'asr', 'community'],
  ['FAJR_ANGLE', '18', 'Fajr angle — Karachi method = 18', 'angle', 'community'],
  ['ISHA_ANGLE', '18', 'Isha angle — Karachi method = 18', 'angle', 'community'],
  ['HIJRI_ADJUST', '0', 'Hijri date adjustment for local moon sighting (-2 to +2 days)', 'signed', 'community'],
  ['JUMUAH_AZAN_TIME', '12:45', 'Jumu\'ah Azan time (24-hour, e.g. 12:45)', 'time', 'community'],
  ['JUMUAH_KHUTBAH_TIME', '13:15', 'Jumu\'ah Khutbah time', 'time', 'community'],
  ['JUMUAH_JAMAAT_TIME', '13:30', 'Jumu\'ah Jamaat time', 'time', 'community'],
  ['RAMADAN_START', '', 'First Roza date (set after moon sighting)', 'cdate', 'community'],
  ['RAMADAN_DAYS', '30', 'Number of Rozas (29 or 30)', 'int', 'community'],
  ['SEHRI_SAFETY_MIN', '0', 'Show Sehri ending this many minutes before Fajr', 'int', 'community'],
  ['IFTAR_SAFETY_MIN', '0', 'Show Iftar this many minutes after sunset', 'int', 'community'],
  ['TARAWEEH_INFO', 'After Isha Jamaat', 'Taraweeh timing / details', 'text', 'community'],
  ['RAMADAN_NOTE', '', 'Ramadan notes (Itikaf, Iftar arrangements, Laylatul Qadr programme)', 'text', 'community'],
  ['EID_FITR_DATE', '', 'Eid-ul-Fitr date', 'cdate', 'community'],
  ['EID_FITR_TIME', '', 'Eid-ul-Fitr Salah time', 'time', 'community'],
  ['EID_ADHA_DATE', '', 'Eid-ul-Adha date', 'cdate', 'community'],
  ['EID_ADHA_TIME', '', 'Eid-ul-Adha Salah time', 'time', 'community'],
  ['EID_VENUE', '', 'Eid Salah venue', 'text', 'community'],
  ['UPI_ID', '', 'UPI ID for donations (e.g. masjid@sbi)', 'upi', 'community'],
  ['UPI_PAYEE_NAME', '', 'Account name shown in UPI apps', 'text', 'community'],
  ['DONATE_NOTE', '', 'Bank details / donation note shown publicly', 'text', 'community'],
  ['WHATSAPP_LINK', '', 'Masjid WhatsApp group or channel link', 'url', 'community'],
  ['PUBLIC_CONTACTS', '', 'Public contacts (e.g. Imam Sahab – 98xxxxxx)', 'text', 'community'],
  ['FACILITIES', '', 'Facilities (wudu area, ladies section, parking…)', 'text', 'community'],
  ['ABOUT_TEXT', '', 'About the masjid (English)', 'text', 'community'],
  ['ABOUT_TEXT_UR', '', 'About the masjid (Urdu)', 'text', 'community'],
  ['PUBLIC_SITE_URL', '', 'Community website URL (after deploying it)', 'url', 'community'],
  ['ADMIN_APP_URL', '', 'Committee app URL for the website\'s "Committee login" button (blank = detected automatically)', 'url', 'community'],
  ['SHOW_COMMITTEE_LOGIN', 'YES', 'Show a "Committee login" button on the website', 'yesno', 'community'],
  ['FORMS_ENABLED', 'YES', 'Accept requests (Nikah / booking / volunteer / queries) on the website', 'yesno', 'community']
];

/** Role-based access control. Checked on the SERVER for every action. */
var ROLES = {
  ADMIN: ['*'],
  TREASURER: ['dashboard', 'dashboard.finance', 'members.view', 'members.contacts', 'members.edit', 'plans.edit', 'schedule.generate',
    'collection.create', 'income.create', 'expense.create', 'transfer.create', 'journal.create',
    'vouchers.view', 'masters.edit', 'reports.view', 'reports.save', 'receipts.view', 'receipts.send', 'files.view', 'brs.edit'],
  APPROVER: ['dashboard', 'dashboard.finance', 'members.view', 'members.contacts', 'vouchers.view', 'expense.approve', 'reports.view',
    'receipts.view', 'files.view', 'audit.view'],
  COLLECTOR: ['dashboard', 'members.view', 'collection.create', 'income.create', 'receipts.view', 'receipts.send', 'vouchers.own'],
  COMMUNITY: ['community.edit', 'community.requests'],
  AUDITOR: ['dashboard', 'dashboard.finance', 'members.view', 'members.contacts', 'vouchers.view', 'reports.view', 'receipts.view',
    'files.view', 'audit.view']
};
var ROLE_LABELS = {
  ADMIN: 'Admin (full access)',
  TREASURER: 'Treasurer / Accountant',
  APPROVER: 'Trustee / Approver',
  COLLECTOR: 'Collector',
  AUDITOR: 'Auditor (read-only)',
  COMMUNITY: 'Community Manager (Imam / Secretary)'
};

var PRAYERS = ['Fajr', 'Zuhr', 'Asr', 'Maghrib', 'Isha'];
var EVENT_CATEGORIES = ['Event', 'Special Night', 'Ijtema', 'Class / Course', 'Eid', 'Ramadan', 'Meeting', 'Other'];
var PROGRAM_CATEGORIES = ['Dawat', 'Gasht', 'Taleem', 'Bayan', 'Mashwara', 'Dars-e-Quran', 'Maktab / Madrasa', 'Women\'s Programme', 'Youth', 'Other'];
var WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

var PAY_MODES = ['Cash', 'UPI', 'Bank Transfer', 'Cheque', 'Card', 'Other'];
var FREQUENCIES = ['Monthly', 'Quarterly', 'Half-Yearly', 'Yearly'];

var FOLDERS = {
  BILLS: 'Expense Bills',
  PROOFS: 'Payment Proofs',
  RECEIPTS: 'Receipts',
  REPORTS: 'Financial Reports',
  BACKUPS: 'Backups',
  COMMUNITY: 'Community Website'
};
