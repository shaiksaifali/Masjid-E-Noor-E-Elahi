/**
 * System.gs — backups to Google Drive, quota monitoring, audit-log viewer, scheduled jobs.
 */

/* ---------------- Backups ---------------- */

function backupNow_(ctx) {
  var ss = ss_();
  var name = 'Backup_' + Utilities.formatDate(new Date(), tz_(), 'yyyy-MM-dd_HHmm');
  var copy = DriveApp.getFileById(ss.getId()).makeCopy(name, folder_('BACKUPS'));
  props_().setProperties({ LAST_BACKUP: nowStr_(), LAST_BACKUP_MS: String(Date.now()) });
  var pruned = pruneBackups_();
  if (ctx) audit_(ctx, 'BACKUP', 'System', copy.getId(), { name: name, oldCopiesMovedToTrash: pruned });
  return { id: copy.getId(), name: name, pruned: pruned };
}

/** Keeps the newest N backup copies; older COPIES go to Drive trash (live data is never touched). */
function pruneBackups_() {
  var keep = Math.max(3, parseInt(setting_('BACKUP_KEEP'), 10) || 30);
  var files = [], it = folder_('BACKUPS').getFiles();
  while (it.hasNext()) { var f = it.next(); files.push({ f: f, t: f.getDateCreated().getTime() }); }
  files.sort(function (a, b) { return b.t - a.t; });
  var n = 0;
  files.slice(keep).forEach(function (x) { x.f.setTrashed(true); n++; });
  return n;
}

function listBackups_(ctx) {
  var out = [], it = folder_('BACKUPS').getFiles();
  while (it.hasNext()) { var f = it.next(); out.push({ id: f.getId(), name: f.getName(), created: fmtTs_(f.getDateCreated().getTime()) }); }
  out.sort(function (a, b) { return a.created < b.created ? 1 : -1; });
  return { backups: out.slice(0, 60), last: props_().getProperty('LAST_BACKUP') || '' };
}

/* ---------------- Quota monitoring ---------------- */

function trackUsage_(ms) {
  try {
    var c = CacheService.getScriptCache(), k = 'USE_' + today_();
    var u = JSON.parse(c.get(k) || '{"n":0,"ms":0,"max":0}');
    u.n++; u.ms += ms; if (ms > u.max) u.max = ms;
    c.put(k, JSON.stringify(u), 21600);
  } catch (e) { /* never block a request for metrics */ }
}

function trackTrigger_(ms) {
  var p = props_(), k = 'TRIG_MS_' + today_().replace(/-/g, '');
  p.setProperty(k, String(num_(p.getProperty(k)) + ms));
}

function systemStatus_(ctx, force) {
  var cache = CacheService.getScriptCache();
  if (!force) { var hit = cache.get('QUOTA'); if (hit) return JSON.parse(hit); }
  var warnPct = num_(setting_('QUOTA_WARN_PCT')) || 80, warnings = [];
  var st = { checkedAt: nowStr_() };

  try {
    var used = DriveApp.getStorageUsed(), limit = DriveApp.getStorageLimit();
    st.drive = { used: used, limit: limit, pct: limit ? Math.round(used / limit * 1000) / 10 : 0 };
    if (st.drive.pct >= warnPct) warnings.push('Google Drive storage is ' + st.drive.pct + '% full. Clear old files from the owner\'s Drive/Gmail/Photos or export old reports.');
  } catch (e) { st.drive = { error: cleanErr_(e) }; }

  var cells = 0, sheets = [];
  ss_().getSheets().forEach(function (s) {
    var c = s.getMaxRows() * s.getMaxColumns(); cells += c;
    sheets.push({ name: s.getName(), rows: Math.max(0, s.getLastRow() - 1), cells: c });
  });
  st.cells = { used: cells, limit: APP.CELL_LIMIT, pct: Math.round(cells / APP.CELL_LIMIT * 1000) / 10, sheets: sheets };
  if (st.cells.pct >= warnPct) warnings.push('Spreadsheet is at ' + st.cells.pct + '% of the 10 million cell limit. Archive old financial years (see README).');

  try { st.mail = { remaining: MailApp.getRemainingDailyQuota() }; } catch (e) { st.mail = { remaining: null }; }
  if (st.mail.remaining !== null && st.mail.remaining < 10 && yes_(setting_('EMAIL_RECEIPTS'))) warnings.push('Only ' + st.mail.remaining + ' free emails left today.');

  var u = JSON.parse(cache.get('USE_' + today_()) || '{"n":0,"ms":0,"max":0}');
  st.usage = { calls: u.n, avgMs: u.n ? Math.round(u.ms / u.n) : 0, maxMs: u.max };
  if (u.max > APP.EXEC_LIMIT_MS * warnPct / 100) warnings.push('A request took ' + Math.round(u.max / 1000) + 's — close to the 6-minute limit. Consider archiving old data.');

  var tms = num_(props_().getProperty('TRIG_MS_' + today_().replace(/-/g, '')));
  st.triggers = { ms: tms, limit: APP.TRIGGER_MS_PER_DAY, pct: Math.round(tms / APP.TRIGGER_MS_PER_DAY * 1000) / 10 };
  if (st.triggers.pct >= warnPct) warnings.push('Scheduled jobs used ' + st.triggers.pct + '% of the daily trigger runtime.');

  var propsSize = JSON.stringify(props_().getProperties()).length;
  st.properties = { bytes: propsSize, limit: 500 * 1024, pct: Math.round(propsSize / (500 * 1024) * 1000) / 10 };
  if (st.properties.pct >= warnPct) warnings.push('Script Properties storage is ' + st.properties.pct + '% full.');

  var unlock = props_().getProperty('LAST_UNLOCK');
  if (unlock) { try { var u2 = JSON.parse(unlock); if (daysBetween_(u2.at.slice(0, 10), today_()) <= 30) warnings.push('Books were unlocked by ' + u2.by + ' on ' + u2.at + ' (lock date ' + u2.from + ' → ' + u2.to + ').'); } catch (e) { } }
  var gl = sheets.filter(function (s) { return s.name === SH.GL; })[0];
  if (gl && gl.rows > 40000) warnings.push('Ledger Entries has ' + gl.rows + ' rows; reports may slow down. Archive old years.');

  st.lastBackup = props_().getProperty('LAST_BACKUP') || '';
  if (!st.lastBackup || daysBetween_(st.lastBackup.slice(0, 10), today_()) > 2) warnings.push('No backup in the last 2 days. Use "Backup now" on the System page.');

  st.warnings = warnings;
  try { cache.put('QUOTA', JSON.stringify(st), 3600); } catch (e) { }
  return st;
}

function quotaWarnings_() {
  try { return systemStatus_(null, false).warnings; } catch (e) { return []; }
}

/* ---------------- Audit log viewer ---------------- */

function listAudit_(ctx, p) {
  var q = String(p.Query || '').toLowerCase().slice(0, 100);
  var rows = readTail_(SH.AUDIT, 3000).reverse();
  if (q) rows = rows.filter(function (r) {
    return (r.UserEmail + ' ' + r.Action + ' ' + r.Entity + ' ' + r.EntityID + ' ' + r.Details).toLowerCase().indexOf(q) >= 0;
  });
  return rows.slice(0, 500).map(strip_);
}

/* ---------------- Scheduled jobs (free time-driven triggers) ---------------- */

function systemCtx_() {
  return { now: nowStr_(), audit: [], user: { Email: 'system@scheduler', Role: 'ADMIN', UserID: 'SYSTEM' } };
}

/** Scheduled jobs run only when Google's trigger service calls them (event carries a real trigger ID).
 *  Called from a browser via google.script.run, they refuse to do anything. */
function fromTrigger_(e) {
  var id = e && e.triggerUid ? String(e.triggerUid) : '';
  if (!id) return false;
  return ScriptApp.getProjectTriggers().some(function (t) { return String(t.getUniqueId()) === id; });
}

/** Daily 2 AM backup. */
function dailyBackupTrigger(e) {
  if (!fromTrigger_(e)) return 'Refused: scheduled job.';
  var t0 = Date.now();
  var last = num_(props_().getProperty('LAST_BACKUP_MS'));
  if (last && Date.now() - last < 20 * 3600000) return 'Skipped: recent backup exists.';
  return withLock_(function () {
    var ctx = systemCtx_();
    var r = backupNow_(ctx);
    try { publishPublic_(ctx); } catch (e) { console.warn('nightly publish: ' + e); } // roll date windows forward
    flushAudit_(ctx);
    trackTrigger_(Date.now() - t0);
    return r.name;
  });
}

/** 1st of every month: generate membership dues. Idempotent. */
function monthlyDuesTrigger(e) {
  if (!fromTrigger_(e)) return 'Refused: scheduled job.';
  var t0 = Date.now();
  if (!yes_(setting_('AUTO_GENERATE_DUES'))) return 'Disabled';
  return withLock_(function () {
    var ctx = systemCtx_();
    var r = generateSchedule_(ctx, { Month: today_().slice(0, 7) });
    flushAudit_(ctx);
    CacheService.getScriptCache().remove('DASH');
    trackTrigger_(Date.now() - t0);
    return r.created + ' dues created';
  });
}
