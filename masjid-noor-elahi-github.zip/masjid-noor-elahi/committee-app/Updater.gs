/**
 * Updater.gs — update the app and the website WITHOUT installing anything.
 *
 * How it works (free, uses only Google's own Apps Script API):
 *   1. Put the update file(s) you receive in your Google Drive (any folder):
 *        masjid-committee-app.json   → updates THIS project (the committee app)
 *        masjid-website.json         → updates the community website project
 *   2. In this editor choose the function  updateEverything  (or one of the two below) and click Run.
 *   3. The code is replaced, a new version is created and your existing web-app links are moved to it.
 *      The links (URLs) do not change. Your data in Google Sheets/Drive is never touched.
 *
 * One-time setup:
 *   - Turn ON "Google Apps Script API":  https://script.google.com/home/usersettings
 *   - For the website: Project Settings (gear) › Script properties › Add property
 *        WEBSITE_SCRIPT_ID  =  the website project's Script ID
 *     (open the "Public Website Data" sheet › Extensions › Apps Script › Project Settings › Script ID)
 *
 * Only the owner can run these, from the editor (they refuse when called from the web app).
 */

var UPD_ = {
  APP_FILE: 'masjid-committee-app.json',
  SITE_FILE: 'masjid-website.json',
  API: 'https://script.googleapis.com/v1/projects/'
};

function updateEverything() {
  assertOwner_();
  var out = [];
  var siteId = PropertiesService.getScriptProperties().getProperty('WEBSITE_SCRIPT_ID');
  if (siteId && latestDriveFile_(UPD_.SITE_FILE)) out.push(updateWebsite());
  else out.push('Website: skipped (' + (siteId ? 'no ' + UPD_.SITE_FILE + ' in Drive' : 'WEBSITE_SCRIPT_ID not set in Script properties') + ').');
  if (latestDriveFile_(UPD_.APP_FILE)) out.push(updateCommitteeApp());
  else out.push('Committee app: skipped (no ' + UPD_.APP_FILE + ' in Drive).');
  Logger.log(out.join('\n'));
  return out.join('\n');
}

function updateCommitteeApp() {
  assertOwner_();
  var msg = pushBundle_(ScriptApp.getScriptId(), UPD_.APP_FILE, 'committee');
  Logger.log(msg);
  return msg;
}

function updateWebsite() {
  assertOwner_();
  var id = String(PropertiesService.getScriptProperties().getProperty('WEBSITE_SCRIPT_ID') || '').trim();
  if (!/^[\w-]{20,}$/.test(id)) throw new Error('Set the Script property WEBSITE_SCRIPT_ID first (Project Settings › Script properties).');
  if (id === ScriptApp.getScriptId()) throw new Error('WEBSITE_SCRIPT_ID is this committee project. Use the website project\'s Script ID.');
  var msg = pushBundle_(id, UPD_.SITE_FILE, 'website');
  Logger.log(msg);
  return msg;
}

function latestDriveFile_(name) {
  var it = DriveApp.getFilesByName(name), best = null;
  while (it.hasNext()) {
    var f = it.next();
    if (f.isTrashed()) continue;
    if (f.getOwner() && f.getOwner().getEmail() !== Session.getEffectiveUser().getEmail()) continue; // only your own files
    if (!best || f.getLastUpdated() > best.getLastUpdated()) best = f;
  }
  return best;
}

function pushBundle_(scriptId, fileName, kind) {
  var f = latestDriveFile_(fileName);
  if (!f) throw new Error('Upload ' + fileName + ' to your Google Drive first.');
  var b;
  try { b = JSON.parse(f.getBlob().getDataAsString('UTF-8')); } catch (e) { throw new Error(fileName + ' is not a valid update file.'); }
  if (!b || b.kind !== kind || !Array.isArray(b.files) || !b.files.length) throw new Error(fileName + ' is not a ' + kind + ' update file.');
  var names = {};
  b.files.forEach(function (x) {
    if (!x || !/^[A-Za-z][\w-]{0,60}$/.test(x.name) || ['SERVER_JS', 'HTML', 'JSON'].indexOf(x.type) < 0 || typeof x.source !== 'string')
      throw new Error('Bad file entry in ' + fileName + '.');
    if (x.type === 'JSON' && x.name !== 'appsscript') throw new Error('Bad manifest in ' + fileName + '.');
    names[x.name + '.' + x.type] = 1;
  });
  if (!names['appsscript.JSON']) throw new Error(fileName + ' has no manifest.');

  var token = ScriptApp.getOAuthToken();
  function call(method, path, body) {
    var r = UrlFetchApp.fetch(UPD_.API + scriptId + path, {
      method: method, contentType: 'application/json', muteHttpExceptions: true,
      headers: { Authorization: 'Bearer ' + token }, payload: body ? JSON.stringify(body) : undefined
    });
    var code = r.getResponseCode(), txt = r.getContentText();
    if (code >= 300) {
      if (/has not been used|is disabled|SERVICE_DISABLED|User has not enabled/i.test(txt))
        throw new Error('Turn ON "Google Apps Script API" at https://script.google.com/home/usersettings, wait 2 minutes, then Run again.');
      throw new Error('Apps Script API ' + code + ': ' + txt.slice(0, 300));
    }
    return txt ? JSON.parse(txt) : {};
  }

  var label = 'v' + (b.version || '?') + ' ' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm');
  call('put', '/content', { files: b.files.map(function (x) { return { name: x.name, type: x.type, source: x.source }; }) });
  var ver = call('post', '/versions', { description: 'Update ' + label });
  var deps = (call('get', '/deployments').deployments || []).filter(function (d) { return d.deploymentConfig && d.deploymentConfig.versionNumber; });
  deps.forEach(function (d) {
    call('put', '/deployments/' + d.deploymentId, { deploymentConfig: {
      scriptId: scriptId, versionNumber: ver.versionNumber, manifestFileName: 'appsscript',
      description: d.deploymentConfig.description || ('Masjid ' + kind) } });
  });
  return (kind === 'committee' ? 'Committee app' : 'Website') + ' updated to ' + label + ' — ' + b.files.length + ' files, version ' + ver.versionNumber +
    ', ' + deps.length + ' web link(s) moved to the new version. ' + (deps.length ? '' : 'No deployment found: use Deploy › New deployment once.');
}
