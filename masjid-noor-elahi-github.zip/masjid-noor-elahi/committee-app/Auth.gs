/**
 * Auth.gs — application login, sessions and role-based access control.
 *
 * Why app-level login: the web app runs "as the owner" so the spreadsheet and Drive folder
 * stay private to the owner. With free @gmail.com accounts, Apps Script cannot reliably tell
 * the visitor's email in that mode, so each committee member gets their own app password
 * (salted, iterated HMAC-SHA256 hash). Sessions live in CacheService (max 6 hours).
 */

var HASH_ROUNDS_LEGACY = 400;
var HASH_ROUNDS = 2500;            // v2 hashes; older hashes are upgraded automatically at next login
var SESSION_ABS_MAX_MS = 12 * 3600000; // a session can never live longer than 12 h, even if active
var LOGIN_MAX_FAILS = 5;
var LOGIN_PAUSE_MS = 10 * 60000;

function hmacRounds_(pw, salt, rounds) {
  var key = Utilities.newBlob(String(salt)).getBytes();
  var b = Utilities.computeHmacSha256Signature(Utilities.newBlob(String(pw)).getBytes(), key);
  for (var i = 0; i < rounds; i++) b = Utilities.computeHmacSha256Signature(b, key);
  return Utilities.base64Encode(b);
}
/** Stored format: v2$<rounds>$<base64>. */
function hashPw_(pw, salt) { return 'v2$' + HASH_ROUNDS + '$' + hmacRounds_(pw, salt, HASH_ROUNDS); }
function verifyPw_(pw, salt, stored) {
  stored = String(stored || '');
  var m = /^v2\$(\d+)\$(.+)$/.exec(stored);
  if (m) return constEq_(hmacRounds_(pw, salt, +m[1]), m[2]);
  return constEq_(hmacRounds_(pw, salt, HASH_ROUNDS_LEGACY), stored);
}
function needsRehash_(stored) { return String(stored).indexOf('v2$' + HASH_ROUNDS + '$') !== 0; }
/** Short fingerprint of the hash used to invalidate sessions when a password changes. */
function pwFp_(h) { h = String(h || ''); return h.length <= 16 ? h : h.slice(-16); }
function newSalt_() { return Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, ''); }

function checkPasswordPolicy_(pw, email) {
  pw = String(pw || '');
  if (pw.length < 10) fail_('Password must be at least 10 characters.');
  if (pw.length > 100) fail_('Password is too long.');
  if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) fail_('Password must contain letters and numbers.');
  var low = pw.toLowerCase();
  if (/(password|masjid|admin|12345|qwerty|noor|elahi|allah)/.test(low)) fail_('Password is too easy to guess. Avoid common words.');
  var local = email ? String(email).split('@')[0].toLowerCase() : '';
  if (local.length >= 4 && low.indexOf(local) >= 0) fail_('Password must not contain your email name.');
}

function sessionTtl_() {
  var h = parseInt(setting_('SESSION_HOURS'), 10);
  if (!(h >= 1 && h <= 6)) h = 6;
  return h * 3600;
}

function userByEmail_(email) {
  email = String(email || '').toLowerCase();
  return read_(SH.USERS).filter(function (u) { return String(u.Email).toLowerCase() === email; })[0] || null;
}

var LOGIN_FAIL_MSG = 'Sign-in failed. Check your email and password. After ' + LOGIN_MAX_FAILS +
  ' wrong attempts, sign-in for that account pauses for 10 minutes.';

/** PUBLIC: called from the login screen.
 *  - Same message and similar timing for unknown / wrong / disabled / paused accounts (no enumeration).
 *  - Failure counting lives in CacheService, so login never holds the financial write lock. */
function apiLogin(email, password) {
  try {
    email = (typeof email === 'string' ? email : '').trim().toLowerCase();
    password = typeof password === 'string' ? password : '';
    if (!email || !password || email.length > 120 || password.length > 100) fail_(LOGIN_FAIL_MSG);
    var cache = CacheService.getScriptCache(), fkey = lfKey_(email);
    var f = JSON.parse(cache.get(fkey) || '{"n":0,"until":0}');
    var paused = f.until && f.until > Date.now();
    _memo.locked = true; // read users fresh (full hash + salt), never from cache
    var u = userByEmail_(email);
    _memo.locked = false;
    // Always run the KDF so timing does not reveal whether the account exists.
    var ok = verifyPw_(password, u ? u.Salt : 'x'.repeat(64), u ? u.PasswordHash : 'v2$' + HASH_ROUNDS + '$AAAA');
    if (!u || u.Status !== 'Active' || paused || !ok) {
      if (u && !paused && !ok) {
        f.n = (f.n || 0) + 1;
        if (f.n >= LOGIN_MAX_FAILS) {
          f = { n: 0, until: Date.now() + LOGIN_PAUSE_MS };
          logSecurityEvent_(u, 'LOGIN_PAUSED', { reason: LOGIN_MAX_FAILS + ' wrong passwords' });
        }
        cache.put(fkey, JSON.stringify(f), 3600);
      }
      fail_(LOGIN_FAIL_MSG);
    }
    cache.remove(fkey);
    var token = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
    var out = withLock_(function () {
      var cur = findById_(SH.USERS, u.UserID);
      if (needsRehash_(cur.PasswordHash)) { cur.Salt = newSalt_(); cur.PasswordHash = hashPw_(password, cur.Salt); }
      cur.FailedAttempts = 0; cur.LockedUntil = ''; cur.LastLogin = nowStr_();
      update_(SH.USERS, cur);
      var ctx = { now: nowStr_(), audit: [], user: cur };
      audit_(ctx, 'LOGIN', 'User', cur.UserID, {});
      flushAudit_(ctx);
      putSession_(token, { uid: cur.UserID, ph: pwFp_(cur.PasswordHash), r: Date.now(), iat: Date.now() });
      return { token: token, user: publicUser_(cur) };
    }, 10000);
    return out;
  } catch (e) {
    if (!(e && e.userFacing)) console.error('apiLogin: ' + (e && e.stack || e));
    throw new Error(e && e.userFacing ? e.message : LOGIN_FAIL_MSG);
  }
}

function lfKey_(email) {
  return 'LF_' + Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(email).toLowerCase())).slice(0, 40);
}

function logSecurityEvent_(u, action, details) {
  try {
    withLock_(function () {
      var ctx = { now: nowStr_(), audit: [], user: { Email: u.Email, Role: u.Role } };
      audit_(ctx, action, 'User', u.UserID, details || {});
      flushAudit_(ctx);
    }, 3000);
  } catch (e) { /* never block login handling on logging */ }
}

function putSession_(token, s) {
  CacheService.getScriptCache().put('SES_' + token, JSON.stringify(s), sessionTtl_());
}

function publicUser_(u) {
  return { id: u.UserID, email: u.Email, name: u.Name, role: u.Role, roleLabel: ROLE_LABELS[u.Role] || u.Role,
    mustChange: yes_(u.MustChangePassword), perms: ROLES[u.Role] || [] };
}

/** Validates the session token and returns the CURRENT user record (status re-checked every call). */
function requireSession_(token) {
  token = String(token || '');
  if (!/^[a-f0-9]{64}$/.test(token)) fail_('AUTH: Please sign in.');
  var cache = CacheService.getScriptCache(), raw = cache.get('SES_' + token);
  if (!raw) fail_('AUTH: Your session has expired. Please sign in again.');
  var s = JSON.parse(raw);
  var u = findById_(SH.USERS, s.uid);
  if (!u || u.Status !== 'Active') { cache.remove('SES_' + token); fail_('AUTH: Your account is not active.'); }
  if (!constEq_(pwFp_(u.PasswordHash), s.ph)) { cache.remove('SES_' + token); fail_('AUTH: Your password was changed. Please sign in again.'); }
  if (!s.iat || Date.now() - s.iat > SESSION_ABS_MAX_MS) { cache.remove('SES_' + token); fail_('AUTH: Your session has expired. Please sign in again.'); }
  if (Date.now() - s.r > 10 * 60000) { s.r = Date.now(); putSession_(token, s); } // sliding idle expiry (max 12 h total)
  u._token = token;
  return u;
}

function can_(user, perm) {
  var p = ROLES[user.Role] || [];
  return p.indexOf('*') >= 0 || p.indexOf(perm) >= 0;
}
function requirePerm_(user, perm) {
  if (perm === 'self') return;
  if (!can_(user, perm)) fail_('You do not have permission for this action.');
}

function logout_(ctx) {
  CacheService.getScriptCache().remove('SES_' + ctx.user._token);
  audit_(ctx, 'LOGOUT', 'User', ctx.user.UserID, {});
  return true;
}

function changePassword_(ctx, p) {
  var u = findById_(SH.USERS, ctx.user.UserID);
  if (typeof p.oldPassword !== 'string' || typeof p.newPassword !== 'string') fail_('Bad request.');
  if (!verifyPw_(p.oldPassword, u.Salt, u.PasswordHash)) fail_('Current password is incorrect.');
  checkPasswordPolicy_(p.newPassword, u.Email);
  if (p.newPassword === p.oldPassword) fail_('New password must be different.');
  u.Salt = newSalt_();
  u.PasswordHash = hashPw_(p.newPassword, u.Salt);
  u.MustChangePassword = 'NO';
  u.UpdatedAt = ctx.now; u.UpdatedBy = ctx.user.Email;
  update_(SH.USERS, u);
  putSession_(ctx.user._token, { uid: u.UserID, ph: pwFp_(u.PasswordHash), r: Date.now(), iat: Date.now() });
  audit_(ctx, 'PASSWORD_CHANGE', 'User', u.UserID, {});
  return publicUser_(u);
}

/* ---------- User management (ADMIN) ---------- */

function listUsers_(ctx) {
  return read_(SH.USERS).map(function (u) {
    return { UserID: u.UserID, Email: u.Email, Name: u.Name, Role: u.Role, Status: u.Status,
      LastLogin: u.LastLogin, MustChangePassword: u.MustChangePassword, LockedUntil: u.LockedUntil };
  });
}

function activeAdmins_() {
  return read_(SH.USERS).filter(function (u) { return u.Role === 'ADMIN' && u.Status === 'Active'; });
}

function saveUser_(ctx, p) {
  var email = V.email(p.Email, 'Email', true);
  var name = V.str(p.Name, 'Name', { req: true, max: 80 });
  var role = V.oneOf(p.Role, Object.keys(ROLES), 'Role');
  var status = V.oneOf(p.Status || 'Active', ['Active', 'Disabled'], 'Status');
  if (!p.UserID) {
    if (userByEmail_(email)) fail_('A user with this email already exists.');
    var temp = genPassword_(), salt = newSalt_();
    var u = { UserID: newId_('USR'), Email: email, Name: name, Role: role, Salt: salt, PasswordHash: hashPw_(temp, salt),
      Status: status, MustChangePassword: 'YES', FailedAttempts: 0, CreatedAt: ctx.now, CreatedBy: ctx.user.Email };
    append_(SH.USERS, [u]);
    audit_(ctx, 'CREATE', 'User', u.UserID, { email: email, role: role });
    return { user: listUsers_(ctx).filter(function (x) { return x.UserID === u.UserID; })[0], tempPassword: temp };
  }
  var cur = findById_(SH.USERS, p.UserID);
  if (!cur) fail_('User not found.');
  if (cur.UserID === ctx.user.UserID && (role !== 'ADMIN' || status !== 'Active')) fail_('You cannot remove your own Admin access.');
  if (cur.UserID === ctx.user.UserID && email !== String(cur.Email).toLowerCase()) fail_('You cannot change your own login email. Ask another Admin.');
  if (cur.Role === 'ADMIN' && (role !== 'ADMIN' || status !== 'Active') && activeAdmins_().length <= 1) fail_('At least one active Admin is required.');
  var other = userByEmail_(email);
  if (other && other.UserID !== cur.UserID) fail_('Another user already uses this email.');
  var before = pick_(cur, ['Email', 'Name', 'Role', 'Status']);
  cur.Email = email; cur.Name = name; cur.Role = role; cur.Status = status;
  cur.UpdatedAt = ctx.now; cur.UpdatedBy = ctx.user.Email;
  update_(SH.USERS, cur);
  audit_(ctx, 'UPDATE', 'User', cur.UserID, { before: before, after: pick_(cur, ['Email', 'Name', 'Role', 'Status']) });
  return { user: listUsers_(ctx).filter(function (x) { return x.UserID === cur.UserID; })[0] };
}

function resetUserPassword_(ctx, p) {
  var u = findById_(SH.USERS, V.id(p.UserID, 'User'));
  if (!u) fail_('User not found.');
  var temp = genPassword_();
  u.Salt = newSalt_(); u.PasswordHash = hashPw_(temp, u.Salt);
  u.MustChangePassword = 'YES'; u.FailedAttempts = 0; u.LockedUntil = '';
  u.UpdatedAt = ctx.now; u.UpdatedBy = ctx.user.Email;
  update_(SH.USERS, u);
  CacheService.getScriptCache().remove(lfKey_(u.Email));
  audit_(ctx, 'PASSWORD_RESET', 'User', u.UserID, {});
  return { tempPassword: temp };
}

/** Guard for owner-only functions that must be run from the Apps Script editor. */
function assertOwner_() {
  var eff = String(Session.getEffectiveUser().getEmail() || '').toLowerCase();
  var act = String(Session.getActiveUser().getEmail() || '').toLowerCase();
  if (!eff || !act || eff !== act) throw new Error('This function can only be run by the script owner from the Apps Script editor.');
}

function cleanErr_(e) {
  var m = (e && e.message) ? e.message : String(e);
  return m.replace(/^(Exception|Error):\s*/i, '');
}

/** Clear a paused sign-in for a user (Admin). */
function unlockUser_(ctx, p) {
  var u = findById_(SH.USERS, V.id(p.UserID, 'User'));
  if (!u) fail_('User not found.');
  CacheService.getScriptCache().remove(lfKey_(u.Email));
  audit_(ctx, 'UNLOCK', 'User', u.UserID, {});
  return true;
}
