/**
 * Community.gs — everything behind the public community website.
 *  - Jamaat time rules (with "effective from" dates), announcements, events, weekly Dawat / programmes, Janazah.
 *  - Publishes a read-only PUBLIC SNAPSHOT to a separate "Public Website Data" spreadsheet.
 *    The public website is a separate Apps Script project bound to that spreadsheet with the
 *    `spreadsheets.currentonly` scope, so it can never open the finance database.
 *  - Keeps a public Google Calendar in sync (free reminders on every subscriber's phone).
 *  - Reads requests (Nikah / booking / volunteer / queries) submitted on the website.
 */

var REQ_HEADERS = ['ReqID', 'SubmittedAt', 'Type', 'Name', 'Phone', 'PreferredDate', 'Message', 'Status', 'HandledBy', 'HandledAt', 'Note'];
var REQ_STATUSES = ['New', 'In progress', 'Done', 'Spam'];

/* ---------------- prayer-time helpers (server) ---------------- */

function tzHours_() {
  var z = Utilities.formatDate(new Date(), tz_(), 'Z'); // e.g. +0530
  var m = /^([+-])(\d{2})(\d{2})$/.exec(z);
  return m ? (m[1] === '-' ? -1 : 1) * (+m[2] + (+m[3]) / 60) : 5.5;
}
function hasLocation_() { return String(setting_('LATITUDE')) !== '' && String(setting_('LONGITUDE')) !== ''; }
function calcOpts_() {
  return { lat: +setting_('LATITUDE'), lng: +setting_('LONGITUDE'), tz: tzHours_(),
    fajrAngle: +setting_('FAJR_ANGLE') || 18, ishaAngle: +setting_('ISHA_ANGLE') || 18,
    asrFactor: setting_('ASR_METHOD') === 'Shafi' ? 1 : 2 };
}
function azanFor_(d) {
  if (!hasLocation_()) return null;
  var p = d.split('-').map(Number);
  return MasjidTimes.compute(p[0], p[1], p[2], calcOpts_());
}
var PRAYER_KEY = { Fajr: 'fajr', Zuhr: 'dhuhr', Asr: 'asr', Maghrib: 'maghrib', Isha: 'isha' };
/** Jamaat minutes for a prayer on a date (latest active rule effective on that date). */
function jamaatFor_(prayer, d) {
  var rules = read_(SH.JAMAAT).filter(function (r) { return r.Status === 'Active' && r.Prayer === prayer && r.EffectiveFrom <= d; })
    .sort(function (a, b) { return a.EffectiveFrom < b.EffectiveFrom ? 1 : a.EffectiveFrom > b.EffectiveFrom ? -1 : (a.CreatedAt < b.CreatedAt ? 1 : -1); });
  var r = rules[0], az = azanFor_(d);
  if (r && r.Mode === 'FIXED') return MasjidTimes.toMin(r.Time);
  if (r && r.Mode === 'OFFSET' && az) return az[PRAYER_KEY[prayer]] + num_(r.OffsetMin);
  return az ? az[PRAYER_KEY[prayer]] : null;
}
function hm_(min) { return min === null || min === undefined ? '' : MasjidTimes.hhmm(min, true); }

/* ---------------- validation helpers ---------------- */

function vTime_(v, label, req) {
  v = V.str(v, label, { max: 5, req: req });
  if (v && !/^([01]\d|2[0-3]):[0-5]\d$/.test(v)) fail_(label + ': use 24-hour time like 13:30.');
  return v;
}
function vDays_(v) {
  var arr = Array.isArray(v) ? v : String(v || '').split(',');
  arr = arr.map(function (x) { return String(x).trim(); }).filter(Boolean);
  if (arr.indexOf('Daily') >= 0) return 'Daily';
  arr.forEach(function (x) { V.oneOf(x, WEEKDAYS, 'Day'); });
  if (!arr.length) fail_('Choose at least one day.');
  return WEEKDAYS.filter(function (w) { return arr.indexOf(w) >= 0; }).join(',');
}
function bilingual_(p, base, label, max, req) {
  return { en: V.str(p[base], label, { max: max, req: req, multi: max > 200 }), ur: V.str(p[base + 'Ur'], label + ' (Urdu)', { max: max, multi: max > 200 }) };
}

/* ---------------- list everything for the Community screens ---------------- */

function listCommunity_(ctx) {
  var p = props_();
  return {
    jamaat: read_(SH.JAMAAT).map(strip_).reverse(),
    announcements: read_(SH.ANNOUNCE).map(strip_).reverse(),
    events: read_(SH.EVENTS).map(strip_).reverse(),
    programs: read_(SH.PROGRAMS).map(strip_).reverse(),
    janazah: read_(SH.JANAZAH).map(strip_).reverse(),
    calendar: calendarInfo_(),
    publicSheetUrl: p.getProperty('PUBLIC_SS_ID') ? 'https://docs.google.com/spreadsheets/d/' + p.getProperty('PUBLIC_SS_ID') : '',
    lastPublished: p.getProperty('PUBLIC_LAST') || '',
    hasQr: !!p.getProperty('UPI_QR_FILE_ID'),
    options: { prayers: PRAYERS, eventCats: EVENT_CATEGORIES, programCats: PROGRAM_CATEGORIES, weekdays: WEEKDAYS }
  };
}

/* ---------------- Jamaat time rules ---------------- */

function saveJamaat_(ctx, p) {
  if (p.RuleID) { // only status can change; history is kept
    var cur = findById_(SH.JAMAAT, p.RuleID);
    if (!cur) fail_('Rule not found.');
    cur.Status = V.oneOf(p.Status, ['Active', 'Inactive'], 'Status');
    cur.UpdatedAt = ctx.now; cur.UpdatedBy = ctx.user.Email;
    update_(SH.JAMAAT, cur);
    audit_(ctx, 'UPDATE', 'JamaatRule', cur.RuleID, { status: cur.Status });
    ctx.publish = true;
    return { record: strip_(cur) };
  }
  var rec = {
    RuleID: newId_('JMT'),
    Prayer: V.oneOf(p.Prayer, PRAYERS, 'Prayer'),
    Mode: V.oneOf(p.Mode || 'FIXED', ['FIXED', 'OFFSET'], 'Type'),
    EffectiveFrom: V.date(p.EffectiveFrom || today_(), 'Effective from'),
    Notes: V.str(p.Notes, 'Notes', { max: 200 }),
    Status: 'Active', CreatedAt: ctx.now, CreatedBy: ctx.user.Email
  };
  if (rec.Mode === 'FIXED') { rec.Time = vTime_(p.Time, 'Jamaat time', true); rec.OffsetMin = ''; }
  else {
    rec.Time = '';
    rec.OffsetMin = parseInt(p.OffsetMin, 10);
    if (!(rec.OffsetMin >= 0 && rec.OffsetMin <= 120)) fail_('Minutes after Azan must be between 0 and 120.');
  }
  append_(SH.JAMAAT, [rec]);
  audit_(ctx, 'CREATE', 'JamaatRule', rec.RuleID, rec);
  ctx.publish = true;
  return { record: strip_(rec) };
}

/* ---------------- Announcements ---------------- */

function saveAnnouncement_(ctx, p) {
  var t = bilingual_(p, 'Title', 'Title', 150, true), b = bilingual_(p, 'Body', 'Message', 1500, false);
  var rec = { Title: t.en, TitleUr: t.ur, Body: b.en, BodyUr: b.ur,
    Priority: V.oneOf(p.Priority || 'Normal', ['Normal', 'Important'], 'Priority'),
    StartDate: V.date(p.StartDate || today_(), 'Show from'),
    EndDate: p.EndDate ? V.date(p.EndDate, 'Show until') : '',
    Status: V.oneOf(p.Status || 'Active', ['Active', 'Inactive'], 'Status') };
  if (rec.EndDate && rec.EndDate < rec.StartDate) fail_('"Show until" must be after "Show from".');
  return saveRow_(ctx, SH.ANNOUNCE, 'AnnID', 'ANN', p.AnnID, rec, null);
}

/* ---------------- Events ---------------- */

function saveEvent_(ctx, p) {
  var t = bilingual_(p, 'Title', 'Title', 150, true), d = bilingual_(p, 'Description', 'Description', 1500, false);
  var rec = { Category: V.oneOf(p.Category || 'Event', EVENT_CATEGORIES, 'Category'), Title: t.en, TitleUr: t.ur,
    Description: d.en, DescriptionUr: d.ur, Date: V.date(p.Date, 'Date'),
    StartTime: vTime_(p.StartTime, 'Start time'), EndTime: vTime_(p.EndTime, 'End time'),
    Venue: V.str(p.Venue, 'Venue', { max: 150 }), Status: V.oneOf(p.Status || 'Active', ['Active', 'Inactive'], 'Status') };
  if (rec.EndTime && !rec.StartTime) fail_('Give a start time too.');
  if (rec.EndTime && rec.EndTime <= rec.StartTime) fail_('End time must be after start time.');
  return saveRow_(ctx, SH.EVENTS, 'EventID', 'EVT', p.EventID, rec, calEvent_);
}

/* ---------------- Weekly programmes (Dawat, Gasht, Taleem, classes…) ---------------- */

function saveProgram_(ctx, p) {
  var t = bilingual_(p, 'Title', 'Title', 150, true), d = bilingual_(p, 'Description', 'Description', 1000, false);
  var rec = { Category: V.oneOf(p.Category || 'Dawat', PROGRAM_CATEGORIES, 'Category'), Title: t.en, TitleUr: t.ur,
    Description: d.en, DescriptionUr: d.ur, Days: vDays_(p.Days),
    TimeMode: V.oneOf(p.TimeMode || 'AFTER', ['FIXED', 'AFTER'], 'Timing'),
    DurationMin: Math.min(600, Math.max(5, parseInt(p.DurationMin, 10) || 45)),
    Venue: V.str(p.Venue, 'Venue', { max: 150 }), Contact: V.str(p.Contact, 'Contact', { max: 150 }),
    StartDate: p.StartDate ? V.date(p.StartDate, 'Starts') : '', EndDate: p.EndDate ? V.date(p.EndDate, 'Ends') : '',
    Status: V.oneOf(p.Status || 'Active', ['Active', 'Inactive'], 'Status') };
  if (rec.TimeMode === 'FIXED') { rec.Time = vTime_(p.Time, 'Time', true); rec.AfterPrayer = ''; }
  else { rec.Time = ''; rec.AfterPrayer = V.oneOf(p.AfterPrayer, PRAYERS, 'After which prayer'); }
  if (rec.StartDate && rec.EndDate && rec.EndDate < rec.StartDate) fail_('End date must be after start date.');
  return saveRow_(ctx, SH.PROGRAMS, 'ProgramID', 'PRG', p.ProgramID, rec, calProgram_);
}

/* ---------------- Janazah ---------------- */

function saveJanazah_(ctx, p) {
  var rec = { DeceasedName: V.str(p.DeceasedName, 'Name of the deceased', { req: true, max: 120 }),
    DeceasedNameUr: V.str(p.DeceasedNameUr, 'Name (Urdu)', { max: 120 }),
    Details: V.str(p.Details, 'Details', { max: 500, multi: true }),
    Date: V.date(p.Date || today_(), 'Date'),
    TimeMode: V.oneOf(p.TimeMode || 'AFTER', ['FIXED', 'AFTER'], 'Timing'),
    Venue: V.str(p.Venue, 'Venue', { max: 150 }), BurialPlace: V.str(p.BurialPlace, 'Burial place', { max: 150 }),
    Status: V.oneOf(p.Status || 'Active', ['Active', 'Inactive'], 'Status') };
  if (rec.TimeMode === 'FIXED') { rec.Time = vTime_(p.Time, 'Salah time', true); rec.AfterPrayer = ''; }
  else { rec.Time = ''; rec.AfterPrayer = V.oneOf(p.AfterPrayer, PRAYERS, 'After which prayer'); }
  return saveRow_(ctx, SH.JANAZAH, 'JanazahID', 'JNZ', p.JanazahID, rec, calJanazah_);
}

/** Generic create/update for community tables + optional calendar sync. */
function saveRow_(ctx, sheet, idCol, prefix, id, rec, calFn) {
  var cur;
  if (id) {
    cur = findById_(sheet, id);
    if (!cur) fail_('Record not found.');
    var before = pick_(cur, Object.keys(rec));
    Object.keys(rec).forEach(function (k) { cur[k] = rec[k]; });
    cur.UpdatedAt = ctx.now; cur.UpdatedBy = ctx.user.Email;
    if (calFn) calSync_(ctx, cur, calFn);
    update_(sheet, cur);
    audit_(ctx, 'UPDATE', sheet, id, { before: before, after: rec });
  } else {
    cur = rec; cur[idCol] = newId_(prefix); cur.CreatedAt = ctx.now; cur.CreatedBy = ctx.user.Email;
    append_(sheet, [cur]);
    if (calFn) { calSync_(ctx, cur, calFn); if (cur.CalendarEventID) update_(sheet, cur); }
    audit_(ctx, 'CREATE', sheet, cur[idCol], rec);
  }
  ctx.publish = true;
  return { record: strip_(cur), warning: ctx.calendarWarning || '' };
}

/* ---------------- Google Calendar (free reminders) ---------------- */

function calendarInfo_() {
  var id = props_().getProperty('CALENDAR_ID');
  if (!id) return { id: '', subscribeUrl: '', icsUrl: '', isPublic: props_().getProperty('CALENDAR_PUBLIC') === 'YES' };
  return { id: id, subscribeUrl: 'https://calendar.google.com/calendar/render?cid=' + encodeURIComponent(id),
    icsUrl: 'https://calendar.google.com/calendar/ical/' + encodeURIComponent(id) + '/public/basic.ics',
    isPublic: props_().getProperty('CALENDAR_PUBLIC') === 'YES' };
}
function cal_() {
  var p = props_(), id = p.getProperty('CALENDAR_ID'), c = null;
  if (id) { try { c = CalendarApp.getCalendarById(id); } catch (e) { c = null; } }
  if (!c) {
    c = CalendarApp.createCalendar(String(setting_('MASJID_NAME')) + ' — Timings & Events',
      { timeZone: tz_(), summary: 'Jumu\'ah, Ramadan Sehri/Iftar, Dawat programmes, events and Janazah notices.' });
    p.setProperty('CALENDAR_ID', c.getId());
    p.deleteProperty('CALENDAR_PUBLIC');
  }
  return c;
}
function dateAt_(d, min) {
  var p = d.split('-').map(Number);
  return new Date(p[0], p[1] - 1, p[2], Math.floor(min / 60), min % 60, 0);
}
function calDelete_(ref) {
  if (!ref) return;
  var c = cal_(), kind = ref.slice(0, 2), id = ref.slice(2);
  try {
    if (kind === 'S:') { var s = c.getEventSeriesById(id); if (s) s.deleteEventSeries(); }
    else { var e = c.getEventById(id); if (e) e.deleteEvent(); }
  } catch (err) { /* already gone */ }
}
function calTitle_(en, ur) { return en + (ur ? ' | ' + ur : ''); }
function calSync_(ctx, rec, fn) {
  try {
    calDelete_(rec.CalendarEventID);
    rec.CalendarEventID = rec.Status === 'Active' ? (fn(rec) || '') : '';
    if (!props_().getProperty('CAL_JUMUAH')) syncJumuah_(ctx); // first use of the calendar: add the weekly Jumu'ah
  } catch (e) {
    rec.CalendarEventID = rec.CalendarEventID || '';
    ctx.calendarWarning = 'Saved, but Google Calendar could not be updated (' + cleanErr_(e) + '). Use "Re-sync calendar" later.';
  }
}
function calEvent_(r) {
  var c = cal_(), opts = { location: r.Venue || String(setting_('MASJID_NAME')), description: [r.Description, r.DescriptionUr].filter(Boolean).join('\n\n') };
  if (r.StartTime) {
    var s = MasjidTimes.toMin(r.StartTime), e = r.EndTime ? MasjidTimes.toMin(r.EndTime) : s + 60;
    return 'E:' + c.createEvent(calTitle_(r.Title, r.TitleUr), dateAt_(r.Date, s), dateAt_(r.Date, e), opts).getId();
  }
  return 'E:' + c.createAllDayEvent(calTitle_(r.Title, r.TitleUr), dateAt_(r.Date, 0), opts).getId();
}
function prayerAnchor_(prayer, d) {
  var j = jamaatFor_(prayer, d);
  if (j === null) fail_('Set the masjid location or a Jamaat time for ' + prayer + ' first.');
  return j + 10; // programme starts ~10 minutes after the Jamaat
}
function calProgram_(r) {
  var c = cal_(), start = r.StartDate && r.StartDate > today_() ? r.StartDate : today_();
  var until = r.EndDate || addDays_(start, 365);
  var min = r.TimeMode === 'FIXED' ? MasjidTimes.toMin(r.Time) : prayerAnchor_(r.AfterPrayer, start);
  var rec = CalendarApp.newRecurrence();
  var rule = r.Days === 'Daily' ? rec.addDailyRule() : rec.addWeeklyRule().onlyOnWeekdays(r.Days.split(',').map(function (d) {
    return CalendarApp.Weekday[{ Mon: 'MONDAY', Tue: 'TUESDAY', Wed: 'WEDNESDAY', Thu: 'THURSDAY', Fri: 'FRIDAY', Sat: 'SATURDAY', Sun: 'SUNDAY' }[d]];
  }));
  rule.until(dateAt_(until, 23 * 60 + 59));
  var desc = [r.TimeMode === 'AFTER' ? 'After ' + r.AfterPrayer + ' Jamaat (time shown is approximate).' : '', r.Description, r.DescriptionUr,
    r.Contact ? 'Contact: ' + r.Contact : ''].filter(Boolean).join('\n\n');
  var title = '[' + r.Category + '] ' + calTitle_(r.Title, r.TitleUr);
  return 'S:' + c.createEventSeries(title, dateAt_(start, min), dateAt_(start, min + num_(r.DurationMin || 45)), rec,
    { location: r.Venue || String(setting_('MASJID_NAME')), description: desc }).getId();
}
function calJanazah_(r) {
  var c = cal_(), min = r.TimeMode === 'FIXED' ? MasjidTimes.toMin(r.Time) : (jamaatFor_(r.AfterPrayer, r.Date) || 12 * 60) + 5;
  var title = 'Namaz-e-Janazah: ' + calTitle_(r.DeceasedName, r.DeceasedNameUr);
  var desc = [r.TimeMode === 'AFTER' ? 'After ' + r.AfterPrayer + ' Jamaat.' : '', r.Details, r.BurialPlace ? 'Burial: ' + r.BurialPlace : '',
    'Inna lillahi wa inna ilayhi raji\'un.'].filter(Boolean).join('\n');
  return 'E:' + c.createEvent(title, dateAt_(r.Date, min), dateAt_(r.Date, min + 30), { location: r.Venue || String(setting_('MASJID_NAME')), description: desc }).getId();
}

/** Weekly Jumu'ah series (re-created when Jumu'ah times change). */
function syncJumuah_(ctx) {
  var p = props_();
  try {
    calDelete_(p.getProperty('CAL_JUMUAH'));
    var k = MasjidTimes.toMin(setting_('JUMUAH_KHUTBAH_TIME')), j = MasjidTimes.toMin(setting_('JUMUAH_JAMAAT_TIME'));
    if (k === null || j === null) { p.deleteProperty('CAL_JUMUAH'); return; }
    var start = today_(), dow = new Date(start + 'T12:00:00Z').getUTCDay(), d = addDays_(start, (5 - dow + 7) % 7);
    var rec = CalendarApp.newRecurrence(); rec.addWeeklyRule().onlyOnWeekday(CalendarApp.Weekday.FRIDAY).until(dateAt_(addDays_(d, 365), 0));
    var s = cal_().createEventSeries('Jumu\'ah — Khutbah ' + hm_(k) + ', Jamaat ' + hm_(j) + ' | جمعہ', dateAt_(d, Math.min(k, j)), dateAt_(d, j + 20), rec,
      { location: String(setting_('MASJID_NAME')), description: 'Azan ' + hm_(MasjidTimes.toMin(setting_('JUMUAH_AZAN_TIME'))) + ' · Khutbah ' + hm_(k) + ' · Jamaat ' + hm_(j) });
    p.setProperty('CAL_JUMUAH', 'S:' + s.getId());
  } catch (e) { ctx.calendarWarning = 'Jumu\'ah calendar not updated: ' + cleanErr_(e); }
}

/** Ramadan Sehri / Iftar for every Roza + Eid, as calendar events (re-run replaces the old ones). */
function ramadanTable_() {
  var start = String(setting_('RAMADAN_START') || ''), n = Math.min(30, Math.max(29, parseInt(setting_('RAMADAN_DAYS'), 10) || 30));
  if (!start) fail_('Set the first Roza date first.');
  if (!hasLocation_()) fail_('Set the masjid latitude and longitude first.');
  var sehriSafe = num_(setting_('SEHRI_SAFETY_MIN')), iftarSafe = num_(setting_('IFTAR_SAFETY_MIN')), out = [];
  for (var i = 0; i < n; i++) {
    var d = addDays_(start, i), az = azanFor_(d);
    out.push({ roza: i + 1, date: d, sehri: az.fajr - sehriSafe, iftar: az.maghrib + iftarSafe, fajr: az.fajr, maghrib: az.maghrib });
  }
  return out;
}
function ramadanSync_(ctx) {
  var table = ramadanTable_(), p = props_(), c = cal_();
  JSON.parse(p.getProperty('CAL_RAMADAN') || '[]').forEach(function (ref) { calDelete_(ref); });
  var refs = [];
  table.forEach(function (r) {
    refs.push('E:' + c.createEvent('Sehri ends ' + hm_(r.sehri) + ' — Roza ' + r.roza + ' | سحری', dateAt_(r.date, r.sehri - 20), dateAt_(r.date, r.sehri),
      { description: 'Sehri ends at ' + hm_(r.sehri) + '. Fajr Azan ' + hm_(r.fajr) + '.' }).getId());
    refs.push('E:' + c.createEvent('Iftar ' + hm_(r.iftar) + ' — Roza ' + r.roza + ' | افطار', dateAt_(r.date, r.iftar), dateAt_(r.date, r.iftar + 15),
      { description: 'Iftar time ' + hm_(r.iftar) + '. ' + String(setting_('TARAWEEH_INFO') ? 'Taraweeh: ' + setting_('TARAWEEH_INFO') : '') }).getId());
    Utilities.sleep(150); // stay well inside Google Calendar's free rate limits
  });
  [['EID_FITR_DATE', 'EID_FITR_TIME', 'Eid-ul-Fitr Salah | عید الفطر'], ['EID_ADHA_DATE', 'EID_ADHA_TIME', 'Eid-ul-Adha Salah | عید الاضحیٰ']].forEach(function (e) {
    var d = setting_(e[0]), t = MasjidTimes.toMin(setting_(e[1]));
    if (d && t !== null) refs.push('E:' + c.createEvent(e[2], dateAt_(d, t), dateAt_(d, t + 45), { location: String(setting_('EID_VENUE') || setting_('MASJID_NAME')) }).getId());
  });
  p.setProperty('CAL_RAMADAN', JSON.stringify(refs));
  audit_(ctx, 'CALENDAR_SYNC', 'Ramadan', String(setting_('RAMADAN_START')), { events: refs.length });
  return { events: refs.length };
}

/** Re-create every active calendar item (e.g. after Jamaat times change or the calendar was recreated). */
function resyncCalendar_(ctx) {
  var n = 0;
  [[SH.EVENTS, calEvent_], [SH.PROGRAMS, calProgram_], [SH.JANAZAH, calJanazah_]].forEach(function (x) {
    var rows = read_(x[0]).filter(function (r) { return r.Status === 'Active' && !(r.Date && r.Date < addDays_(today_(), -2)) && !(r.EndDate && r.EndDate < today_()); });
    rows.forEach(function (r) { calSync_(ctx, r, x[1]); n++; Utilities.sleep(100); });
    updateMany_(x[0], rows);
  });
  syncJumuah_(ctx);
  audit_(ctx, 'CALENDAR_SYNC', 'All', '', { items: n });
  return { items: n, warning: ctx.calendarWarning || '' };
}

/** Make the calendar public (needs the free "Google Calendar API" advanced service, enabled in appsscript.json). */
function makeCalendarPublic_(ctx) {
  var c = cal_();
  try {
    Calendar.Acl.insert({ role: 'reader', scope: { type: 'default' } }, c.getId());
    props_().setProperty('CALENDAR_PUBLIC', 'YES');
    if (!props_().getProperty('CAL_JUMUAH')) syncJumuah_(ctx);
    ctx.publish = true;
    audit_(ctx, 'CALENDAR_PUBLIC', 'Calendar', c.getId(), {});
    return calendarInfo_();
  } catch (e) {
    fail_('Could not make the calendar public automatically. Open Google Calendar › Settings › "' + c.getName() + '" › Access permissions › tick "Make available to public". (' + cleanErr_(e) + ')');
  }
}

/* ---------------- Public snapshot (read by the public website) ---------------- */

function publicSs_() {
  var id = props_().getProperty('PUBLIC_SS_ID');
  if (!id) fail_('The public website data sheet is missing. The owner should run setup().');
  return SpreadsheetApp.openById(id);
}

function buildSnapshot_() {
  var s = settings_(), t = today_(), p = props_();
  function active(r) { return r.Status === 'Active'; }
  function pickRow(r, keys) { var o = {}; keys.forEach(function (k) { o[k] = r[k]; }); return o; }
  var snap = {
    v: Date.now(), generatedAt: nowStr_(), today: t,
    masjid: { name: s.MASJID_NAME, nameUr: s.MASJID_NAME_UR, address: s.MASJID_ADDRESS, phone: s.MASJID_PHONE, email: s.MASJID_EMAIL,
      mapsLink: s.MAPS_LINK, whatsapp: s.WHATSAPP_LINK, contacts: s.PUBLIC_CONTACTS, facilities: s.FACILITIES,
      about: s.ABOUT_TEXT, aboutUr: s.ABOUT_TEXT_UR, siteUrl: s.PUBLIC_SITE_URL, formsEnabled: yes_(s.FORMS_ENABLED),
      appUrl: yes_(s.SHOW_COMMITTEE_LOGIN) ? committeeAppUrl_() : '' },
    calc: { lat: s.LATITUDE === '' ? null : +s.LATITUDE, lng: s.LONGITUDE === '' ? null : +s.LONGITUDE, tz: tzHours_(),
      fajrAngle: +s.FAJR_ANGLE || 18, ishaAngle: +s.ISHA_ANGLE || 18, asrFactor: s.ASR_METHOD === 'Shafi' ? 1 : 2,
      asrMethod: s.ASR_METHOD, hijriAdjust: +s.HIJRI_ADJUST || 0 },
    jumuah: { azan: s.JUMUAH_AZAN_TIME, khutbah: s.JUMUAH_KHUTBAH_TIME, jamaat: s.JUMUAH_JAMAAT_TIME },
    jamaat: read_(SH.JAMAAT).filter(active).map(function (r) { return { p: r.Prayer, mode: r.Mode, time: r.Time, offset: num_(r.OffsetMin), from: r.EffectiveFrom }; }),
    announcements: read_(SH.ANNOUNCE).filter(function (r) { return active(r) && (!r.EndDate || r.EndDate >= t) && r.StartDate <= addDays_(t, 60); })
      .slice(-40).map(function (r) { return pickRow(r, ['AnnID', 'Title', 'TitleUr', 'Body', 'BodyUr', 'Priority', 'StartDate', 'EndDate']); }),
    events: read_(SH.EVENTS).filter(function (r) { return active(r) && r.Date >= addDays_(t, -30) && r.Date <= addDays_(t, 400); })
      .slice(-150).map(function (r) { return pickRow(r, ['EventID', 'Category', 'Title', 'TitleUr', 'Description', 'DescriptionUr', 'Date', 'StartTime', 'EndTime', 'Venue']); }),
    programs: read_(SH.PROGRAMS).filter(function (r) { return active(r) && (!r.EndDate || r.EndDate >= t); })
      .map(function (r) { return pickRow(r, ['ProgramID', 'Category', 'Title', 'TitleUr', 'Description', 'DescriptionUr', 'Days', 'TimeMode', 'Time', 'AfterPrayer', 'DurationMin', 'Venue', 'Contact', 'StartDate', 'EndDate']); }),
    janazah: read_(SH.JANAZAH).filter(function (r) { return active(r) && r.Date >= addDays_(t, -14); })
      .map(function (r) { return pickRow(r, ['JanazahID', 'DeceasedName', 'DeceasedNameUr', 'Details', 'Date', 'TimeMode', 'Time', 'AfterPrayer', 'Venue', 'BurialPlace']); }),
    ramadan: { start: s.RAMADAN_START, days: Math.min(30, Math.max(29, parseInt(s.RAMADAN_DAYS, 10) || 30)),
      sehriSafety: num_(s.SEHRI_SAFETY_MIN), iftarSafety: num_(s.IFTAR_SAFETY_MIN), taraweeh: s.TARAWEEH_INFO, note: s.RAMADAN_NOTE,
      eidFitr: { date: s.EID_FITR_DATE, time: s.EID_FITR_TIME }, eidAdha: { date: s.EID_ADHA_DATE, time: s.EID_ADHA_TIME }, eidVenue: s.EID_VENUE },
    donate: { upiId: s.UPI_ID, payee: s.UPI_PAYEE_NAME || s.MASJID_NAME, note: s.DONATE_NOTE, reg: s.REG_NO, tax: s.TAX_EXEMPTION_NOTE, qr: '' },
    calendar: calendarInfo_()
  };
  var qr = p.getProperty('UPI_QR_FILE_ID');
  if (qr) { try { var b = DriveApp.getFileById(qr).getBlob(); if (b.getBytes().length < 150000) snap.donate.qr = 'data:' + b.getContentType() + ';base64,' + Utilities.base64Encode(b.getBytes()); } catch (e) { } }
  return snap;
}

/** Writes the snapshot to the public data sheet (chunked into column A; B1 = version). 2 Sheets calls. */
/** The private app's own /exec address (set in Website Settings, or detected from this deployment). */
function committeeAppUrl_() {
  var u = String(setting_('ADMIN_APP_URL') || '');
  if (!u) { try { u = String(ScriptApp.getService().getUrl() || ''); } catch (e) { u = ''; } }
  return /^https:\/\/script\.google\.com\/(a\/[^\/\s]+\/)?macros\/s\/[\w-]+\/exec$/.test(u) ? u : '';
}

function publishPublic_(ctx) {
  var json = JSON.stringify(buildSnapshot_()), chunks = [];
  for (var i = 0; i < json.length; i += 45000) chunks.push([json.slice(i, i + 45000)]);
  var sh = publicSs_().getSheetByName('Snapshot');
  if (!sh) fail_('Public data sheet is missing its "Snapshot" tab. Run setup().');
  if (sh.getMaxRows() < chunks.length + 1) sh.insertRowsAfter(sh.getMaxRows(), chunks.length + 1 - sh.getMaxRows());
  var block = chunks.map(function (c) { return [c[0]]; });
  while (block.length < sh.getMaxRows()) block.push(['']);
  sh.getRange(1, 1, block.length, 1).setValues(block);
  sh.getRange(1, 2).setValue(String(Date.now()));
  props_().setProperty('PUBLIC_LAST', nowStr_());
  return { bytes: json.length, chunks: chunks.length };
}

function publishNow_(ctx) {
  var r = publishPublic_(ctx);
  audit_(ctx, 'PUBLISH', 'PublicWebsite', '', r);
  return r;
}

/* ---------------- Community settings + UPI QR ---------------- */

function saveCommunitySettings_(ctx, p) {
  var out = saveSettings_(ctx, p, 'community');
  var ch = ctx.changedSettings || [];
  if (ch.some(function (k) { return /^JUMUAH_/.test(k); })) syncJumuah_(ctx);
  ctx.publish = true;
  return { settings: out, warning: ctx.calendarWarning || '' };
}

function saveQr_(ctx, p) {
  if (p.remove === true) { props_().deleteProperty('UPI_QR_FILE_ID'); audit_(ctx, 'UPDATE', 'UPI_QR', '', { removed: true }); ctx.publish = true; return true; }
  var f = p.file;
  if (!f || (f.mimeType !== 'image/png' && f.mimeType !== 'image/jpeg')) fail_('Upload the UPI QR code as a PNG or JPG image.');
  var bytes = Utilities.base64Decode(String(f.data || ''));
  if (bytes.length > 150000) fail_('QR image must be under 150 KB.');
  var id = saveUpload_(ctx, f, 'COMMUNITY', 'UPI_QR');
  props_().setProperty('UPI_QR_FILE_ID', id);
  ctx.publish = true;
  return true;
}

/* ---------------- Requests submitted on the website ---------------- */

function requestsSheet_() {
  var sh = publicSs_().getSheetByName('Requests');
  if (!sh) fail_('Public data sheet is missing its "Requests" tab. Run setup().');
  return sh;
}
function listRequests_(ctx, p) {
  var sh = requestsSheet_(), last = sh.getLastRow();
  if (last < 2) return [];
  var start = Math.max(2, last - 499);
  var vals = sh.getRange(start, 1, last - start + 1, REQ_HEADERS.length).getValues();
  var status = p && p.Status ? String(p.Status) : '';
  return vals.map(function (r) { var o = {}; REQ_HEADERS.forEach(function (h, i) { o[h] = r[i] instanceof Date ? fmtTs_(r[i].getTime()) : String(r[i]); }); return o; })
    .filter(function (o) { return o.ReqID && (!status || o.Status === status); }).reverse();
}
function updateRequest_(ctx, p) {
  var id = V.id(p.ReqID, 'Request'), status = V.oneOf(p.Status, REQ_STATUSES, 'Status'), note = V.str(p.Note, 'Note', { max: 300 });
  var sh = requestsSheet_(), last = sh.getLastRow();
  if (last < 2) fail_('Request not found.');
  var ids = sh.getRange(2, 1, last - 1, 1).getValues().map(function (r) { return String(r[0]); });
  var i = ids.lastIndexOf(id);
  if (i < 0) fail_('Request not found.');
  sh.getRange(i + 2, 8, 1, 4).setValues([[status, ctx.user.Email, ctx.now, note]]);
  audit_(ctx, 'UPDATE', 'Request', id, { status: status, note: note });
  return true;
}
