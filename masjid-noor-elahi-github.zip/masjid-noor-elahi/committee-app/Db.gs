/**
 * Db.gs — Google Sheets data layer.
 * - One batch read per sheet per execution (memoised), small masters cached in CacheService.
 * - Batch appends with setValues; single-range row updates.
 * - All writes run under LockService (see withLock_).
 * - Nothing is ever deleted: rows only get appended or have their Status changed.
 */

var _memo = { t: {}, h: {}, idx: {} };

function props_() { return PropertiesService.getScriptProperties(); }

function ss_() {
  if (_memo.ss) return _memo.ss;
  var id = props_().getProperty('SPREADSHEET_ID');
  if (!id) fail_('System is not set up yet. The owner must run setup() from the Apps Script editor.');
  _memo.ss = SpreadsheetApp.openById(id);
  return _memo.ss;
}

function sheet_(name) {
  _memo.sh = _memo.sh || {};
  if (_memo.sh[name]) return _memo.sh[name];
  var s = ss_().getSheetByName(name);
  if (!s) fail_('Missing sheet "' + name + '". The owner should run setup() again.');
  return (_memo.sh[name] = s);
}

function headers_(name) {
  if (_memo.h[name]) return _memo.h[name];
  var sh = sheet_(name);
  var h = sh.getRange(1, 1, 1, Math.max(1, sh.getLastColumn())).getValues()[0].map(String);
  return (_memo.h[name] = h);
}

function normCell_(h, v) {
  if (v instanceof Date) {
    return /At$|Timestamp|LockedUntil|LastLogin/.test(h)
      ? Utilities.formatDate(v, tz_(), 'yyyy-MM-dd HH:mm:ss')
      : Utilities.formatDate(v, tz_(), 'yyyy-MM-dd');
  }
  if (NUMERIC_COLS[h]) return v === '' ? '' : num_(v);
  return v === null || v === undefined ? '' : String(v);
}

/** Cache version per table (bumped under the lock on every write). Stale cache entries are ignored. */
function tableVer_(name) {
  if (!_memo.ver) _memo.ver = props_().getProperties();
  return _memo.ver['VER_' + name] || '0';
}
function bumpVer_(name) {
  var v = String(Date.now()) + Math.floor(Math.random() * 1000);
  props_().setProperty('VER_' + name, v);
  if (_memo.ver) _memo.ver['VER_' + name] = v;
}

/** Cached copy of users never contains salts or full hashes (only a fingerprint for session checks). */
function cacheSafe_(name, rows) {
  if (name !== SH.USERS) return rows;
  return rows.map(function (u) {
    var c = {}; Object.keys(u).forEach(function (k) { c[k] = u[k]; });
    c.PasswordHash = pwFp_(u.PasswordHash); c.Salt = ''; c._cached = true;
    return c;
  });
}

/** Read a whole table (one Sheets call). Rows carry their sheet row number in _row.
 *  Inside a write lock, tables are always read fresh from the sheet. */
function read_(name) {
  if (_memo.t[name]) return _memo.t[name];
  var cacheable = CACHED_TABLES.indexOf(name) >= 0, cache = null, key = 'TBL_' + name, ver = '';
  if (cacheable) {
    cache = CacheService.getScriptCache();
    ver = tableVer_(name);
    if (!_memo.locked) {
      var hit = cache.get(key);
      if (hit) {
        var parsed = JSON.parse(hit);
        if (parsed.v === ver) { _memo.h[name] = parsed.h; return (_memo.t[name] = parsed.r); }
      }
    }
  }
  var sh = sheet_(name), last = sh.getLastRow(), lastCol = Math.max(1, sh.getLastColumn());
  var vals = sh.getRange(1, 1, Math.max(1, last), lastCol).getValues();
  var h = vals[0].map(String);
  _memo.h[name] = h;
  var rows = [];
  for (var i = 1; i < vals.length; i++) {
    var o = { _row: i + 1 }, empty = true;
    for (var j = 0; j < h.length; j++) {
      if (!h[j]) continue;
      o[h[j]] = normCell_(h[j], vals[i][j]);
      if (o[h[j]] !== '') empty = false;
    }
    if (!empty) rows.push(o);
  }
  if (cacheable) {
    var s = JSON.stringify({ v: ver, h: h, r: cacheSafe_(name, rows) });
    if (s.length < 95000) { try { cache.put(key, s, 21600); } catch (e) { /* too large — skip cache */ } }
  }
  return (_memo.t[name] = rows);
}

/** Read only the last n data rows (used for the large audit log). */
function readTail_(name, n) {
  var sh = sheet_(name), last = sh.getLastRow(), h = headers_(name);
  if (last < 2) return [];
  var start = Math.max(2, last - n + 1);
  var vals = sh.getRange(start, 1, last - start + 1, h.length).getValues();
  return vals.map(function (r, i) {
    var o = { _row: start + i };
    h.forEach(function (k, j) { if (k) o[k] = normCell_(k, r[j]); });
    return o;
  });
}

function invalidate_(name) {
  if (CACHED_TABLES.indexOf(name) >= 0) { bumpVer_(name); CacheService.getScriptCache().remove('TBL_' + name); }
  delete _memo.idx[name];
  if (name === SH.LEDGERS || name === SH.ACCOUNTS) delete _memo.lm;
  if (name === SH.SETTINGS) delete _memo.settings;
  if (name === SH.GL) delete _memo.gla;
}

function toRow_(h, obj) {
  return h.map(function (k) {
    var v = obj[k];
    if (v === undefined || v === null) return '';
    if (NUMERIC_COLS[k]) return v === '' ? '' : num_(v);
    return typeof v === 'object' ? JSON.stringify(v) : String(v);
  });
}

/** Append many records in ONE setValues call. */
function append_(name, objs) {
  if (!objs || !objs.length) return;
  var sh = sheet_(name), h = headers_(name);
  var start = sh.getLastRow() + 1, need = start + objs.length - 1, max = sh.getMaxRows();
  if (need > max) {
    var add = need - max + 200;
    sh.insertRowsAfter(max, add);
    // Make sure new rows keep plain-text format (no formula evaluation, no date auto-conversion).
    var fmt = h.map(function (k) { return NUMERIC_COLS[k] ? '#,##0.00' : '@'; });
    var block = []; for (var i = 0; i < add; i++) block.push(fmt);
    sh.getRange(max + 1, 1, add, h.length).setNumberFormats(block);
  }
  sh.getRange(start, 1, objs.length, h.length).setValues(objs.map(function (o) { return toRow_(h, o); }));
  var cachedRows = _memo.t[name];
  objs.forEach(function (o, i) { o._row = start + i; if (cachedRows) cachedRows.push(o); });
  invalidate_(name);
}

/** Overwrite one existing record (requires _row). One setValues call. */
function update_(name, obj) {
  if (!obj._row || obj._row < 2) throw new Error('Internal: record has no row reference.');
  if (obj._cached) throw new Error('Internal: refusing to write a cached (sanitised) record.');
  var h = headers_(name);
  sheet_(name).getRange(obj._row, 1, 1, h.length).setValues([toRow_(h, obj)]);
  invalidate_(name);
}

/** Update many records; contiguous rows are written together. */
function updateMany_(name, objs) {
  if (!objs.length) return;
  var h = headers_(name), sh = sheet_(name);
  if (objs.some(function (o) { return o._cached || !o._row; })) throw new Error('Internal: refusing to write a cached record.');
  var sorted = objs.slice().sort(function (a, b) { return a._row - b._row; });
  var i = 0;
  while (i < sorted.length) {
    var j = i;
    while (j + 1 < sorted.length && sorted[j + 1]._row === sorted[j]._row + 1) j++;
    var block = sorted.slice(i, j + 1).map(function (o) { return toRow_(h, o); });
    sh.getRange(sorted[i]._row, 1, block.length, h.length).setValues(block);
    i = j + 1;
  }
  invalidate_(name);
}

function findById_(name, id) {
  if (!id) return null;
  if (!_memo.idx[name]) {
    var key = SCHEMA[name][0], m = Object.create(null);
    read_(name).forEach(function (r) { m[r[key]] = r; });
    _memo.idx[name] = m;
  }
  var r = _memo.idx[name][String(id)];
  return r || null;
}

/** Sequential counters stored in Script Properties. MUST be called inside withLock_. */
function nextSeq_(key) {
  var p = props_(), cur = parseInt(p.getProperty('SEQ_' + key) || '0', 10) + 1;
  p.setProperty('SEQ_' + key, String(cur));
  return cur;
}
function newId_(prefix) { return prefix + '-' + pad_(nextSeq_('ID_' + prefix), 6); }
/** Tally-style voucher number per financial year, e.g. RV/2026-27/00012. */
function voucherNo_(type, date) {
  var fy = fyLabel_(date);
  return type + '/' + fy + '/' + pad_(nextSeq_('VN_' + type + '_' + fy), 5);
}

function withLock_(fn, waitMs) {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(waitMs || 30000)) fail_('The system is busy with another financial update. Please try again in a moment.');
  // Re-read everything fresh inside the lock (no stale cache can drive a financial decision).
  _memo.t = {}; _memo.h = {}; _memo.idx = {}; _memo.ver = null;
  delete _memo.lm; delete _memo.settings; delete _memo.gla;
  _memo.locked = true;
  try {
    return fn();
  } finally {
    _memo.locked = false;
    SpreadsheetApp.flush();
    lock.releaseLock();
  }
}

/** Settings as a key → value map (cached). */
function settings_() {
  if (_memo.settings) return _memo.settings;
  var m = {};
  DEFAULT_SETTINGS.forEach(function (d) { m[d[0]] = d[1]; });
  read_(SH.SETTINGS).forEach(function (r) { m[r.Key] = r.Value; });
  return (_memo.settings = m);
}
function setting_(k) { var v = settings_()[k]; return v === undefined ? '' : v; }

/** Audit trail (Tally "Edit Log") — buffered per request, flushed in one append. */
function audit_(ctx, action, entity, id, details) {
  var d = '';
  try { d = typeof details === 'string' ? details : JSON.stringify(details || {}); } catch (e) { d = String(details); }
  if (d.length > 4000) d = d.slice(0, 4000) + '…';
  ctx.audit.push({
    LogID: 'LOG-' + Date.now().toString(36).toUpperCase() + '-' + Utilities.getUuid().slice(0, 6).toUpperCase(),
    Timestamp: ctx.now, UserEmail: ctx.user.Email, Role: ctx.user.Role,
    Action: action, Entity: entity, EntityID: id || '', Details: d
  });
}
function flushAudit_(ctx) {
  if (ctx.audit.length) { append_(SH.AUDIT, ctx.audit); ctx.audit = []; }
}
