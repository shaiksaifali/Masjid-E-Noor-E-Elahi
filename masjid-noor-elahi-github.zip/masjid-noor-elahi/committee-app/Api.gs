/**
 * Api.gs — the ONLY entry point the browser can call (besides apiLogin).
 * Every action: session check → permission check → server-side validation → (lock) → audit.
 * Internal functions end with "_" so google.script.run cannot call them directly.
 */

var ACTIONS_ = null;
/** Built lazily: Apps Script loads files in order, so other files' functions may not exist yet at load time. */
function actions_() {
  if (ACTIONS_) return ACTIONS_;
  return (ACTIONS_ = {
  'bootstrap':          { perm: 'self', fn: bootstrap_ },
  'auth.logout':        { perm: 'self', fn: logout_, write: true },
  'auth.changePassword':{ perm: 'self', fn: changePassword_, write: true },

  'dashboard':          { perm: 'dashboard', fn: dashboard_ },

  'members.list':       { perm: 'members.view', fn: listMembers_ },
  'members.save':       { perm: 'members.edit', fn: saveMember_, write: true },
  'plans.save':         { perm: 'plans.edit', fn: savePlan_, write: true },
  'schedule.generate':  { perm: 'schedule.generate', fn: generateSchedule_, write: true },
  'schedule.list':      { perm: 'members.view', fn: listSchedule_ },
  'schedule.memberDues':{ perm: 'members.view', fn: memberDues_ },
  'schedule.waive':     { perm: 'schedule.waive', fn: waiveDue_, write: true },
  'collection.create':  { perm: 'collection.create', fn: collect_, write: true },

  'income.create':      { perm: 'income.create', fn: createIncome_, write: true },
  'expense.create':     { perm: 'expense.create', fn: createExpense_, write: true },
  'expense.decide':     { perm: 'expense.approve', fn: decideExpense_, write: true },
  'approvals.list':     { perm: 'expense.approve', fn: listApprovals_, altPerm: 'vouchers.view' },
  'transfer.create':    { perm: 'transfer.create', fn: createTransfer_, write: true },
  'journal.create':     { perm: 'journal.create', fn: createJournal_, write: true },
  'voucher.cancel':     { perm: 'voucher.cancel', fn: cancelVoucher_, write: true },
  'vouchers.list':      { perm: 'vouchers.view', fn: listVouchers_, altPerm: 'vouchers.own' },

  'ledgers.save':       { perm: 'masters.edit', fn: saveLedger_, write: true },
  'accounts.save':      { perm: 'masters.edit', fn: saveAccount_, write: true },
  'funds.save':         { perm: 'masters.edit', fn: saveFund_, write: true },
  'budgets.list':       { perm: 'reports.view', fn: listBudgets_ },
  'budgets.save':       { perm: 'masters.edit', fn: saveBudget_, write: true },

  'report.run':         { perm: 'reports.view', fn: runReport_ },
  'report.pdf':         { perm: 'reports.view', fn: reportPdf_, write: true },  // write: may save a copy + daily cap
  'brs.clear':          { perm: 'brs.edit', fn: brsClear_, write: true },

  'receipts.list':      { perm: 'receipts.view', fn: listReceipts_ },
  'receipt.get':        { perm: 'receipts.view', fn: getReceipt_ },
  'receipt.pdf':        { perm: 'receipts.view', fn: receiptPdf_, write: true },
  'receipt.email':      { perm: 'receipts.send', fn: emailReceipt_, write: true },
  'file.get':           { perm: 'files.view', fn: getFile_ },

  'users.list':         { perm: 'users.manage', fn: listUsers_ },
  'users.save':         { perm: 'users.manage', fn: saveUser_, write: true },
  'users.resetPassword':{ perm: 'users.manage', fn: resetUserPassword_, write: true },
  'users.unlock':       { perm: 'users.manage', fn: unlockUser_, write: true },
  'settings.save':      { perm: 'settings.edit', fn: saveSettings_, write: true },
  'audit.list':         { perm: 'audit.view', fn: listAudit_ },
  'system.status':      { perm: 'system.admin', fn: function (ctx) { return systemStatus_(ctx, true); } },
  'system.backup':      { perm: 'system.admin', fn: backupNow_, write: true },
  'system.backups':     { perm: 'system.admin', fn: listBackups_ },

  'community.list':     { perm: 'community.edit', fn: listCommunity_ },
  'community.jamaat':   { perm: 'community.edit', fn: saveJamaat_, write: true },
  'community.announce': { perm: 'community.edit', fn: saveAnnouncement_, write: true },
  'community.event':    { perm: 'community.edit', fn: saveEvent_, write: true },
  'community.program':  { perm: 'community.edit', fn: saveProgram_, write: true },
  'community.janazah':  { perm: 'community.edit', fn: saveJanazah_, write: true },
  'community.settings': { perm: 'community.edit', fn: saveCommunitySettings_, write: true },
  'community.qr':       { perm: 'community.edit', fn: saveQr_, write: true },
  'community.publish':  { perm: 'community.edit', fn: publishNow_, write: true },
  'community.ramadanSync': { perm: 'community.edit', fn: ramadanSync_, write: true },
  'community.resync':   { perm: 'community.edit', fn: resyncCalendar_, write: true },
  'community.calendarPublic': { perm: 'settings.edit', fn: makeCalendarPublic_, write: true },
  'community.requests': { perm: 'community.requests', fn: listRequests_ },
  'community.requestUpdate': { perm: 'community.requests', fn: updateRequest_, write: true }
  });
}

/** PUBLIC: single API gateway. */
function api(token, action, payload) {
  var t0 = Date.now();
  try {
    if (typeof action !== 'string') fail_('Bad request.');
    var defs = actions_();
    if (!Object.prototype.hasOwnProperty.call(defs, action)) fail_('Unknown action.');
    var def = defs[action];
    if (props_().getProperty('SCHEMA_VERSION') !== APP.SCHEMA_VERSION)
      fail_('The system was updated. The owner must run setup() once in the Apps Script editor before it can be used.');
    var user = requireSession_(token);
    if (yes_(user.MustChangePassword) && ['bootstrap', 'auth.logout', 'auth.changePassword'].indexOf(action) < 0)
      fail_('Please change your temporary password first.');
    if (!(def.altPerm && can_(user, def.altPerm))) requirePerm_(user, def.perm);
    if (payload === undefined || payload === null) payload = {};
    if (typeof payload !== 'object' || Array.isArray(payload)) fail_('Bad request.');
    if (JSON.stringify(payload).length > 14 * 1048576) fail_('Request is too large.');
    var ctx = { user: user, now: nowStr_(), audit: [], posted: false };
    var result;
    if (def.write) {
      result = withLock_(function () {
        var r = def.fn(ctx, payload);
        if (ctx.publish) {
          try { publishPublic_(ctx); } catch (pe) { console.warn('publish: ' + pe); if (r && typeof r === 'object' && !Array.isArray(r)) r.warning = 'Saved, but the public website could not be refreshed. Use "Publish now".'; }
        }
        flushAudit_(ctx);
        return r;
      });
      CacheService.getScriptCache().remove('DASH');
    } else {
      result = def.fn(ctx, payload);
      if (ctx.audit.length) withLock_(function () { flushAudit_(ctx); }, 10000);
    }
    trackUsage_(Date.now() - t0);
    return JSON.parse(JSON.stringify({ ok: true, data: result === undefined ? null : result }));
  } catch (e) {
    var msg = cleanErr_(e);
    if (e && e.userFacing) {
      if (!/^AUTH:/.test(msg)) console.warn(action + ': ' + msg);
      throw new Error(msg);
    }
    // Unexpected internal error: log the details for the owner, show the user only a reference.
    var ref = Utilities.getUuid().slice(0, 8).toUpperCase();
    console.error('[' + ref + '] ' + action + ': ' + (e && e.stack ? e.stack : msg));
    throw new Error('Something went wrong (ref ' + ref + '). Please check your entry and try again; if it repeats, tell the Admin.');
  }
}

function bootstrap_(ctx) {
  var u = ctx.user, out = { user: publicUser_(u), app: { name: APP.NAME, version: APP.VERSION }, roles: ROLE_LABELS };
  if (yes_(u.MustChangePassword)) return out;
  out.settings = publicSettings_();
  out.today = today_();
  out.fy = fyLabel_(out.today);
  out.groups = GROUPS;
  out.modes = PAY_MODES;
  out.frequencies = FREQUENCIES;
  out.community = can_(u, 'community.edit');
  var finRole = ['vouchers.view', 'vouchers.own', 'income.create', 'collection.create', 'expense.create', 'members.view'].some(function (x) { return can_(u, x); });
  if (can_(u, 'settings.edit') || can_(u, 'community.edit')) out.settingsMeta = DEFAULT_SETTINGS;
  if (!finRole) { out.prayers = PRAYERS; return out; }
  out.ledgers = read_(SH.LEDGERS).map(strip_);
  var fin = can_(u, 'vouchers.view');
  out.accounts = read_(SH.ACCOUNTS).map(function (a) {
    var o = strip_(a);
    if (!fin) { delete o.BankName; delete o.AccountNoMasked; delete o.IFSC; delete o.OpeningBalance; }
    return o;
  });
  out.funds = read_(SH.FUNDS).map(strip_);
  out.plans = read_(SH.PLANS).map(strip_);
  if (can_(u, 'members.view')) {
    var contacts = can_(u, 'members.contacts');
    out.members = read_(SH.MEMBERS).map(function (m) {
      return { MemberID: m.MemberID, MemberNo: m.MemberNo, Name: m.Name, PlanID: m.PlanID, Status: m.Status,
        Phone: contacts ? m.Phone : (m.Phone ? 'XXXXXX' + String(m.Phone).replace(/\D/g, '').slice(-4) : ''), Email: contacts ? m.Email : '' };
    });
  }
  if (can_(u, 'expense.approve')) out.pendingApprovals = read_(SH.APPROVALS).filter(function (a) { return a.Decision === 'PENDING'; }).length;
  return out;
}
