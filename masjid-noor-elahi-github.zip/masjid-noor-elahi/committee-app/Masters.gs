/**
 * Masters.gs — Members, Plans, Ledgers (Chart of Accounts), Cash & Bank, Funds, Budgets, Settings.
 * Masters can be edited (with before/after audit); they are deactivated, never deleted.
 */

function ledgerMap_() {
  if (_memo.lm) return _memo.lm;
  var m = Object.create(null);
  read_(SH.LEDGERS).forEach(function (l) {
    m[l.LedgerID] = { id: l.LedgerID, name: l.Name, group: l.Group, nature: l.Nature, fund: l.FundID, status: l.Status, cash: false };
  });
  read_(SH.ACCOUNTS).forEach(function (a) {
    m[a.AccountID] = { id: a.AccountID, name: a.Name, group: a.Type === 'Bank' ? 'Bank Accounts' : 'Cash-in-Hand',
      nature: 'Asset', status: a.Status, cash: true, type: a.Type, fund: '' };
  });
  return (_memo.lm = m);
}

function activeLedger_(id, natures, label) {
  var l = ledgerMap_()[id];
  if (!l) fail_((label || 'Ledger') + ' not found.');
  if (l.status !== 'Active') fail_((label || 'Ledger') + ' "' + l.name + '" is inactive.');
  if (natures && natures.indexOf(l.nature) < 0) fail_((label || 'Ledger') + ' "' + l.name + '" cannot be used here.');
  return l;
}
function activeAccount_(id, label) {
  var l = ledgerMap_()[id];
  if (!l || !l.cash) fail_((label || 'Cash/Bank account') + ' not found.');
  if (l.status !== 'Active') fail_((label || 'Account') + ' "' + l.name + '" is inactive.');
  return l;
}
function activeFund_(id) {
  var f = findById_(SH.FUNDS, id || GEN_FUND);
  if (!f) fail_('Fund not found.');
  if (f.Status !== 'Active') fail_('Fund "' + f.Name + '" is inactive.');
  return f;
}
/** Names are compared by a look-alike-proof key, so "Cash in Hаnd" (Cyrillic а) cannot impersonate "Cash in Hand". */
function nameTaken_(name, exceptId) {
  var k = nameKey_(name), lm = ledgerMap_();
  if (!k) fail_('Name must contain letters or numbers.');
  return Object.keys(lm).some(function (id) { return id !== exceptId && nameKey_(lm[id].name) === k; });
}
function hasEntries_(ledgerId) {
  return read_(SH.GL).some(function (e) { return e.LedgerID === ledgerId && e.Status !== 'CANCELLED'; });
}
function hasLockedEntries_(ledgerId) {
  var lock = String(setting_('LOCK_DATE') || '');
  return !!lock && read_(SH.GL).some(function (e) { return e.LedgerID === ledgerId && e.Status !== 'CANCELLED' && e.Date <= lock; });
}
function isAdmin_(ctx) { return ctx.user.Role === 'ADMIN'; }
function requireAdmin_(ctx, what) { if (!isAdmin_(ctx)) fail_('Only an Admin can ' + what + '.'); }

/* ---------------- Members ---------------- */

/** Collectors only see what they need to find a member (no phone, email, address or private notes). */
function listMembers_(ctx) {
  var full = can_(ctx.user, 'members.contacts');
  return read_(SH.MEMBERS).map(function (m) {
    return full ? strip_(m) : { MemberID: m.MemberID, MemberNo: m.MemberNo, Name: m.Name, PlanID: m.PlanID, Status: m.Status, JoinDate: m.JoinDate,
      Phone: m.Phone ? 'XXXXXX' + String(m.Phone).replace(/\D/g, '').slice(-4) : '' };
  });
}

function saveMember_(ctx, p) {
  var rec = {
    Name: V.str(p.Name, 'Name', { req: true, max: 100 }),
    Phone: V.phone(p.Phone),
    Email: V.email(p.Email),
    Address: V.str(p.Address, 'Address', { max: 300, multi: true }),
    FamilySize: (p.FamilySize === '' || p.FamilySize == null) ? '' : Math.max(0, Math.min(99, parseInt(p.FamilySize, 10) || 0)),
    PlanID: V.str(p.PlanID, 'Plan', { max: 30 }),
    JoinDate: p.JoinDate ? V.date(p.JoinDate, 'Join date') : today_(),
    Status: V.oneOf(p.Status || 'Active', ['Active', 'Inactive', 'Moved', 'Deceased'], 'Status'),
    Notes: V.str(p.Notes, 'Notes', { max: 500, multi: true })
  };
  if (rec.PlanID) {
    var pl = findById_(SH.PLANS, rec.PlanID);
    if (!pl || pl.Status !== 'Active') fail_('Selected membership plan is not active.');
  }
  if (!p.MemberID) {
    rec.MemberID = newId_('MEM');
    rec.MemberNo = 'M' + pad_(nextSeq_('MEMBERNO'), 4);
    rec.CreatedAt = ctx.now; rec.CreatedBy = ctx.user.Email;
    append_(SH.MEMBERS, [rec]);
    audit_(ctx, 'CREATE', 'Member', rec.MemberID, rec);
    return strip_(rec);
  }
  var cur = findById_(SH.MEMBERS, p.MemberID);
  if (!cur) fail_('Member not found.');
  var before = pick_(cur, Object.keys(rec));
  Object.keys(rec).forEach(function (k) { cur[k] = rec[k]; });
  cur.UpdatedAt = ctx.now; cur.UpdatedBy = ctx.user.Email;
  update_(SH.MEMBERS, cur);
  audit_(ctx, 'UPDATE', 'Member', cur.MemberID, { before: before, after: rec });
  return strip_(cur);
}

/* ---------------- Membership plans ---------------- */

function savePlan_(ctx, p) {
  var rec = {
    Name: V.str(p.Name, 'Plan name', { req: true, max: 80 }),
    Frequency: V.oneOf(p.Frequency, FREQUENCIES, 'Frequency'),
    Amount: V.amount(p.Amount, 'Amount'),
    IncomeLedgerID: activeLedger_(p.IncomeLedgerID, ['Income'], 'Income ledger').id,
    Description: V.str(p.Description, 'Description', { max: 300, multi: true }),
    Status: V.oneOf(p.Status || 'Active', ['Active', 'Inactive'], 'Status')
  };
  var pk = nameKey_(rec.Name);
  if (read_(SH.PLANS).some(function (x) { return x.PlanID !== p.PlanID && nameKey_(x.Name) === pk; })) fail_('A plan with a similar name already exists.');
  if (!p.PlanID) {
    rec.PlanID = newId_('PLN'); rec.CreatedAt = ctx.now; rec.CreatedBy = ctx.user.Email;
    append_(SH.PLANS, [rec]);
    audit_(ctx, 'CREATE', 'Plan', rec.PlanID, rec);
    return strip_(rec);
  }
  var cur = findById_(SH.PLANS, p.PlanID);
  if (!cur) fail_('Plan not found.');
  var before = pick_(cur, Object.keys(rec));
  Object.keys(rec).forEach(function (k) { cur[k] = rec[k]; });
  cur.UpdatedAt = ctx.now; cur.UpdatedBy = ctx.user.Email;
  update_(SH.PLANS, cur);
  audit_(ctx, 'UPDATE', 'Plan', cur.PlanID, { before: before, after: rec, note: 'Already generated dues keep their old amount.' });
  return strip_(cur);
}

/* ---------------- Ledgers (Chart of Accounts) ---------------- */

function saveLedger_(ctx, p) {
  var name = V.str(p.Name, 'Ledger name', { req: true, max: 80 });
  var groups = Object.keys(GROUPS).filter(function (g) { return CASH_GROUPS.indexOf(g) < 0; });
  var group = V.oneOf(p.Group, groups, 'Group');
  var nature = GROUPS[group];
  var fund = p.FundID ? activeFund_(p.FundID).FundID : GEN_FUND;
  if (nameTaken_(name, p.LedgerID)) fail_('A ledger or account named "' + name + '" already exists.');

  if (!p.LedgerID) {
    var ob = V.amount(p.OpeningBalance, 'Opening balance', { allowZero: true });
    var obType = nature === 'Asset' ? 'Dr' : 'Cr'; // assets open Dr, liabilities/funds open Cr — never reversed
    if (ob && (nature === 'Income' || nature === 'Expense')) fail_('Income and expense ledgers cannot have an opening balance.');
    if (ob) requireAdmin_(ctx, 'enter opening balances');
    var fobj = findById_(SH.FUNDS, fund);
    if (fobj && fobj.Type === 'Restricted' && !isAdmin_(ctx)) fail_('Only an Admin can create ledgers for a restricted fund.');
    var rec = { LedgerID: newId_('LED'), Name: name, Group: group, Nature: nature, FundID: fund, OpeningBalance: ob,
      OpeningType: obType, IsSystem: 'NO', Status: 'Active', CreatedAt: ctx.now, CreatedBy: ctx.user.Email };
    append_(SH.LEDGERS, [rec]);
    if (ob) postOpening_(ctx, rec.LedgerID, fund, ob, obType, 'Opening balance — ' + name);
    audit_(ctx, 'CREATE', 'Ledger', rec.LedgerID, rec);
    return strip_(rec);
  }
  var cur = findById_(SH.LEDGERS, p.LedgerID);
  if (!cur) fail_('Ledger not found.');
  var status = V.oneOf(p.Status || cur.Status, ['Active', 'Inactive'], 'Status');
  if (cur.IsSystem === 'YES' && (status !== 'Active' || group !== cur.Group)) fail_('System ledgers cannot be deactivated or regrouped.');
  if (nature !== cur.Nature && hasEntries_(cur.LedgerID)) fail_('This ledger has entries; it can only move to a group of the same nature (' + cur.Nature + ').');
  if ((group !== cur.Group || fund !== cur.FundID) && hasLockedEntries_(cur.LedgerID)) fail_('This ledger has entries in the locked (closed) period; its group and fund cannot change.');
  if ((name !== cur.Name || group !== cur.Group || fund !== cur.FundID) && hasEntries_(cur.LedgerID)) requireAdmin_(ctx, 'rename, regroup or re-fund a ledger that already has entries');
  var before = pick_(cur, ['Name', 'Group', 'Nature', 'FundID', 'Status']);
  cur.Name = name; cur.Group = group; cur.Nature = nature; cur.FundID = fund; cur.Status = status;
  cur.UpdatedAt = ctx.now; cur.UpdatedBy = ctx.user.Email;
  update_(SH.LEDGERS, cur);
  audit_(ctx, 'UPDATE', 'Ledger', cur.LedgerID, { before: before, after: pick_(cur, ['Name', 'Group', 'Nature', 'FundID', 'Status']) });
  return strip_(cur);
}

/** Opening balances are posted against General Fund (Corpus) so the Trial Balance always tallies. */
function postOpening_(ctx, ledgerId, fundId, amount, type, narration) {
  var d = String(setting_('BOOKS_BEGIN_DATE') || today_());
  checkLock_(d);
  var src = 'OPN-' + ledgerId;
  var lines = type === 'Dr'
    ? [{ l: ledgerId, f: fundId, dr: amount, cr: 0 }, { l: CORPUS, f: GEN_FUND, dr: 0, cr: amount }]
    : [{ l: ledgerId, f: fundId, dr: 0, cr: amount }, { l: CORPUS, f: GEN_FUND, dr: amount, cr: 0 }];
  postGL_(ctx, { type: 'OPENING', no: 'OPENING', src: src, date: d, narration: narration }, lines);
}

/* ---------------- Cash & Bank accounts ---------------- */

function saveAccount_(ctx, p) {
  var name = V.str(p.Name, 'Account name', { req: true, max: 80 });
  var type = V.oneOf(p.Type, ['Cash', 'Bank'], 'Type');
  if (nameTaken_(name, p.AccountID)) fail_('A ledger or account named "' + name + '" already exists.');
  var digits = String(p.AccountNo || '').replace(/\D/g, '');
  var rec = {
    Name: name, Type: type,
    BankName: V.str(p.BankName, 'Bank name', { max: 80 }),
    IFSC: V.str(p.IFSC, 'IFSC', { max: 15 }).toUpperCase(),
    Status: V.oneOf(p.Status || 'Active', ['Active', 'Inactive'], 'Status')
  };
  if (rec.IFSC && !/^[A-Z]{4}0[A-Z0-9]{6}$/.test(rec.IFSC)) fail_('IFSC code is not valid.');
  if (digits) rec.AccountNoMasked = 'XXXX' + digits.slice(-4); // never store the full account number

  if (!p.AccountID) {
    requireAdmin_(ctx, 'create a new cash or bank account');
    var ob = V.amount(p.OpeningBalance, 'Opening balance', { allowZero: true });
    rec.AccountID = newId_('ACC'); rec.OpeningBalance = ob;
    rec.OpeningDate = String(setting_('BOOKS_BEGIN_DATE') || today_());
    rec.CreatedAt = ctx.now; rec.CreatedBy = ctx.user.Email;
    append_(SH.ACCOUNTS, [rec]);
    if (ob) postOpening_(ctx, rec.AccountID, GEN_FUND, ob, 'Dr', 'Opening balance — ' + name);
    audit_(ctx, 'CREATE', 'Account', rec.AccountID, rec);
    return strip_(rec);
  }
  var cur = findById_(SH.ACCOUNTS, p.AccountID);
  if (!cur) fail_('Account not found.');
  if (type !== cur.Type && hasEntries_(cur.AccountID)) fail_('Account type cannot change after entries exist.');
  if ((name !== cur.Name || type !== cur.Type || rec.Status !== cur.Status) && !isAdmin_(ctx)) fail_('Only an Admin can rename, retype or deactivate an account.');
  // Admin may set the opening balance once, while the account has no entries at all (e.g. the default Cash in Hand).
  var ob2 = V.amount(p.OpeningBalance, 'Opening balance', { allowZero: true });
  if (ob2 && round2_(ob2) !== round2_(num_(cur.OpeningBalance))) {
    requireAdmin_(ctx, 'enter opening balances');
    if (hasEntries_(cur.AccountID)) fail_('Opening balance can only be set before the account has any entries.');
    rec.OpeningBalance = ob2;
    postOpening_(ctx, cur.AccountID, GEN_FUND, ob2, 'Dr', 'Opening balance — ' + name);
  }
  if (rec.Status === 'Inactive' && round2_(accountBalance_(cur.AccountID)) !== 0) fail_('Transfer the balance out before deactivating this account.');
  var before = pick_(cur, Object.keys(rec));
  Object.keys(rec).forEach(function (k) { cur[k] = rec[k]; });
  cur.UpdatedAt = ctx.now; cur.UpdatedBy = ctx.user.Email;
  update_(SH.ACCOUNTS, cur);
  audit_(ctx, 'UPDATE', 'Account', cur.AccountID, { before: before, after: rec });
  return strip_(cur);
}

/* ---------------- Funds ---------------- */

function saveFund_(ctx, p) {
  requireAdmin_(ctx, 'create or change funds');
  var rec = {
    Name: V.str(p.Name, 'Fund name', { req: true, max: 60 }),
    Type: V.oneOf(p.Type, ['Unrestricted', 'Restricted'], 'Type'),
    RestrictSpending: V.oneOf(p.RestrictSpending || 'NO', ['YES', 'NO'], 'Restrict spending'),
    Description: V.str(p.Description, 'Description', { max: 200 }),
    Status: V.oneOf(p.Status || 'Active', ['Active', 'Inactive'], 'Status')
  };
  var fk = nameKey_(rec.Name);
  if (read_(SH.FUNDS).some(function (f) { return f.FundID !== p.FundID && nameKey_(f.Name) === fk; })) fail_('A fund with a similar name already exists.');
  if (!p.FundID) {
    rec.FundID = newId_('FND'); rec.CreatedAt = ctx.now; rec.CreatedBy = ctx.user.Email;
    append_(SH.FUNDS, [rec]);
    audit_(ctx, 'CREATE', 'Fund', rec.FundID, rec);
    return strip_(rec);
  }
  var cur = findById_(SH.FUNDS, p.FundID);
  if (!cur) fail_('Fund not found.');
  if (cur.FundID === GEN_FUND && (rec.Status !== 'Active' || rec.Type !== 'Unrestricted')) fail_('General Fund must stay active and unrestricted.');
  if (cur.Type === 'Restricted' && rec.Type !== 'Restricted' && round2_(fundBalances_()[cur.FundID] || 0) !== 0) fail_('A restricted fund with a balance cannot be made unrestricted.');
  if (rec.Status !== 'Active' && round2_(fundBalances_()[cur.FundID] || 0) !== 0) fail_('A fund with a balance cannot be deactivated.');
  var before = pick_(cur, Object.keys(rec));
  Object.keys(rec).forEach(function (k) { cur[k] = rec[k]; });
  update_(SH.FUNDS, cur);
  audit_(ctx, 'UPDATE', 'Fund', cur.FundID, { before: before, after: rec });
  return strip_(cur);
}

/* ---------------- Budgets ---------------- */

function listBudgets_(ctx, p) {
  var fy = p && p.FY ? String(p.FY) : '';
  return read_(SH.BUDGETS).filter(function (b) { return !fy || b.FY === fy; }).map(strip_);
}

function saveBudget_(ctx, p) {
  var fy = V.str(p.FY, 'Financial year', { req: true, max: 7 });
  if (!/^\d{4}(-\d{2})?$/.test(fy)) fail_('Financial year must look like 2026-27.');
  var led = activeLedger_(p.LedgerID, ['Income', 'Expense'], 'Ledger');
  var amt = V.amount(p.Amount, 'Budget amount', { allowZero: true });
  var cur = read_(SH.BUDGETS).filter(function (b) { return b.FY === fy && b.LedgerID === led.id; })[0];
  if (cur) {
    var before = cur.Amount;
    cur.Amount = amt; cur.Notes = V.str(p.Notes, 'Notes', { max: 200 }); cur.UpdatedAt = ctx.now; cur.UpdatedBy = ctx.user.Email;
    update_(SH.BUDGETS, cur);
    audit_(ctx, 'UPDATE', 'Budget', cur.BudgetID, { before: before, after: amt });
    return strip_(cur);
  }
  var rec = { BudgetID: newId_('BUD'), FY: fy, LedgerID: led.id, Amount: amt, Notes: V.str(p.Notes, 'Notes', { max: 200 }),
    CreatedAt: ctx.now, CreatedBy: ctx.user.Email };
  append_(SH.BUDGETS, [rec]);
  audit_(ctx, 'CREATE', 'Budget', rec.BudgetID, rec);
  return strip_(rec);
}

/* ---------------- Settings ---------------- */

var MULTILINE_SETTINGS = { MASJID_ADDRESS: 1, DONATE_NOTE: 1, PUBLIC_CONTACTS: 1, FACILITIES: 1, ABOUT_TEXT: 1, ABOUT_TEXT_UR: 1, RAMADAN_NOTE: 1 };
/** Only https links to well-known free services may be published. */
var SAFE_LINK_HOSTS = /^https:\/\/((www\.)?google\.[a-z.]+\/maps|maps\.app\.goo\.gl|goo\.gl\/maps|maps\.google\.[a-z.]+|chat\.whatsapp\.com|(www\.)?whatsapp\.com\/channel|t\.me|script\.google\.com\/macros\/s\/)[^\s<>"']*$/i;

function settingValue_(d, v, ctx) {
  var k = d[0], type = d[3], label = d[2];
  if (type === 'text') return V.str(v, label, { max: MULTILINE_SETTINGS[k] ? 1500 : 300, multi: !!MULTILINE_SETTINGS[k] });
  if (type === 'int') { v = String(v).trim(); if (!/^\d{1,6}$/.test(v)) fail_(label + ': enter a whole number.'); return v; }
  if (type === 'money') return String(V.amount(v, label, { allowZero: true }));
  if (type === 'yesno') return V.oneOf(String(v).toUpperCase(), ['YES', 'NO'], label);
  if (type === 'month') { v = String(v).trim(); if (!(+v >= 1 && +v <= 12)) fail_('Month must be 1–12.'); return v; }
  if (type === 'date') { v = String(v || '').trim(); if (v) V.date(v, label); if (v && v > today_()) fail_(label + ' cannot be in the future.'); return v; }
  if (type === 'cdate') { v = String(v || '').trim(); if (v) V.date(v, label); return v; }
  if (type === 'time') { v = String(v || '').trim(); if (v && !/^([01]\d|2[0-3]):[0-5]\d$/.test(v)) fail_(label + ': use 24-hour time like 13:30.'); return v; }
  if (type === 'coord') {
    v = String(v || '').trim(); if (!v) return v;
    if (!/^-?\d{1,3}(\.\d{1,8})?$/.test(v)) fail_(label + ': enter a decimal number like 17.385044.');
    var lim = k === 'LATITUDE' ? 90 : 180; if (Math.abs(+v) > lim) fail_(label + ' is out of range.'); return v;
  }
  if (type === 'angle') { v = String(v).trim(); if (!/^\d{1,2}(\.\d{1,2})?$/.test(v) || +v < 10 || +v > 22) fail_(label + ' must be between 10 and 22.'); return v; }
  if (type === 'signed') { v = String(v).trim(); if (!/^[-+]?[0-2]$/.test(v)) fail_(label + ' must be between -2 and 2.'); return String(+v); }
  if (type === 'asr') return V.oneOf(String(v), ['Hanafi', 'Shafi'], label);
  if (type === 'upi') { v = String(v || '').trim(); if (v && !/^[a-zA-Z0-9.\-_]{2,64}@[a-zA-Z]{2,64}$/.test(v)) fail_(label + ' is not a valid UPI ID.'); return v; }
  if (type === 'url') { v = String(v || '').trim(); if (v && (v.length > 300 || !SAFE_LINK_HOSTS.test(v))) fail_(label + ': only https links to Google Maps, WhatsApp, Telegram or the Apps Script site are allowed.'); return v; }
  fail_('Unknown setting type.');
}

/** group: undefined = any setting (Admin), 'community' = only community website settings. */
function saveSettings_(ctx, p, group) {
  var input = (p && typeof p.settings === 'object' && p.settings) || {}, rows = read_(SH.SETTINGS), byKey = {}, changed = [];
  rows.forEach(function (r) { byKey[r.Key] = r; });
  DEFAULT_SETTINGS.forEach(function (d) {
    var k = d[0], type = d[3];
    if (!Object.prototype.hasOwnProperty.call(input, k)) return;
    if (group && d[4] !== group) fail_('You cannot change the setting "' + d[2] + '".');
    var v = settingValue_(d, input[k], ctx);
    if (k === 'SESSION_HOURS' && !(+v >= 1 && +v <= 6)) fail_('Session hours must be 1–6.');
    if (k === 'LOCK_DATE' && byKey[k] && byKey[k].Value && (!v || v < byKey[k].Value)) {
      CacheService.getScriptCache().remove('QUOTA');
      props_().setProperty('LAST_UNLOCK', JSON.stringify({ by: ctx.user.Email, at: ctx.now, from: byKey[k].Value, to: v || '(none)' }));
      audit_(ctx, 'UNLOCK_BOOKS', 'Settings', 'LOCK_DATE', { from: byKey[k].Value, to: v || '' });
    }
    if (k === 'FY_START_MONTH' && String(byKey[k] ? byKey[k].Value : '') !== v && read_(SH.GL).length > 0)
      fail_('Financial year start cannot change after vouchers exist (voucher numbers depend on it).');
    var r = byKey[k];
    if (r && String(r.Value) === String(v)) return;
    if (r) {
      changed.push({ key: k, before: r.Value, after: v });
      r.Value = v; r.UpdatedAt = ctx.now; r.UpdatedBy = ctx.user.Email;
    } else {
      r = { Key: k, Value: v, Description: d[2], UpdatedAt: ctx.now, UpdatedBy: ctx.user.Email };
      append_(SH.SETTINGS, [r]); byKey[k] = r;
      changed.push({ key: k, before: '', after: v });
    }
  });
  var toUpdate = rows.filter(function (r) { return changed.some(function (c) { return c.key === r.Key; }); });
  updateMany_(SH.SETTINGS, toUpdate);
  if (changed.length) { audit_(ctx, 'UPDATE', 'Settings', '', changed); ctx.publish = true; }
  ctx.changedSettings = changed.map(function (c) { return c.key; });
  return publicSettings_();
}

function publicSettings_() {
  var s = settings_(), out = {};
  DEFAULT_SETTINGS.forEach(function (d) { out[d[0]] = s[d[0]]; });
  return out;
}
