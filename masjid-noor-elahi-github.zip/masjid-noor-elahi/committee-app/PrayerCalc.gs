/**
 * PrayerCalc.gs — offline prayer-time and Hijri calculation (no internet, no paid API).
 * The SAME code is shipped to the public website (community/PrayerCalc.html), so the
 * website and the Google Calendar always show identical times.
 *
 * Method: University of Islamic Sciences, Karachi — Fajr 18°, Isha 18°; Asr Hanafi (shadow factor 2).
 * Sun position: standard low-precision solar coordinates (accurate to ~1 minute for prayer times).
 */
var MasjidTimes = (function () {
  function rad(d) { return d * Math.PI / 180; }
  function deg(r) { return r * 180 / Math.PI; }
  function sin(d) { return Math.sin(rad(d)); }
  function cos(d) { return Math.cos(rad(d)); }
  function tan(d) { return Math.tan(rad(d)); }
  function asin(x) { return deg(Math.asin(x)); }
  function acos(x) { return deg(Math.acos(Math.max(-1, Math.min(1, x)))); }
  function atan2(y, x) { return deg(Math.atan2(y, x)); }
  function acot(x) { return deg(Math.atan(1 / x)); }
  function fix(a, b) { a = a - b * Math.floor(a / b); return a < 0 ? a + b : a; }

  function julian(y, m, d) {
    if (m <= 2) { y -= 1; m += 12; }
    var A = Math.floor(y / 100), B = 2 - A + Math.floor(A / 4);
    return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
  }
  function sun(jd) {
    var D = jd - 2451545.0;
    var g = fix(357.529 + 0.98560028 * D, 360), q = fix(280.459 + 0.98564736 * D, 360);
    var L = fix(q + 1.915 * sin(g) + 0.020 * sin(2 * g), 360);
    var e = 23.439 - 0.00000036 * D;
    var RA = atan2(cos(e) * sin(L), cos(L)) / 15;
    return { decl: asin(sin(e) * sin(L)), eqt: q / 15 - fix(RA, 24) };
  }

  var DEFAULTS = { fajrAngle: 18, ishaAngle: 18, asrFactor: 2, dhuhrMin: 1, maghribMin: 0, elevation: 0 };

  /** Prayer times for a calendar date at lat/lng, tz = UTC offset in hours (India 5.5).
   *  Returns minutes after local midnight: {fajr, sunrise, dhuhr, asr, maghrib, isha}. */
  function compute(y, m, d, o) {
    var p = {}; for (var k in DEFAULTS) p[k] = DEFAULTS[k]; for (k in o) p[k] = o[k];
    var lat = +p.lat, lng = +p.lng, tz = +p.tz;
    var jd0 = julian(y, m, d) - lng / (15 * 24);
    function midDay(t) { return fix(12 - sun(jd0 + t).eqt, 24); }
    function angleTime(angle, t, ccw) {
      var s = sun(jd0 + t), noon = midDay(t);
      var T = acos((-sin(angle) - sin(s.decl) * sin(lat)) / (cos(s.decl) * cos(lat))) / 15;
      return noon + (ccw ? -T : T);
    }
    function asrTime(t) {
      var s = sun(jd0 + t);
      return angleTime(-acot(p.asrFactor + tan(Math.abs(lat - s.decl))), t);
    }
    var riseSet = 0.833 + 0.0347 * Math.sqrt(p.elevation || 0);
    var t = { fajr: 5, sunrise: 6, dhuhr: 12, asr: 13, maghrib: 18, isha: 18 };
    for (var i = 0; i < 2; i++) { // iterate: use the previous estimate as the time of day for the sun position
      var f = function (h) { return h / 24; };
      t = {
        fajr: angleTime(p.fajrAngle, f(t.fajr), true),
        sunrise: angleTime(riseSet, f(t.sunrise), true),
        dhuhr: midDay(f(t.dhuhr)),
        asr: asrTime(f(t.asr)),
        maghrib: angleTime(riseSet, f(t.maghrib)),
        isha: angleTime(p.ishaAngle, f(t.isha))
      };
    }
    var adj = tz - lng / 15, out = {};
    for (k in t) out[k] = Math.round((fix(t[k] + adj, 24)) * 60);
    out.dhuhr += p.dhuhrMin; out.maghrib += p.maghribMin;
    return out;
  }

  function hhmm(min, twelve) {
    min = ((Math.round(min) % 1440) + 1440) % 1440;
    var h = Math.floor(min / 60), mi = min % 60;
    if (!twelve) return (h < 10 ? '0' : '') + h + ':' + (mi < 10 ? '0' : '') + mi;
    var ap = h >= 12 ? 'PM' : 'AM', h12 = h % 12 || 12;
    return h12 + ':' + (mi < 10 ? '0' : '') + mi + ' ' + ap;
  }
  function toMin(s) { var m = /^(\d{1,2}):(\d{2})$/.exec(String(s || '')); return m ? (+m[1]) * 60 + (+m[2]) : null; }

  /** Tabular Islamic (Kuwaiti) calendar + committee adjustment (moon sighting), e.g. adjust = -1. */
  var HIJRI_EN = ['Muharram', 'Safar', 'Rabi al-Awwal', 'Rabi al-Thani', 'Jumada al-Ula', 'Jumada al-Akhirah', 'Rajab', 'Shaban', 'Ramadan', 'Shawwal', 'Dhul Qadah', 'Dhul Hijjah'];
  var HIJRI_UR = ['محرم', 'صفر', 'ربیع الاول', 'ربیع الثانی', 'جمادی الاول', 'جمادی الثانی', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذوالقعدہ', 'ذوالحجہ'];
  function hijri(y, m, d, adjust) {
    var jd = Math.floor(julian(y, m, d) + 0.5) + (adjust || 0);
    var l = jd - 1948440 + 10632, n = Math.floor((l - 1) / 10631);
    l = l - 10631 * n + 354;
    var j = Math.floor((10985 - l) / 5316) * Math.floor((50 * l) / 17719) + Math.floor(l / 5670) * Math.floor((43 * l) / 15238);
    l = l - Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) - Math.floor(j / 16) * Math.floor((15238 * j) / 43) + 29;
    var hm = Math.floor((24 * l) / 709), hd = l - Math.floor((709 * hm) / 24), hy = 30 * n + j - 30;
    return { y: hy, m: hm, d: hd, en: HIJRI_EN[hm - 1], ur: HIJRI_UR[hm - 1] };
  }

  return { compute: compute, hhmm: hhmm, toMin: toMin, hijri: hijri, julian: julian, DEFAULTS: DEFAULTS };
})();
