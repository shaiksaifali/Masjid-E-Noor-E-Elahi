/**
 * Vouchers.gs — Tally-style vouchers with double-entry posting and maker-checker controls.
 *   Receipt (F6)  → Income sheet           RV/FY/nnnnn   Dr Cash/Bank, Cr Income ledger
 *   Payment (F5)  → Expenses sheet         PV/FY/nnnnn   Dr Expense ledger, Cr Cash/Bank
 *   Contra  (F4)  → Account Transfers      CV/FY/nnnnn   Dr To account, Cr From account
 *   Journal (F7)  → Journal Vouchers       JV/FY/nnnnn   balanced non-cash adjustments
 *   Membership collections are Receipt vouchers too (Membership.gs).
 *
 * Controls (all server-side):
 *  - Payments and Contra at/above the approval threshold — including several smaller ones to the same
 *    payee within 7 days, or by the same person on the same day — wait for an independent approver.
 *  - Payments without a bill above the bill limit always need approval.
 *  - Every Journal needs an independent approver, and journals may not touch cash or bank
 *    (cash only moves through Receipt / Payment / Contra, as in Tally).
 *  - Each fund's own cash is tracked; no fund (General included) can spend another fund's money.
 *  - Restricted funds (e.g. Zakat) can only be charged to ledgers designated for that fund.
 *  - Maker-checker compares user IDs, not editable emails.
 *  - Cancellation keeps the record (Tally "Cancel Voucher") and may not push cash or a fund negative.
 */

/** Validate and append balanced GL lines. lines: [{l: ledgerId, f: fundId, dr, cr, n}] */
function postGL_(ctx, v, lines) {
  var rows = buildGL_(ctx, v, lines);
  append_(SH.GL, rows);
  ctx.posted = true;
  return rows;
}

/** Build + validate GL rows without writing (call before writing source records). */
function buildGL_(ctx, v, lines) {
  var lm = ledgerMap_(), dr = 0, cr = 0;
  if (!lines || lines.length < 2) fail_('A voucher needs at least two ledger lines.');
  var rows = lines.map(function (x, i) {
    if (!lm[x.l]) fail_('Unknown ledger in voucher.');
    var d = round2_(x.dr || 0), c = round2_(x.cr || 0);
    if (d < 0 || c < 0 || (d > 0 && c > 0) || (d === 0 && c === 0)) fail_('Each voucher line must have either a debit or a credit.');
    dr += d; cr += c;
    return { EntryID: v.src + '-' + pad_(i + 1, 2), Date: v.date, VoucherType: v.type, VoucherNo: v.no, SourceID: v.src,
      LedgerID: x.l, FundID: x.f || lm[x.l].fund || GEN_FUND, Debit: d || '', Credit: c || '',
      Narration: x.n || v.narration || '', Status: 'ACTIVE', ClearedDate: '', CreatedAt: ctx.now, CreatedBy: ctx.user.Email };
  });
  if (round2_(dr) !== round2_(cr)) fail_('Voucher is not balanced: Debit ' + money_(dr) + ' ≠ Credit ' + money_(cr) + '.');
  return rows;
}
function appendGL_(ctx, rows) { append_(SH.GL, rows); ctx.posted = true; }

function glActive_() {
  if (_memo.gla) return _memo.gla;
  return (_memo.gla = read_(SH.GL).filter(function (e) { return e.Status !== 'CANCELLED'; }));
}

function accountBalance_(accId) {
  var b = 0;
  read_(SH.GL).forEach(function (e) {
    if (e.LedgerID === accId && e.Status !== 'CANCELLED') b += num_(e.Debit) - num_(e.Credit);
  });
  return round2_(b);
}

/** Fund balance (books) = credited to the fund (income, corpus/earmarked) minus spent from it. */
function fundBalances_(asOf) {
  var lm = ledgerMap_(), out = Object.create(null);
  read_(SH.GL).forEach(function (e) {
    if (e.Status === 'CANCELLED' || (asOf && e.Date > asOf)) return;
    var l = lm[e.LedgerID];
    if (!l) return;
    if (l.nature === 'Income' || l.nature === 'Expense' || FUND_GROUPS.indexOf(l.group) >= 0) {
      var f = e.FundID || GEN_FUND;
      out[f] = round2_((out[f] || 0) + num_(e.Credit) - num_(e.Debit));
    }
  });
  return out;
}

/** Liquid money each fund holds across all cash & bank accounts (cash lines carry the fund tag). */
function fundCash_() {
  var lm = ledgerMap_(), out = Object.create(null);
  read_(SH.GL).forEach(function (e) {
    if (e.Status === 'CANCELLED') return;
    var l = lm[e.LedgerID];
    if (!l || !l.cash) return;
    var f = e.FundID || GEN_FUND;
    out[f] = round2_((out[f] || 0) + num_(e.Debit) - num_(e.Credit));
  });
  return out;
}

function checkCash_(accId, amount) {
  if (yes_(setting_('ALLOW_NEGATIVE_CASH'))) return;
  var bal = accountBalance_(accId);
  if (round2_(bal - amount) < 0) fail_('Insufficient balance in "' + ledgerMap_()[accId].name + '" (available ₹' + money_(bal) + ').');
}
/** A fund can only spend the money it actually holds. */
function checkFund_(fundId, amount) {
  var f = activeFund_(fundId);
  if (!yes_(setting_('ENFORCE_FUND_BALANCE'))) return;
  var bal = fundCash_()[f.FundID] || 0;
  if (round2_(bal - amount) < 0) fail_('"' + f.Name + '" holds only ₹' + money_(bal) + '. Money from other funds (e.g. Zakat) cannot be used for this.');
}
/** Restricted funds may only be charged to ledgers designated for them. */
function checkFundUse_(fund, led) {
  if (fund.Type === 'Restricted' && led.fund !== fund.FundID)
    fail_('"' + fund.Name + '" is restricted. It can only be used with ledgers designated for it (e.g. "' + fund.Name.replace(' Fund', '') + ' Disbursement").');
}

function newReceipt_(ctx, r) {
  var rec = { ReceiptID: newId_('RCP'), ReceiptNo: 'RCPT/' + fyLabel_(r.date) + '/' + pad_(nextSeq_('RCPT_' + fyLabel_(r.date)), 5),
    Date: r.date, SourceType: r.type, SourceID: r.src, PartyName: r.party || 'Well-wisher', PartyPhone: r.phone || '',
    Amount: r.amount, AmountWords: amountWords_(r.amount), Purpose: r.purpose, Mode: r.mode, PdfFileID: '', Status: 'ACTIVE',
    CreatedAt: ctx.now, CreatedBy: ctx.user.Email };
  append_(SH.RECEIPTS, [rec]);
  return rec;
}

function threshold_() { return num_(setting_('APPROVAL_THRESHOLD')); }
function sameUser_(rec, ctx) {
  if (rec.CreatedByID) return rec.CreatedByID === ctx.user.UserID;
  return String(rec.CreatedBy).toLowerCase() === String(ctx.user.Email).toLowerCase();
}
function newApproval_(ctx, type, id, amount, reason) {
  var ap = { ApprovalID: newId_('APR'), SourceType: type, ExpenseID: id, Amount: amount, RequestedBy: ctx.user.Email,
    RequestedByID: ctx.user.UserID, RequestedAt: ctx.now, Decision: 'PENDING', Remarks: reason || '' };
  append_(SH.APPROVALS, [ap]);
  return ap;
}

/* ---------------- Receipt voucher (Income / Donation) — F6 ---------------- */

function createIncome_(ctx, p) {
  var date = V.date(p.Date || today_(), 'Date');
  checkVoucherDate_(ctx, date);
  var led = activeLedger_(p.LedgerID, ['Income'], 'Income ledger');
  var fund = activeFund_(p.FundID || led.fund || GEN_FUND);
  // Money given for a restricted purpose (e.g. Zakat) must land in that fund.
  var ledFund = findById_(SH.FUNDS, led.fund);
  if (ledFund && ledFund.Type === 'Restricted' && fund.FundID !== ledFund.FundID) fail_('"' + led.name + '" must be recorded in ' + ledFund.Name + '.');
  checkFundUse_(fund, led);
  var acc = activeAccount_(p.AccountID, 'Received into');
  var amount = V.amount(p.Amount, 'Amount');
  var mode = V.oneOf(p.Mode || 'Cash', PAY_MODES, 'Mode');
  if (acc.type === 'Cash' && mode !== 'Cash') fail_('Non-cash receipts must go into a bank account.');
  var rec = {
    IncomeID: newId_('INC'), Date: date, LedgerID: led.id, FundID: fund.FundID, Amount: amount, AccountID: acc.id, Mode: mode,
    Reference: V.str(p.Reference, 'Reference', { max: 60 }),
    DonorName: V.str(p.DonorName, 'Donor name', { max: 100 }),
    DonorPhone: V.phone(p.DonorPhone, 'Donor phone'),
    Narration: V.str(p.Narration, 'Narration', { max: 300, multi: true }),
    Status: 'POSTED', CreatedAt: ctx.now, CreatedBy: ctx.user.Email
  };
  rec.VoucherNo = voucherNo_('RV', date);
  var gl = buildGL_(ctx, { type: 'Receipt', no: rec.VoucherNo, src: rec.IncomeID, date: date, narration: rec.Narration || led.name + (rec.DonorName ? ' from ' + rec.DonorName : '') },
    [{ l: acc.id, f: fund.FundID, dr: amount }, { l: led.id, f: fund.FundID, cr: amount }]);
  rec.ProofFileID = saveUpload_(ctx, p.file, 'PROOFS', rec.IncomeID);
  var receipt = newReceipt_(ctx, { date: date, type: 'INCOME', src: rec.IncomeID, party: rec.DonorName, phone: rec.DonorPhone,
    amount: amount, purpose: led.name + (fund.FundID !== GEN_FUND ? ' (' + fund.Name + ')' : ''), mode: mode });
  rec.ReceiptID = receipt.ReceiptID;
  append_(SH.INCOME, [rec]);
  appendGL_(ctx, gl);
  audit_(ctx, 'CREATE', 'Income', rec.IncomeID, { voucher: rec.VoucherNo, amount: amount, ledger: led.name, fund: fund.FundID });
  return { record: strip_(rec), receipt: strip_(receipt) };
}

/* ---------------- Payment voucher (Expense) — F5, maker-checker ---------------- */

/** Why a payment needs approval ('' = it does not). Catches splitting a big payment into small ones. */
function paymentNeedsApproval_(ctx, rec, hasBill) {
  var t = threshold_(), amt = num_(rec.Amount);
  if (amt >= t) return 'Amount is at or above the approval limit.';
  if (amt > num_(setting_('BILL_REQUIRED_ABOVE')) && !hasBill) return 'No bill attached: ' + rec.NoBillReason;
  var payee = nameKey_(rec.PayeeName), from = addDays_(rec.Date, -6), sumPayee = 0, sumMine = 0;
  read_(SH.EXPENSES).forEach(function (e) {
    // Only payments that were posted WITHOUT an approval count towards the limit (approved ones were already checked).
    if (e.Status !== 'POSTED' || e.ApprovalID) return;
    if (e.Date >= from && e.Date <= rec.Date && nameKey_(e.PayeeName) === payee) sumPayee += num_(e.Amount);
    if (e.Date === rec.Date && sameUser_(e, ctx)) sumMine += num_(e.Amount);
  });
  if (sumPayee + amt >= t) return 'Payments to this payee in 7 days reach ₹' + money_(sumPayee + amt) + '.';
  if (sumMine + amt >= t) return 'Your payments today reach ₹' + money_(sumMine + amt) + '.';
  return '';
}

function createExpense_(ctx, p) {
  var date = V.date(p.Date || today_(), 'Date');
  checkVoucherDate_(ctx, date);
  var led = activeLedger_(p.LedgerID, ['Expense', 'Asset', 'Liability'], 'Expense ledger');
  if (led.cash) fail_('Use a Contra voucher to move money between cash and bank.');
  var fund = activeFund_(p.FundID || led.fund || GEN_FUND);
  checkFundUse_(fund, led);
  var acc = activeAccount_(p.AccountID, 'Paid from');
  var amount = V.amount(p.Amount, 'Amount');
  var mode = V.oneOf(p.Mode || 'Cash', PAY_MODES, 'Mode');
  if (acc.type === 'Cash' && mode !== 'Cash') fail_('Non-cash payments must be made from a bank account.');
  var rec = {
    ExpenseID: newId_('EXP'), VoucherNo: '', Date: date, LedgerID: led.id, FundID: fund.FundID, Amount: amount, AccountID: acc.id,
    Mode: mode, Reference: V.str(p.Reference, 'Reference', { max: 60 }),
    PayeeName: V.str(p.PayeeName, 'Paid to', { req: true, max: 100 }),
    Narration: V.str(p.Narration, 'Narration', { req: true, max: 300, multi: true }),
    NoBillReason: V.str(p.NoBillReason, 'Reason for no bill', { max: 200 }),
    CreatedAt: ctx.now, CreatedBy: ctx.user.Email, CreatedByID: ctx.user.UserID
  };
  var hasBill = !!(p.file && p.file.data);
  var billLimit = num_(setting_('BILL_REQUIRED_ABOVE'));
  if (amount > billLimit && !hasBill && rec.NoBillReason.length < 10)
    fail_('A bill/invoice upload is required for payments above ₹' + money_(billLimit) + ' (or give a reason of at least 10 characters — it will then need approval).');
  checkCash_(acc.id, amount);
  checkFund_(fund.FundID, amount);
  rec.BillFileID = saveUpload_(ctx, p.file, 'BILLS', rec.ExpenseID);

  var why = paymentNeedsApproval_(ctx, rec, hasBill);
  if (why) {
    rec.Status = 'PENDING_APPROVAL';
    append_(SH.EXPENSES, [rec]);
    rec.ApprovalID = newApproval_(ctx, 'EXPENSE', rec.ExpenseID, amount, why).ApprovalID;
    update_(SH.EXPENSES, rec);
    audit_(ctx, 'CREATE', 'Expense', rec.ExpenseID, { amount: amount, ledger: led.name, status: 'PENDING_APPROVAL', why: why });
    return { record: strip_(rec), pending: true, why: why };
  }
  postExpense_(ctx, rec);
  append_(SH.EXPENSES, [rec]);
  audit_(ctx, 'CREATE', 'Expense', rec.ExpenseID, { voucher: rec.VoucherNo, amount: amount, ledger: led.name });
  return { record: strip_(rec), pending: false };
}

function postExpense_(ctx, rec) {
  rec.VoucherNo = voucherNo_('PV', rec.Date);
  rec.Status = 'POSTED'; rec.PostedAt = ctx.now;
  postGL_(ctx, { type: 'Payment', no: rec.VoucherNo, src: rec.ExpenseID, date: rec.Date, narration: rec.Narration },
    [{ l: rec.LedgerID, f: rec.FundID, dr: rec.Amount, n: rec.Narration + ' — ' + rec.PayeeName }, { l: rec.AccountID, f: rec.FundID, cr: rec.Amount }]);
}

/* ---------------- Approvals (payments, contra, journals) ---------------- */

var APPROVAL_SHEETS = { EXPENSE: SH.EXPENSES, TRANSFER: SH.TRANSFERS, JOURNAL: SH.JOURNAL };

function decideExpense_(ctx, p) {
  var ap = findById_(SH.APPROVALS, V.id(p.ApprovalID, 'Approval'));
  if (!ap || ap.Decision !== 'PENDING') fail_('This approval request is no longer pending.');
  var type = ap.SourceType || 'EXPENSE', sheet = APPROVAL_SHEETS[type];
  if (!sheet) fail_('Unknown approval type.');
  var rec = findById_(sheet, ap.ExpenseID);
  if (!rec || rec.Status !== 'PENDING_APPROVAL') fail_('This voucher is not awaiting approval.');
  var decision = V.oneOf(String(p.Decision || '').toUpperCase(), ['APPROVED', 'REJECTED'], 'Decision');
  var remarks = V.str(p.Remarks, 'Remarks', { max: 300, req: decision === 'REJECTED' });
  var makerId = ap.RequestedByID || rec.CreatedByID;
  var isMaker = makerId ? makerId === ctx.user.UserID : String(rec.CreatedBy).toLowerCase() === String(ctx.user.Email).toLowerCase();
  var adminSelf = isMaker && ctx.user.Role === 'ADMIN' && yes_(setting_('ADMIN_SELF_APPROVE'));
  if (isMaker && !adminSelf && (type === 'JOURNAL' || !yes_(setting_('ALLOW_SELF_APPROVAL'))))
    fail_('Maker-checker rule: someone else must approve a voucher you entered.');
  if (adminSelf) {
    remarks = ('[Self-approved by Admin] ' + remarks).trim();
    noteSelfApproval_(ctx, type, rec, decision);
  }
  checkLock_(rec.Date); // a locked period can be neither approved nor rejected
  if (decision === 'APPROVED') {
    if (type === 'EXPENSE') {
      var led = activeLedger_(rec.LedgerID, null, 'Expense ledger');
      activeAccount_(rec.AccountID);
      checkFundUse_(activeFund_(rec.FundID), led);
      checkCash_(rec.AccountID, num_(rec.Amount));
      checkFund_(rec.FundID, num_(rec.Amount));
      postExpense_(ctx, rec);
    } else if (type === 'TRANSFER') {
      activeAccount_(rec.FromAccountID); activeAccount_(rec.ToAccountID);
      checkCash_(rec.FromAccountID, num_(rec.Amount));
      postTransfer_(ctx, rec);
    } else {
      var lines = journalLines_(rec.Lines);
      checkJournalFunds_(lines);
      postJournal_(ctx, rec, lines);
    }
  } else {
    rec.Status = 'REJECTED';
  }
  ap.Decision = decision; ap.DecidedBy = ctx.user.Email; ap.DecidedAt = ctx.now; ap.Remarks = remarks || ap.Remarks;
  update_(sheet, rec);
  update_(SH.APPROVALS, ap);
  audit_(ctx, decision === 'APPROVED' ? 'APPROVE' : 'REJECT', type, ap.ExpenseID, { approval: ap.ApprovalID, voucher: rec.VoucherNo, remarks: remarks });
  return { expense: strip_(rec), approval: strip_(ap) };
}

/** Admin self-approvals are allowed (setting) but always made visible to Trustees and Auditors. */
function noteSelfApproval_(ctx, type, rec, decision) {
  var p = props_(), list = [];
  try { list = JSON.parse(p.getProperty('SELF_APPROVALS') || '[]'); } catch (e) { list = []; }
  list.push({ at: ctx.now, by: ctx.user.Email, type: type, id: rec[SCHEMA[APPROVAL_SHEETS[type]][0]], amount: num_(rec.Amount || rec.Total), decision: decision });
  p.setProperty('SELF_APPROVALS', JSON.stringify(list.slice(-50)));
  audit_(ctx, 'ADMIN_SELF_APPROVE', type, list[list.length - 1].id, list[list.length - 1]);
  CacheService.getScriptCache().remove('QUOTA');
}

function listApprovals_(ctx, p) {
  var all = read_(SH.APPROVALS);
  var rows = p && p.all === true ? all.slice(-300) : all.filter(function (a) { return a.Decision === 'PENDING'; });
  return rows.map(function (a) {
    var type = a.SourceType || 'EXPENSE';
    var rec = findById_(APPROVAL_SHEETS[type] || SH.EXPENSES, a.ExpenseID) || {};
    var view = strip_(rec);
    if (type === 'TRANSFER') { view.PayeeName = 'Contra: transfer to ' + ((ledgerMap_()[rec.ToAccountID] || {}).name || ''); view.LedgerID = rec.ToAccountID; view.AccountID = rec.FromAccountID; }
    if (type === 'JOURNAL') { view.PayeeName = 'Journal voucher'; view.Amount = rec.Total; }
    view.SourceType = type;
    return { approval: strip_(a), expense: view };
  }).reverse();
}

/* ---------------- Contra (Cash ↔ Bank transfer) — F4 ---------------- */

function createTransfer_(ctx, p) {
  var date = V.date(p.Date || today_(), 'Date');
  checkVoucherDate_(ctx, date);
  var from = activeAccount_(p.FromAccountID, 'From account');
  var to = activeAccount_(p.ToAccountID, 'To account');
  if (from.id === to.id) fail_('From and To accounts must be different.');
  var amount = V.amount(p.Amount, 'Amount');
  checkCash_(from.id, amount);
  var rec = { TransferID: newId_('TRF'), VoucherNo: '', Date: date, FromAccountID: from.id, ToAccountID: to.id, Amount: amount,
    Mode: V.oneOf(p.Mode || 'Cash', PAY_MODES, 'Mode'), Reference: V.str(p.Reference, 'Reference', { max: 60 }),
    Narration: V.str(p.Narration, 'Narration', { max: 300, multi: true }), CreatedAt: ctx.now, CreatedBy: ctx.user.Email, CreatedByID: ctx.user.UserID };
  var mine = 0;
  read_(SH.TRANSFERS).forEach(function (r) { if (r.Date === date && sameUser_(r, ctx) && r.Status === 'POSTED' && !r.ApprovalID) mine += num_(r.Amount); });
  if (amount >= threshold_() || mine + amount >= threshold_()) {
    rec.Status = 'PENDING_APPROVAL';
    append_(SH.TRANSFERS, [rec]);
    rec.ApprovalID = newApproval_(ctx, 'TRANSFER', rec.TransferID, amount, from.name + ' → ' + to.name).ApprovalID;
    update_(SH.TRANSFERS, rec);
    audit_(ctx, 'CREATE', 'Transfer', rec.TransferID, { amount: amount, from: from.name, to: to.name, status: 'PENDING_APPROVAL' });
    return { record: strip_(rec), pending: true };
  }
  var gl = transferGL_(ctx, rec);
  append_(SH.TRANSFERS, [rec]);
  appendGL_(ctx, gl);
  audit_(ctx, 'CREATE', 'Transfer', rec.TransferID, { voucher: rec.VoucherNo, amount: amount, from: from.name, to: to.name });
  return { record: strip_(rec), pending: false };
}

/** Contra lines keep each fund's share of cash intact: the money moved is taken from funds proportionally. */
function transferGL_(ctx, rec) {
  rec.VoucherNo = voucherNo_('CV', rec.Date);
  rec.Status = 'POSTED';
  var lm = ledgerMap_(), byFund = Object.create(null), total = 0;
  read_(SH.GL).forEach(function (e) {
    if (e.Status === 'CANCELLED' || e.LedgerID !== rec.FromAccountID) return;
    var f = e.FundID || GEN_FUND;
    byFund[f] = (byFund[f] || 0) + num_(e.Debit) - num_(e.Credit);
  });
  Object.keys(byFund).forEach(function (f) { if (byFund[f] <= 0) delete byFund[f]; else total += byFund[f]; });
  var amt = num_(rec.Amount), lines = [], left = amt, keys = Object.keys(byFund);
  if (!keys.length || total <= 0) { keys = [GEN_FUND]; byFund[GEN_FUND] = 1; total = 1; }
  keys.forEach(function (f, i) {
    var part = i === keys.length - 1 ? round2_(left) : round2_(amt * byFund[f] / total);
    left = round2_(left - part);
    if (part > 0) { lines.push({ l: rec.ToAccountID, f: f, dr: part }); lines.push({ l: rec.FromAccountID, f: f, cr: part }); }
  });
  return buildGL_(ctx, { type: 'Contra', no: rec.VoucherNo, src: rec.TransferID, date: rec.Date,
    narration: rec.Narration || ('Transfer ' + lm[rec.FromAccountID].name + ' → ' + lm[rec.ToAccountID].name) }, lines);
}
function postTransfer_(ctx, rec) { appendGL_(ctx, transferGL_(ctx, rec)); }

/* ---------------- Journal — F7 (always needs an independent approver) ---------------- */

function journalLines_(raw) {
  if (typeof raw === 'string') { try { raw = JSON.parse(raw); } catch (e) { raw = []; } }
  if (!Array.isArray(raw) || raw.length < 2 || raw.length > 30) fail_('A journal needs between 2 and 30 lines.');
  var lines = raw.map(function (x, i) {
    if (!x || typeof x !== 'object') fail_('Line ' + (i + 1) + ' is invalid.');
    var l = activeLedger_(V.id(x.LedgerID, 'Line ' + (i + 1) + ' ledger'), null, 'Line ' + (i + 1) + ' ledger');
    if (l.cash) fail_('Journals cannot touch cash or bank. Use a Receipt, Payment or Contra voucher instead.');
    var f = activeFund_(x.FundID || l.fund || GEN_FUND);
    var dr = V.amount(x.Debit, 'Line ' + (i + 1) + ' debit', { allowZero: true });
    var cr = V.amount(x.Credit, 'Line ' + (i + 1) + ' credit', { allowZero: true });
    if ((dr > 0) === (cr > 0)) fail_('Line ' + (i + 1) + ' needs either a debit or a credit.');
    return { l: l.id, f: f.FundID, dr: dr, cr: cr };
  });
  var dr = 0, cr = 0;
  lines.forEach(function (x) { dr += x.dr; cr += x.cr; });
  if (round2_(dr) !== round2_(cr)) fail_('Journal is not balanced: Debit ' + money_(dr) + ' ≠ Credit ' + money_(cr) + '.');
  return lines;
}
/** A journal may not take a fund's books balance below zero (e.g. moving Zakat into General). */
function checkJournalFunds_(lines) {
  if (!yes_(setting_('ENFORCE_FUND_BALANCE'))) return;
  var lm = ledgerMap_(), take = Object.create(null), bal = fundBalances_();
  lines.forEach(function (x) {
    var l = lm[x.l];
    if (l.nature === 'Income' || l.nature === 'Expense' || FUND_GROUPS.indexOf(l.group) >= 0) take[x.f] = (take[x.f] || 0) + x.dr - x.cr;
  });
  Object.keys(take).forEach(function (f) {
    if (round2_(take[f]) > 0 && round2_((bal[f] || 0) - take[f]) < 0) fail_('This journal would take "' + (findById_(SH.FUNDS, f) || { Name: f }).Name + '" below zero.');
  });
}

function createJournal_(ctx, p) {
  var date = V.date(p.Date || today_(), 'Date');
  checkVoucherDate_(ctx, date);
  var narration = V.str(p.Narration, 'Narration', { req: true, max: 300, multi: true });
  var lines = journalLines_(p.Lines);
  checkJournalFunds_(lines);
  var total = round2_(lines.reduce(function (s, x) { return s + x.dr; }, 0));
  var rec = { JournalID: newId_('JNL'), VoucherNo: '', Date: date, Narration: narration, Total: total, Status: 'PENDING_APPROVAL',
    Lines: lines.map(function (x) { return { LedgerID: x.l, FundID: x.f, Debit: x.dr, Credit: x.cr }; }),
    CreatedAt: ctx.now, CreatedBy: ctx.user.Email, CreatedByID: ctx.user.UserID };
  append_(SH.JOURNAL, [rec]);
  rec.ApprovalID = newApproval_(ctx, 'JOURNAL', rec.JournalID, total, narration).ApprovalID;
  update_(SH.JOURNAL, rec);
  audit_(ctx, 'CREATE', 'Journal', rec.JournalID, { total: total, status: 'PENDING_APPROVAL', lines: rec.Lines });
  return { record: strip_(rec), pending: true };
}

function postJournal_(ctx, rec, lines) {
  rec.VoucherNo = voucherNo_('JV', rec.Date);
  rec.Status = 'POSTED';
  postGL_(ctx, { type: 'Journal', no: rec.VoucherNo, src: rec.JournalID, date: rec.Date, narration: rec.Narration }, lines);
}

/* ---------------- Cancel voucher (never delete) ---------------- */

var VOUCHER_SHEETS = {
  INCOME: SH.INCOME, EXPENSE: SH.EXPENSES, COLLECTION: SH.COLLECTIONS, TRANSFER: SH.TRANSFERS, JOURNAL: SH.JOURNAL
};

function cancelVoucher_(ctx, p) {
  var type = V.oneOf(String(p.Type || ''), Object.keys(VOUCHER_SHEETS), 'Voucher type');
  var name = VOUCHER_SHEETS[type];
  var rec = findById_(name, V.id(p.ID, 'Voucher'));
  if (!rec) fail_('Voucher not found.');
  var reason = V.str(p.Reason, 'Reason', { req: true, min: 5, max: 300 });
  if (rec.Status === 'CANCELLED' || rec.Status === 'REJECTED') fail_('This voucher is already ' + rec.Status.toLowerCase() + '.');
  checkLock_(rec.Date);

  var id = rec[SCHEMA[name][0]];
  if (rec.Status === 'POSTED') {
    var lines = read_(SH.GL).filter(function (e) { return e.SourceID === id && e.Status !== 'CANCELLED'; });
    // Cancelling money that came IN must not push a cash/bank account, or any fund's cash, below zero.
    var lm = ledgerMap_(), net = Object.create(null), fnet = Object.create(null);
    lines.forEach(function (e) {
      if (!lm[e.LedgerID] || !lm[e.LedgerID].cash) return;
      var v = num_(e.Debit) - num_(e.Credit);
      net[e.LedgerID] = (net[e.LedgerID] || 0) + v;
      fnet[e.FundID || GEN_FUND] = (fnet[e.FundID || GEN_FUND] || 0) + v;
    });
    Object.keys(net).forEach(function (acc) { if (round2_(net[acc]) > 0) checkCash_(acc, round2_(net[acc])); });
    Object.keys(fnet).forEach(function (f) { if (round2_(fnet[f]) > 0) checkFund_(f, round2_(fnet[f])); });
    lines.forEach(function (e) { e.Status = 'CANCELLED'; });
    updateMany_(SH.GL, lines);
    ctx.posted = true;
  }
  if (type === 'COLLECTION') {
    var alloc = [];
    try { alloc = JSON.parse(rec.Allocations || '[]'); } catch (e) { alloc = []; }
    var sched = alloc.map(function (a) {
      var s = findById_(SH.SCHEDULE, a.s);
      if (!s) return null;
      s.PaidAmount = round2_(Math.max(0, num_(s.PaidAmount) - num_(a.a)));
      s.Status = s.PaidAmount <= 0 ? 'Due' : (s.PaidAmount >= num_(s.Amount) ? 'Paid' : 'Partial');
      s.UpdatedAt = ctx.now; s.UpdatedBy = ctx.user.Email;
      return s;
    }).filter(Boolean);
    updateMany_(SH.SCHEDULE, sched);
  }
  if (rec.Status === 'PENDING_APPROVAL' && rec.ApprovalID) {
    var ap = findById_(SH.APPROVALS, rec.ApprovalID);
    if (ap) { ap.Decision = 'WITHDRAWN'; ap.DecidedBy = ctx.user.Email; ap.DecidedAt = ctx.now; ap.Remarks = reason; update_(SH.APPROVALS, ap); }
  }
  if (rec.ReceiptID) {
    var r = findById_(SH.RECEIPTS, rec.ReceiptID);
    if (r) { r.Status = 'CANCELLED'; r.PdfFileID = ''; update_(SH.RECEIPTS, r); }
  }
  var prev = rec.Status;
  rec.Status = 'CANCELLED'; rec.CancelReason = reason; rec.CancelledAt = ctx.now; rec.CancelledBy = ctx.user.Email;
  update_(name, rec);
  audit_(ctx, 'CANCEL', type, id, { voucher: rec.VoucherNo, previousStatus: prev, reason: reason });
  return { record: strip_(rec) };
}

/* ---------------- Voucher register ---------------- */

function listVouchers_(ctx, p) {
  var type = V.oneOf(String(p.Type || 'INCOME'), Object.keys(VOUCHER_SHEETS), 'Voucher type');
  var from = p.From ? V.date(p.From, 'From') : '0000-00-00';
  var to = p.To ? V.date(p.To, 'To') : '9999-12-31';
  var own = !can_(ctx.user, 'vouchers.view');
  if (own && !can_(ctx.user, 'vouchers.own')) fail_('You do not have permission to view vouchers.');
  var rows = read_(VOUCHER_SHEETS[type]).filter(function (r) {
    return r.Date >= from && r.Date <= to && (!own || sameUser_(r, ctx));
  });
  if (rows.length > 2000) rows = rows.slice(-2000);
  return rows.map(function (r) { var o = strip_(r); delete o.CreatedByID; return o; }).reverse();
}
