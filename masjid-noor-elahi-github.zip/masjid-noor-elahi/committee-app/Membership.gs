/**
 * Membership.gs — payment schedule (dues) generation and membership collections.
 * Dues are a memo register (cash-basis accounting, as most masjids use);
 * only actual collections are posted to the books as Receipt vouchers.
 */

function isDueMonth_(freq, ym) {
  var offset = ((+ym.slice(5, 7)) - fyStartMonth_() + 12) % 12;
  if (freq === 'Monthly') return true;
  if (freq === 'Quarterly') return offset % 3 === 0;
  if (freq === 'Half-Yearly') return offset % 6 === 0;
  if (freq === 'Yearly') return offset === 0;
  return false;
}

/** Create dues for one month for all active members. Idempotent (ScheduleID = member + month). */
function generateSchedule_(ctx, p) {
  var ym = V.month(p.Month || today_().slice(0, 7), 'Month');
  var maxYm = addMonths_(today_().slice(0, 7), 1);
  if (ym > maxYm) fail_('Dues can be generated at most one month ahead.');
  var exists = {};
  read_(SH.SCHEDULE).forEach(function (s) { exists[s.ScheduleID] = 1; });
  var plans = {};
  read_(SH.PLANS).forEach(function (pl) { if (pl.Status === 'Active') plans[pl.PlanID] = pl; });
  var dueDay = Math.min(28, Math.max(1, parseInt(setting_('DUE_DAY'), 10) || 10));
  var rows = [];
  read_(SH.MEMBERS).forEach(function (m) {
    if (m.Status !== 'Active' || !plans[m.PlanID]) return;
    if (m.JoinDate && m.JoinDate.slice(0, 7) > ym) return;
    var pl = plans[m.PlanID];
    if (!isDueMonth_(pl.Frequency, ym)) return;
    var id = 'SCH-' + m.MemberID + '-' + ym;
    if (exists[id]) return;
    rows.push({ ScheduleID: id, MemberID: m.MemberID, PlanID: pl.PlanID, Period: ym, DueDate: ym + '-' + pad_(dueDay, 2),
      Amount: num_(pl.Amount), PaidAmount: 0, Status: 'Due', CreatedAt: ctx.now, UpdatedAt: ctx.now, UpdatedBy: ctx.user.Email });
  });
  append_(SH.SCHEDULE, rows);
  if (rows.length) audit_(ctx, 'GENERATE', 'Schedule', ym, { created: rows.length });
  return { month: ym, created: rows.length };
}

function memberDues_(ctx, p) {
  var mid = V.id(p.MemberID, 'Member');
  return read_(SH.SCHEDULE).filter(function (s) {
    return s.MemberID === mid && (s.Status === 'Due' || s.Status === 'Partial');
  }).sort(function (a, b) { return a.Period < b.Period ? -1 : 1; }).map(strip_);
}

function listSchedule_(ctx, p) {
  var ym = p.Month ? V.month(p.Month, 'Month') : '';
  var status = p.Status || '';
  return read_(SH.SCHEDULE).filter(function (s) {
    return (!ym || s.Period === ym) && (!status || s.Status === status);
  }).slice(-3000).map(strip_);
}

function waiveDue_(ctx, p) {
  var s = findById_(SH.SCHEDULE, V.id(p.ScheduleID, 'Due'));
  if (!s) fail_('Due not found.');
  if (s.Status === 'Paid' || s.Status === 'Waived') fail_('This due is already ' + s.Status.toLowerCase() + '.');
  if (num_(s.PaidAmount) > 0) fail_('A partly paid due cannot be waived.');
  var reason = V.str(p.Reason, 'Reason', { req: true, min: 5, max: 200 });
  s.Status = 'Waived'; s.Remarks = reason; s.UpdatedAt = ctx.now; s.UpdatedBy = ctx.user.Email;
  update_(SH.SCHEDULE, s);
  audit_(ctx, 'WAIVE', 'Schedule', s.ScheduleID, { amount: s.Amount, reason: reason });
  return strip_(s);
}

/** Collect membership fees: allocates oldest-first across the selected (or all) open dues. */
function collect_(ctx, p) {
  var date = V.date(p.Date || today_(), 'Date');
  checkVoucherDate_(ctx, date);
  var m = findById_(SH.MEMBERS, V.id(p.MemberID, 'Member'));
  if (!m) fail_('Member not found.');
  var acc = activeAccount_(p.AccountID, 'Received into');
  var amount = V.amount(p.Amount, 'Amount');
  var mode = V.oneOf(p.Mode || 'Cash', PAY_MODES, 'Mode');
  if (acc.type === 'Cash' && mode !== 'Cash') fail_('Non-cash receipts must go into a bank account.');

  var selected = Array.isArray(p.ScheduleIDs) && p.ScheduleIDs.length ? p.ScheduleIDs.map(String) : null;
  var open = read_(SH.SCHEDULE).filter(function (s) {
    return s.MemberID === m.MemberID && (s.Status === 'Due' || s.Status === 'Partial') && (!selected || selected.indexOf(s.ScheduleID) >= 0);
  }).sort(function (a, b) { return a.Period < b.Period ? -1 : 1; });
  if (!open.length) fail_('This member has no open dues. Record other contributions as a Receipt (donation).');
  var outstanding = round2_(open.reduce(function (t, s) { return t + num_(s.Amount) - num_(s.PaidAmount); }, 0));
  if (amount > outstanding) fail_('Amount exceeds the selected dues (₹' + money_(outstanding) + '). Record any extra as a donation.');

  var left = amount, alloc = [], byLedger = {}, periods = [], touched = [];
  var col = { CollectionID: newId_('COL') };
  open.forEach(function (s) {
    if (left <= 0) return;
    var bal = round2_(num_(s.Amount) - num_(s.PaidAmount)), take = round2_(Math.min(bal, left));
    if (take <= 0) return;
    left = round2_(left - take);
    s.PaidAmount = round2_(num_(s.PaidAmount) + take);
    s.Status = s.PaidAmount >= num_(s.Amount) ? 'Paid' : 'Partial';
    s.LastCollectionID = col.CollectionID; s.UpdatedAt = ctx.now; s.UpdatedBy = ctx.user.Email;
    alloc.push({ s: s.ScheduleID, a: take });
    periods.push(s.Period);
    touched.push(s);
    var pl = findById_(SH.PLANS, s.PlanID), led = pl && pl.IncomeLedgerID ? pl.IncomeLedgerID : 'LED-D01';
    byLedger[led] = round2_((byLedger[led] || 0) + take);
  });

  col.Date = date; col.MemberID = m.MemberID; col.Amount = amount; col.AccountID = acc.id; col.Mode = mode;
  col.Reference = V.str(p.Reference, 'Reference', { max: 60 });
  col.Narration = V.str(p.Narration, 'Narration', { max: 300 }) || ('Membership ' + periods.join(', ') + ' — ' + m.Name + ' (' + m.MemberNo + ')');
  col.Allocations = JSON.stringify(alloc);
  col.Status = 'POSTED'; col.CreatedAt = ctx.now; col.CreatedBy = ctx.user.Email;
  col.VoucherNo = voucherNo_('RV', date);

  var lines = [{ l: acc.id, f: GEN_FUND, dr: amount }];
  Object.keys(byLedger).forEach(function (l) { activeLedger_(l, ['Income'], 'Plan income ledger'); lines.push({ l: l, f: GEN_FUND, cr: byLedger[l] }); });
  var gl = buildGL_(ctx, { type: 'Receipt', no: col.VoucherNo, src: col.CollectionID, date: date, narration: col.Narration }, lines);
  col.ProofFileID = saveUpload_(ctx, p.file, 'PROOFS', col.CollectionID);
  var receipt = newReceipt_(ctx, { date: date, type: 'COLLECTION', src: col.CollectionID, party: m.Name + ' (' + m.MemberNo + ')',
    phone: m.Phone, amount: amount, purpose: 'Membership fee: ' + periods.join(', '), mode: mode });
  col.ReceiptID = receipt.ReceiptID;

  append_(SH.COLLECTIONS, [col]);
  updateMany_(SH.SCHEDULE, touched);
  appendGL_(ctx, gl);
  audit_(ctx, 'CREATE', 'Collection', col.CollectionID, { voucher: col.VoucherNo, member: m.MemberNo, amount: amount, allocations: alloc });
  return { record: strip_(col), receipt: strip_(receipt) };
}
