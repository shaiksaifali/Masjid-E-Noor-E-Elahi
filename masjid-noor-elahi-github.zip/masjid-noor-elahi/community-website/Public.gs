/**
 * @OnlyCurrentDoc
 * Public.gs — Masjid-E-Noor-Elahi community website (public, no login).
 *
 * SECURITY DESIGN
 *  - This project is BOUND to the "Public Website Data" spreadsheet and uses only the
 *    `spreadsheets.currentonly` permission: it can open THAT spreadsheet and nothing else —
 *    not the finance database, not Drive, not Gmail.
 *  - Only three functions can be reached from a browser: doGet, getSnapshot, submitRequest.
 *    Everything else ends with "_" (private).
 *  - The snapshot contains only information the committee chose to publish.
 *  - Requests are validated, rate-limited, stored as plain text and never shown publicly.
 */

var REQ_HEADERS = ['ReqID', 'SubmittedAt', 'Type', 'Name', 'Phone', 'PreferredDate', 'Message', 'Status', 'HandledBy', 'HandledAt', 'Note'];
var REQ_TYPES = ['Nikah', 'Hall / venue booking', 'Volunteer', 'Madrasa / Maktab admission', 'Query / suggestion', 'Other'];
var LIMITS = { perHour: 40, perPhonePerDay: 3, maxRows: 5000, minFillMs: 4000 };

function doGet(e) {
  var snap = snapshot_();
  var p = (e && e.parameter) || {};
  var t = HtmlService.createTemplateFromFile('PublicIndex');
  t.snapJson = safeJson_(snap);
  t.initJson = safeJson_({ lang: p.lang === 'ur' ? 'ur' : 'en', page: /^[a-z]{2,12}$/.test(String(p.page || '')) ? p.page : 'home' });
  t.title = (snap.masjid && snap.masjid.name) || 'Masjid';
  return t.evaluate()
    .setTitle(t.title)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.DEFAULT);
}

function include_(name) { return HtmlService.createHtmlOutputFromFile(name).getContent(); }

/** JSON that is safe to place inside a <script> tag. */
function safeJson_(o) {
  return JSON.stringify(o).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026')
    .replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
}

/** PUBLIC: latest snapshot (used for the auto-refresh). */
function getSnapshot() { return snapshot_(); }

/** Snapshot written by the private app; cached for 2 minutes (chunked: CacheService values max 100 KB). */
function snapshot_() {
  var cache = CacheService.getScriptCache(), n = +(cache.get('SNAP_N') || 0);
  if (n) {
    var keys = []; for (var i = 0; i < n; i++) keys.push('SNAP_' + i);
    var parts = cache.getAll(keys), s = '';
    for (i = 0; i < n; i++) { if (parts['SNAP_' + i] === undefined) { s = null; break; } s += parts['SNAP_' + i]; }
    if (s) { try { return JSON.parse(s); } catch (e) { /* fall through */ } }
  }
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Snapshot');
  var json = '';
  if (sh && sh.getLastRow() > 0) json = sh.getRange(1, 1, sh.getLastRow(), 1).getValues().map(function (r) { return String(r[0]); }).join('');
  var snap;
  try { snap = json ? JSON.parse(json) : null; } catch (e) { snap = null; }
  if (!snap) snap = { masjid: { name: 'Masjid', formsEnabled: false }, calc: {}, jamaat: [], announcements: [], events: [], programs: [], janazah: [], ramadan: {}, donate: {}, calendar: {}, jumuah: {} };
  try {
    var str = JSON.stringify(snap), put = {}, k = 0;
    for (var j = 0; j < str.length; j += 90000) put['SNAP_' + (k++)] = str.slice(j, j + 90000);
    put.SNAP_N = String(k);
    cache.putAll(put, 120);
  } catch (e) { /* cache is optional */ }
  return snap;
}

function pubErr_(msg) { var e = new Error(msg); e.userFacing = true; throw e; }
function clean_(v, label, max, req) {
  if (v !== null && v !== undefined && typeof v === 'object') pubErr_(label + ' is invalid.');
  v = String(v === null || v === undefined ? '' : v).normalize('NFKC')
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u200B-\u200F\u202A-\u202E\u2060-\u2069\uFEFF]/g, '')
    .replace(/\r\n?/g, '\n').trim();
  if (req && !v) pubErr_(label + ' is required.');
  if (v.length > max) pubErr_(label + ' is too long.');
  return v;
}
function today_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Kolkata', 'yyyy-MM-dd'); }

/** PUBLIC: a request from the website (Nikah, booking, volunteer, query…). */
function submitRequest(f) {
  try {
    if (!f || typeof f !== 'object' || Array.isArray(f)) pubErr_('Invalid request.');
    if (f.website) return { ok: true };                       // honeypot field filled → silently drop bots
    if (!(+f.t >= LIMITS.minFillMs)) pubErr_('Please take a moment to fill in the form, then send it again.');
    if (!snapshot_().masjid.formsEnabled) pubErr_('The masjid is not accepting online requests right now. Please contact the masjid office.');
    var type = clean_(f.type, 'Request type', 40, true);
    if (REQ_TYPES.indexOf(type) < 0) pubErr_('Choose a request type.');
    var name = clean_(f.name, 'Name', 80, true).replace(/\n/g, ' ');
    var phone = clean_(f.phone, 'Phone', 20, true);
    if (!/^\+?[0-9][0-9 \-]{8,16}$/.test(phone)) pubErr_('Enter a valid phone number.');
    var digits = phone.replace(/\D/g, '');
    var date = clean_(f.date, 'Preferred date', 10, false);
    if (date) {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || isNaN(Date.parse(date + 'T00:00:00Z'))) pubErr_('Preferred date is not valid.');
      if (date < today_()) pubErr_('Preferred date cannot be in the past.');
    }
    var msg = clean_(f.message, 'Message', 1000, type === 'Query / suggestion' || type === 'Other');

    var lock = LockService.getScriptLock();
    if (!lock.tryLock(10000)) pubErr_('The website is busy. Please try again in a minute.');
    try {
      var cache = CacheService.getScriptCache(), hourKey = 'RQH_' + Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyyMMddHH');
      var phoneKey = 'RQP_' + today_() + '_' + digits.slice(-10);
      var hourN = +(cache.get(hourKey) || 0), phoneN = +(cache.get(phoneKey) || 0);
      if (hourN >= LIMITS.perHour) pubErr_('Many requests are coming in right now. Please try again later or contact the masjid office.');
      if (phoneN >= LIMITS.perPhonePerDay) pubErr_('We have already received your requests today. The committee will contact you, insha’Allah.');
      var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Requests');
      if (!sh) pubErr_('Requests are not available right now.');
      var row = sh.getLastRow() + 1;
      if (row > LIMITS.maxRows + 1) pubErr_('The request box is full. Please contact the masjid office directly.');
      var id = 'REQ-' + Date.now().toString(36).toUpperCase() + '-' + Utilities.getUuid().slice(0, 4).toUpperCase();
      var vals = [id, Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd HH:mm:ss'), type, name, phone, date, msg, 'New', '', '', '']
        .map(function (v) { return /^[=+\-@\t]/.test(v) ? "'" + v : v; });   // never a formula
      if (row > sh.getMaxRows()) sh.insertRowsAfter(sh.getMaxRows(), 100);
      var rng = sh.getRange(row, 1, 1, REQ_HEADERS.length);
      rng.setNumberFormat('@');
      rng.setValues([vals]);
      cache.put(hourKey, String(hourN + 1), 3700);
      cache.put(phoneKey, String(phoneN + 1), 86400);
    } finally { lock.releaseLock(); }
    return { ok: true, id: id };
  } catch (e) {
    if (e && e.userFacing) throw new Error(e.message);
    console.error('submitRequest: ' + (e && e.stack || e));
    throw new Error('Could not send your request. Please try again later.');
  }
}
