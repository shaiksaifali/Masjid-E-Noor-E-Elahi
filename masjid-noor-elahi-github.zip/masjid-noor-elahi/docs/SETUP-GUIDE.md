# Masjid-E-Noor-Elahi — Masjid Management System + Community Website (Zero-Cost Edition, ₹0)

*Developed by **Arhaan Agencies**.*

A complete masjid accounts and membership system with Tally-style double-entry books, running entirely on a **free Google account**:

| Layer | Free service used |
|---|---|
| Backend + hosting | Google Apps Script (Web App deployment, `script.google.com/macros/s/…/exec` URL) |
| Database | Google Sheets (private to the owner) |
| Files (bills, proofs, receipts, reports, backups) | Google Drive (private folder) |
| Frontend | HTML5 / CSS3 / vanilla JavaScript via HTML Service |
| Charts | Google Charts |
| Receipts as PDF | Built-in Apps Script HTML → PDF conversion |
| Receipt sharing | WhatsApp click-to-chat links (`wa.me`, free) + optional email via the free MailApp quota |

No paid APIs, no subscriptions, no domain, no Firebase/Supabase/AWS/Azure/Vercel.

---

## 1. Tally Prime modules → what this app provides

| Tally Prime | This app |
|---|---|
| Gateway of Tally | **Dashboard** (balances, month/FY income & expense, fund balances, pending approvals, dues, 12-month chart) |
| Ledger masters & Groups | **Ledgers (Chart of Accounts)** with non-profit groups: Cash-in-Hand, Bank Accounts, Fixed Assets, Corpus Fund, Earmarked Funds, Donations, Membership Income, Salaries, Utilities, Charity & Welfare, etc. |
| Receipt voucher (F6) | **Receipt / Donation** — Jumu'ah collection, general donations, Zakat, Sadaqah, rent… with auto receipt |
| Payment voucher (F5) | **Payment / Expense** with bill upload and **maker-checker approval** above a threshold |
| Contra voucher (F4) | **Contra** — cash deposit/withdrawal, bank-to-bank |
| Journal voucher (F7) | **Journal** — multi-line, must balance, never touches cash/bank, always approved by a second person |
| Cost centres | **Funds** — General, Zakat, Sadaqah, Construction, Ramadan (restricted funds cannot be overspent) |
| Voucher numbering | Per voucher type per financial year: `RV/2026-27/00001`, `PV/…`, `CV/…`, `JV/…` |
| Cancel voucher | **Cancel** keeps the voucher, marks it CANCELLED and removes it from all reports. Nothing is ever deleted. |
| Day Book | ✔ (cancelled vouchers shown struck-through) |
| Ledger / Cash Book / Bank Book | ✔ with running Dr/Cr balance and contra-ledger particulars |
| Trial Balance | ✔ grouped, with tally check |
| Profit & Loss | **Income & Expenditure Account** (the non-profit equivalent), optionally per fund |
| Balance Sheet | ✔ Funds & Liabilities vs Assets, with tally check |
| Receipts & Payments Account | ✔ (the statement auditors/Waqf boards usually ask for) |
| Budgets / Budget vs Actual | ✔ |
| Bank Reconciliation (BRS) | ✔ tick cleared entries with bank date |
| Outstanding (receivables) | **Membership dues outstanding** + member statement |
| Edit log / Audit trail | **Audit Log** — every login, entry, approval, cancellation and master change, with before/after values |
| Period lock / Security control | **Lock date**, back-dating limit, roles & permissions |
| Backup & Restore | Daily automatic Drive backups + "Backup now" + owner restore function |
| Print / Export | Print, CSV (opens in Excel), PDF saved to Drive |

**Keyboard shortcuts (like Tally):** F4 Contra · F5 Payment · F6 Receipt · F7 Journal · Esc closes dialogs.

**Membership module:** members, plans (monthly / quarterly / half-yearly / yearly), automatic dues on the 1st of each month, collection with oldest-first allocation, waivers (Admin), receipts, outstanding report.

Accounting basis: membership dues are a memo register (cash basis, as most masjids keep books); only money actually received is posted to the books.

---

## 1b. Community website (public, no login) — new in v1.2

A separate public website for the whole community, in **English and Urdu**:
- **Home** — a Bismillah banner, a "day arc" showing the sun's path through today's prayers, prayer cards with their own icons, today's Azan and Jamaat times, a live "next Jamaat in 42 min" countdown, Jumu'ah (Khutbah and Jamaat), the Hijri date, announcements, Janazah notices, today's Dawat programmes and upcoming events.
- **Prayer Times** — a printable monthly timetable (Azan times calculated for the masjid's location: University of Islamic Sciences, Karachi 18°/18°, Hanafi Asr) plus the committee's Jamaat times.
- **Ramadan** — a countdown, a Sehri/Iftar table for every Roza, Taraweeh details, the odd nights of the last ten days, and Eid-ul-Fitr / Eid-ul-Adha Salah times.
- **Wudu & Salah** — step-by-step Wudu with an original illustration for each step (faceless figures, no photos), the Fard of Wudu and what breaks it, a colour-coded rakat chart from Fajr to Isha plus Jumu'ah and Witr (Hanafi), and everyday duas with Arabic, transliteration, English/Urdu meaning and hadith reference. *Have the Imam review this page before going live.*
- **Dawat & Programmes** — the weekly schedule for Gasht, Taleem, Bayan, Mashwara, Dars-e-Quran, Maktab, women's and youth programmes, by day ("after Asr" times follow the Jamaat automatically).
- **Events**, **Janazah**, **Donate** (UPI pay button + QR + bank note), **Contact** (Google Maps, call, WhatsApp group) and **Request** (Nikah, hall booking, volunteer, Madrasa admission, queries).
- **Reminders (free):**
  - **Google Calendar subscription** — Jumu'ah, Ramadan Sehri/Iftar, Dawat programmes, events and Janazah, kept in sync automatically; people get alerts from their own phone.
  - **WhatsApp share buttons** on every notice and event.
  - An optional **on-page reminder with sound** before each Jamaat, Sehri and Iftar while the page is open.

The committee manages it all from **Community Website** in the private app, using the **Community Manager** role (for the Imam or secretary). That role cannot see any accounts, members or money.

**Security:** the public website is a *separate* Apps Script project bound to a separate "Public Website Data" sheet. It runs with Google's `spreadsheets.currentonly` permission, so it can open only that one sheet — never the finance database, Drive or Gmail. The private app publishes only what the committee chose to show.

## 2. Files

| File | Purpose |
|---|---|
| `appsscript.json` | Manifest (time zone, scopes, web-app settings) |
| `Config.gs` | Sheet schemas, account groups, default ledgers/funds/settings, roles |
| `Util.gs` | Dates, financial year, validation, amount-in-words (Lakh/Crore) |
| `Db.gs` | Batch Sheets reads/writes, caching, LockService, ID & voucher numbering, audit buffer |
| `Auth.gs` | Login, sessions, password hashing, role checks, user management |
| `Setup.gs` | `setup()`, `adminResetPassword()`, `restoreFromBackup()` |
| `Masters.gs` | Members, plans, ledgers, cash/bank accounts, funds, budgets, settings |
| `Membership.gs` | Dues generation and collections |
| `Vouchers.gs` | Receipt, payment, contra, journal, approvals, cancellation, double-entry posting |
| `Reports.gs` | All Tally-style reports + dashboard + server-side PDF HTML |
| `Files.gs` | Drive uploads, secure file viewing, receipts PDF/email |
| `System.gs` | Backups, quota monitor, audit viewer, scheduled jobs |
| `Api.gs` | Single API gateway with permission checks |
| `Code.gs` | `doGet()` web-app entry |
| `Community.gs` | Community website data: Jamaat rules, announcements, events, programmes, Janazah, Google Calendar sync, publishing, requests |
| `PrayerCalc.gs` / `PrayerCalcJs.html` | Offline prayer-time and Hijri calculation (identical copy in the website) |
| `AppCommunity.html` | Committee screens for the community website |
| `community/` | **The public website — a separate Apps Script project** (`Public.gs`, `PublicIndex.html`, `PublicStyles.html`, `PublicApp.html`, `PublicGuide.html`, `PublicArt.html`, `PrayerCalcJs.html`, `appsscript.json`) |
| `Index.html`, `Styles.html`, `App.html` | The private app's user interface |
| `tests/` | Local test harness (Node.js) — **do not** copy into Apps Script |

---

## 3. Installation (about 15 minutes)

Use the Google account that will **own** the data (ideally a dedicated masjid Gmail, e.g. `yourmasjid.accounts@gmail.com`, not someone's personal account — so it survives committee changes).

1. Go to **https://script.google.com** → **New project**. Rename it "Masjid Management System".
2. **Project Settings** (⚙) → tick **"Show appsscript.json manifest file in editor"**.
3. In the editor, replace the contents of `appsscript.json` with the file from this package.
4. Delete the default `Code.gs` content and create each file with the **same name**:
   - Script files (**+ → Script**): `Config`, `Util`, `Db`, `Auth`, `Setup`, `Masters`, `Membership`, `Vouchers`, `Reports`, `Files`, `System`, `Api`, `Code`, `Community`, `PrayerCalc` (paste the matching `.gs` contents).
   - HTML files (**+ → HTML**): `Index`, `Styles`, `App`, `AppCommunity`, `PrayerCalcJs` (paste the matching `.html` contents).
   - The `community/` folder is **not** pasted here; it is a separate project (section 3b).
5. Select the function **`setup`** in the toolbar and click **Run**. Approve the permission prompt (Google will warn "Google hasn't verified this app" — this is normal for your own script: *Advanced → Go to Masjid-E-Noor-Elahi*).
6. Open **Execution log**. It shows:
   - the private database spreadsheet link,
   - the private Drive folder link,
   - **the first Admin login email and temporary password** — note it down.
7. **Deploy → New deployment → ⚙ Web app**
   - Description: `v1`
   - **Execute as: Me**
   - **Who has access: Anyone with Google account**
   - Click **Deploy** and copy the **Web app URL** (ends in `/exec`).
8. Open the URL, sign in with the email + temporary password, and set a new password.
9. Go to **Settings**: the masjid name is already set to Masjid-E-Noor-Elahi; add the address, registration number, financial-year start month, approval threshold, etc.
10. **Cash & Bank Accounts** (Admin): add your bank accounts with opening balances, and open *Cash in Hand* → Edit to enter the opening cash (allowed once, before its first entry).
11. **Users & Roles**: add each committee member. Give them the web-app URL and the one-time temporary password privately.

### Updating the code later
Edit the files, **run `setup()` once** (it adds any new columns and confirms the database layout — the app refuses to run until you do), then **Deploy → Manage deployments → ✏ Edit → Version: New version → Deploy**. The URL stays the same.

---

## 3b. Setting up the community website (about 10 minutes)

**A. Update the private app** (if you already installed v1.1):
1. Replace or add all the files in the main project, including the new `Community`, `PrayerCalc`, `PrayerCalcJs` and `AppCommunity` files and the new `appsscript.json` (it adds the free Google Calendar permission).
2. Run **`setup()`** once and approve the new Calendar permission. The execution log now also shows a link to **"Masjid-E-Noor-Elahi — Public Website Data"**.
3. **Deploy → Manage deployments → Edit → New version → Deploy.**

**B. Create the public website:**
1. Open the **Public Website Data** spreadsheet from the log (it is in your private Drive folder › Community Website).
2. **Extensions → Apps Script.** This creates a project *bound* to that sheet. Name it "Masjid-E-Noor-Elahi Website".
3. Turn on "Show appsscript.json" in Project Settings. Then paste in every file from the `community/` folder with the same names:
   - `appsscript.json`
   - `Public` (script)
   - `PublicIndex`, `PublicStyles`, `PublicApp`, `PublicGuide`, `PublicArt` and `PrayerCalcJs` (HTML)
4. **Deploy → New deployment → Web app**
   - Execute as: **Me**
   - Who has access: **Anyone** (no Google sign-in needed for the community)
5. Approve the permission. Google will only ask to *"view and manage spreadsheets that this application has been installed in"*. That's the proof the website can't reach anything else.
6. Copy the website URL (it ends in `/exec`).

**C. Fill it in (in the private app):**
1. **Users & Roles** → add the Imam or secretary with role **Community Manager (Imam / Secretary)**.
2. **Community Website › Website Settings:**
   - **Location:** in Google Maps, *press and hold on the masjid*, copy the coordinates (e.g. `17.385044, 78.486671`), paste them into the box and press "Use these coordinates". Check the preview against a trusted local timetable once.
   - Paste the website URL into **Community website URL**. The website then shows a **🔒 Committee login** button that opens the private app, and the app's login page links back to the website. The app address is detected automatically; if the button doesn't appear, paste the private app's `/exec` link into **Committee app URL**. You can hide the button with **Show a "Committee login" button**.
   - Fill in Jumu'ah times, About, Contacts, Facilities, WhatsApp link, UPI ID, and upload the UPI QR. Then Save.
3. **Jamaat Times:** set each prayer's Jamaat. Maghrib is usually "5 minutes after Azan".
4. **Dawat & Programmes, Events, Announcements:** add your weekly schedule and notices.
5. **Community Home** (Admin): press **Make calendar public**, then use **Share on WhatsApp** to send the website and calendar links to the community.
6. **Before each Ramadan:** after moon sighting, set the first Roza date (and Eid dates) under **Ramadan & Eid**, then press **Publish Sehri/Iftar to Google Calendar**.

**Which link to share:** give everyone the **community website** link — it is the front door. Committee members reach their login through the 🔒 button (or a bookmark).

Every save publishes automatically; the website shows changes within about 2 minutes. If moon sighting makes the Hijri date one day off, set **Hijri date adjustment** to −1 or +1.

## 4. Roles (enforced on the server for every request)

| Role | Can do |
|---|---|
| **Admin** | Everything: users, settings, lock date, cancel vouchers, waive dues, backups |
| **Treasurer / Accountant** | All vouchers, members, plans, masters, reports, bank reconciliation |
| **Trustee / Approver** | Approve/reject payments, view reports and audit log |
| **Collector** | Record donations and membership fees, issue receipts; sees only their own entries |
| **Auditor** | Read-only books, reports and audit log |
| **Community Manager** | Community website only: Jamaat times, announcements, events, Dawat programmes, Janazah, Ramadan, website requests. No access to money, members or reports. |

Recommended set-up: 1–2 Admins, 1 Treasurer, 2 Trustees (approvers), Collectors as needed, an Auditor for the yearly audit.

---

## 5. Security design

A full penetration test was run on this version (see `SECURITY-AUDIT.md`). Key protections:

**Access**
- The spreadsheet and Drive folder are never shared. The web app runs as the owner; users never get access to the Sheet or Drive. Files are streamed through the app after a permission check, only from the app's own upload/receipt/report folders (never backups or the database).
- Personal app passwords (min 10 characters, letters + numbers, common words blocked), hashed with salted, iterated HMAC-SHA-256 (2,500 rounds, upgraded automatically). Sign-in errors are identical for unknown, wrong, disabled and paused accounts. After 5 wrong passwords that account's sign-in pauses for 10 minutes (Admin can clear it with **Unlock**).
- Sessions end after 6 h idle and **12 h maximum**; disabling a user, changing their role or resetting their password takes effect on their very next click.
- Only `api()` and `apiLogin()` can be called from a browser. Scheduled jobs refuse to run unless Google's trigger service calls them; owner tools (`setup`, `adminResetPassword`, `restoreFromBackup`) refuse unless the owner runs them in the editor.
- Collectors see member names and the last 4 phone digits only — no addresses, emails, notes or bank details.

**Money (insider-fraud controls)**
- Double-entry: every voucher must balance; no future dates; lock date; back-dating limit for non-admins.
- **Maker-checker** (by user ID, not editable email): payments and contra transfers at or above the approval limit, several smaller payments to the same payee within 7 days, a person's own payments that add up past the limit in a day, and any payment above the bill limit without a bill all wait for a second person. **Every journal** needs a second person, and journals can never move cash or bank. *Exception (setting "Admins may approve their own…", ON by default at the masjid's request):* an Admin may approve their own entries; each such approval is labelled "[Self-approved by Admin]", written to the Audit Log, and shown as a warning on every Trustee/Auditor dashboard for 30 days. Switch it OFF in Settings for strict maker-checker.
- **Fund protection**: each fund's own cash is tracked, so no fund — General included — can spend Zakat/Sadaqah/Construction money. Restricted funds can only be charged to ledgers designated for them; Zakat received is always recorded in the Zakat Fund. Only an Admin can create funds or change their restrictions.
- Only an Admin can create cash/bank accounts, enter opening balances, cancel vouchers, waive dues, or rename/regroup ledgers that already have entries. Ledgers with entries in a closed period can't be regrouped; nothing dated in a locked period can be approved, rejected, reconciled or cancelled.
- Re-opening locked books shows a warning on every Trustee/Auditor dashboard for 30 days.
- Cancelling a voucher keeps it (marked CANCELLED) and is blocked if it would make cash or any fund negative. Nothing is ever deleted.

**Data & injection**
- All writes take a `LockService` lock and re-read data fresh inside it; cached copies are version-checked, so stale data can never drive a decision, and cached user data never contains password salts or hashes.
- Text is normalised (zero-width/bidi characters removed, look-alike letters folded) so "Cash in Hаnd" cannot impersonate "Cash in Hand". All sheet columns are stored as plain text (no formulas); CSV exports neutralise formula characters on every line.
- Amounts must be plain numbers with at most 2 decimals. Internal errors are never shown to users (they get a reference code; details go to the owner's execution log).
- Uploads: JPG/PNG/WEBP/PDF only, true file signature checked, PDFs containing JavaScript/launch actions rejected, 200 MB per person per day. Receipt emails: 20 per person per day; Collectors may only email the member's address on record. Report PDFs are downloaded, not stored, unless a Treasurer/Admin chooses "Save to Drive" (30/day).

**What you must do**
1. Use a dedicated masjid Gmail as owner and turn on **2-Step Verification** — whoever controls that Google account controls everything.
2. Use login emails that aren't published (they are only login IDs), so outsiders can't pause a sign-in.
3. Have at least 2 Admins and 2 Trustees, and download a backup to a second trustee every month.

## 6. Staying within free quotas

Designed for a small community organisation (hundreds of members, a few thousand vouchers per year):

- One batch read per sheet per request; appends and updates are single `setValues` calls; small masters are cached in `CacheService`; the dashboard is cached for 10 minutes.
- New sheets are trimmed to the columns needed, saving the 10-million-cell spreadsheet limit.
- Only two scheduled jobs: a daily backup (a few seconds) and monthly dues (a few seconds).
- Receipt PDFs are generated only when someone clicks "PDF"; printing and WhatsApp sharing use no quota.
- **Backup & Quotas** page (Admin) shows Drive storage, spreadsheet cells, scheduled-job runtime, script-property storage, emails left today, request timings and rows per sheet, and the Admin dashboard shows warnings when any reaches the warning percentage (default 80%).

Typical free consumer-account limits at the time of writing (Google can change these): 6 minutes per execution, 90 minutes/day of trigger runtime, about 100 email recipients/day, 10 million cells per spreadsheet, 15 GB Drive storage shared with Gmail and Photos. Check Google's "Quotas for Google Services" page if something stops working.

---

## 7. Backups and restore

- **Automatic**: every day at ~2 AM a full copy of the database is saved to the private Drive folder › *Backups*. The newest 30 copies are kept (configurable); older **copies** go to Drive trash (live data is never touched).
- **Manual**: Admin → Backup & Quotas → **Backup now** (do this before year-end closing or bulk changes).
- **Off-site copy (recommended monthly)**: open the latest backup in Drive → File → Download → Microsoft Excel, and keep it with a second trustee.
- **Restore**: in the Apps Script editor run `restoreFromBackup('<backup file ID>')` (file IDs are shown on the Backup page). The app switches to a fresh copy of that backup; the previous database is kept, not deleted.
- **Locked out?** Owner runs `adminResetPassword('email@gmail.com')` in the editor; the temporary password appears in the execution log.

---

## 8. Year-end routine

1. Enter all vouchers for the year and reconcile banks (BRS).
2. Print/save to Drive: Receipts & Payments, Income & Expenditure, Balance Sheet, Trial Balance, Fund Statement.
3. **Backup now**.
4. Settings → **Lock date** = last day of the financial year. No one can add or cancel entries for that year any more.

The books carry forward automatically — balance-sheet ledgers keep their balances; income and expenditure start fresh each year in reports.

If the Backup page ever warns about cell usage after many years: make a backup copy as the archive of old years, then start a new database for the new year by running `setup()` after clearing the `SPREADSHEET_ID` script property, and enter closing balances as opening balances.

---

## 9. Daily use cheat-sheet

- **Friday collection** → F6 Receipt → *Jumu'ah Collection* → amount → Save → Print / WhatsApp.
- **Zakat received** → F6 → *Zakat Received* (fund switches to Zakat Fund automatically).
- **Member pays dues** → Membership Collection → type member number/name → tick months → Save.
- **Pay electricity bill** → F5 → *Electricity* → attach bill photo → Save.
- **Imam salary** (above approval limit) → F5 → goes to Approvals → a Trustee approves → posted.
- **Adjustment / correction** → F7 Journal → a second person approves it on the Approvals page.
- **Deposit cash in bank** → F4 Contra → From Cash in Hand → To bank.
- **Month end** → Reports → Receipts & Payments for the month; Bank Reconciliation.

---

## 10. Known limits (free platform)

- Google shows a small banner on Apps Script web apps ("This application was created by a Google Apps Script user"). It cannot be removed without paid hosting.
- WhatsApp sharing opens WhatsApp with the receipt text ready — someone taps Send (the automated WhatsApp Business API is paid).
- Email receipts use the owner account's daily free quota.
- Very large data (e.g. 50,000+ ledger entries) will slow reports; archive by financial year as above.

## 11. Testing (optional, for developers)

`tests/mock.js` emulates Sheets/Drive/Cache/Lock services in Node.js. Run these from the project folder:
- `node tests/run.js .` — 81 accounting checks
- `node tests/security.js .` — 60 security checks replaying every penetration-test finding
- `node tests/community.js .` — 59 community-website checks: role isolation, publishing, calendar, request form abuse, and the website's single-sheet permission
