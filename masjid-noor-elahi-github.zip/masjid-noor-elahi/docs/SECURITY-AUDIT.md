# Security Audit — Masjid-E-Noor-Elahi Management System

**Prepared for:** Masjid-E-Noor-Elahi · **Developed by:** Arhaan Agencies
**Date:** 3 November 2026 · **Version tested:** 1.0.0 → **fixed in 1.1.0**

## How it was tested
Four specialist test agents attacked the real server code in parallel, each from one angle, using a local emulation of Google Sheets, Drive, Cache and Lock services. A fifth check rendered the real user interface in a headless browser.

1. **Authentication & sessions**: brute force, account enumeration, session theft and reuse, calling hidden functions directly.
2. **Injection**: stored XSS in every text field, viewed on every screen; spreadsheet/CSV formula injection; JSON tricks; look-alike Unicode names.
3. **Authorization & money fraud**: every action tried as every role, plus a dishonest committee member trying to move or hide money.
4. **Files, Drive & denial-of-service**: malicious uploads, reading private Drive files, filling quotas, email abuse.

Every finding was reproduced, fixed, and turned into an automated test. `tests/security.js` replays all of them (60 checks, all now blocked), and `tests/run.js` re-checks normal accounting (81 checks). After the fixes, the agents' own attack scripts were run again and failed.

## Results summary
| Severity | Found | Fixed |
|---|---|---|
| Critical | 1 | 1 |
| High | 8 | 8 |
| Medium | 8 | 8 |
| Low / Info | 9 | 6 fixed, 3 accepted (explained below) |

**What held from the start:** no XSS executed anywhere (49 screens and dialogs tested with payloads from every role); no SQL-style injection is possible; session tokens are 256-bit and cannot be forced or guessed; the owner-only functions refused outsiders; the database and backups could not be downloaded; audit logs cannot be edited from the app; and Trial Balance / Balance Sheet always tallied.

## Findings and fixes

### Critical
| ID | Loophole | Fix |
|---|---|---|
| AZ-1 | A **Journal voucher** skipped approval, the cash check and the Zakat check. A Treasurer could post "Dr Salary / Cr Bank ₹50,000", drive cash negative, or move Zakat into General, with no second person involved. | Journals can no longer touch cash or bank (the Tally rule: cash moves only through Receipt, Payment or Contra). **Every** journal now needs approval by a different person, and a journal cannot take any fund below zero. |

### High
| ID | Loophole | Fix |
|---|---|---|
| AZ-2 | **Split payments**: ten ₹4,999 payments avoided the ₹5,000 approval limit, using "no bill" reasons. | Approval is now required when payments to the same payee within 7 days, or one person's payments in a day, reach the limit (matched by a look-alike-proof name). Any no-bill payment above the bill limit also needs approval. |
| AZ-3 | A Treasurer could **create a new bank account** and move ₹1.5 lakh into it by Contra, instantly. | Only an Admin can create accounts. Contra transfers at or above the limit (or adding up past it in a day) need approval. |
| AZ-4 | **Fake opening balances**: a Treasurer could invent assets, back-date cash, or post a debit opening on a Zakat reserve to drain it. | Opening balances are Admin-only. Assets always open Dr and liabilities/funds always open Cr. A cash account's opening can be set only once, before its first entry. |
| AZ-5 | **Zakat protection bypasses**: (a) a Treasurer could switch off the restriction; (b) General payments could silently spend Zakat cash; (c) Zakat could be received as General; (d) cancelling a spent Zakat receipt left the fund negative. | (a) Funds are Admin-only, and a restricted fund with a balance can't be unrestricted or deactivated. (b) Each fund's own cash is tracked, so no fund can spend another's. (c) Zakat/restricted ledgers always post to their fund, and restricted funds can only be charged to their designated ledgers. (d) A cancellation that would make a fund negative is blocked. |
| AUTH-1 / FILE-3 | The two **scheduled jobs** (daily backup, monthly dues) could be triggered by any visitor without logging in. | They now run only when called by Google's trigger service with a genuine trigger ID; any browser call is refused. |
| AUTH-2 / FILE-4 | **Login denial-of-service**: anyone knowing the admin's email could keep it locked. The login code also held the global write lock, so login spam could block financial entries. | Login no longer takes the write lock; failure counting moved to the cache. The pause is 10 minutes and an Admin can clear it with **Unlock**. Residual risk: see "Accepted" below. |
| FILE-1 | The **report PDF** button saved a new Drive file on every click, even for read-only roles, which could fill the owner's 15 GB. | PDFs now download without being stored. "Save to Drive" is limited to Treasurer/Admin, 30 per person per day. |
| FILE-2 / AZ-9 | **Receipt email** could be sent to any address by Collectors, Auditors and Approvers, an open relay through the masjid Gmail. | A new `receipts.send` permission (Admin, Treasurer, Collector only). Collectors can email only the member's address on record. 20 emails per person per day; cancelled receipts can't be emailed. |

### Medium
| ID | Loophole | Fix |
|---|---|---|
| AUTH-3 | **Account enumeration**: different messages and timing revealed which emails existed or were disabled. | One identical message for every failure, and the password hash is always computed so timing is equal. |
| AUTH-4 | An active session could renew forever. | Absolute 12-hour maximum, on top of the 6-hour idle timeout. |
| AZ-6 | **Cache race**: a disabled user could keep working up to 6 hours if a read overlapped the change. Lock date and fund rule changes could also be lost. | Every cached table carries a version number that is bumped on each write, so stale copies are ignored. All reads inside a financial write come fresh from the sheet. |
| AZ-7 | **Maker-checker dodge**: an Admin could change their own email and then approve their own payment. | Approvals compare user IDs. Nobody can change their own login email. |
| AZ-8 | **Closed-period side doors**: bank reconciliation, rejecting, regrouping or renaming ledgers still changed locked years. | All are blocked for locked dates. Renaming or regrouping a ledger that has entries is Admin-only. Re-opening locked books shows a warning on every Trustee/Auditor dashboard for 30 days. |
| INJ-1 | **CSV formula injection**: hidden line breaks let `=…` formulas run when an export was opened in Excel or LibreOffice. | Line breaks are stripped from single-line fields. CSV export neutralises formula characters at the start of every line, including after spaces and in full-width forms. |
| INJ-2 | **Look-alike names**: "Cash in Hаnd" (Cyrillic а), zero-width spaces and RTL tricks could impersonate real ledgers or accounts. | Invisible and direction characters are removed, and names are compared by a look-alike-proof key. |
| INJ-3 | **Internal error details** (code messages) were shown to users. | Users see "Something went wrong (ref XXXX)"; details go only to the owner's execution log. |

### Low / Info
| ID | Item | Status |
|---|---|---|
| AUTH-5 | Password hashing only 400 rounds; 8-character passwords | Fixed: 2,500 rounds (auto-upgrade at next login), constant-time compare, minimum 10 characters, common words blocked. |
| FILE-5 / AZ-10 | Collectors saw every member's phone, address, notes and bank details | Fixed: Collectors see name, member number and the last 4 phone digits only. |
| FILE-6 | WEBP check accepted any RIFF file (WAV/AVI) | Fixed: full WEBP signature check. PDFs containing JavaScript, launch actions or embedded files are rejected. Uploads capped at 200 MB per person per day. |
| FILE-7 | Password hashes were stored in the shared cache | Fixed: the cache holds only a short fingerprint. |
| AZ-11 | Amounts like `true`, `[5]`, `0x10` were accepted | Fixed: plain numbers with at most 2 decimals only. |
| INJ-4 | Objects or arrays sent where text was expected | Fixed: rejected with "must be text" / "Bad request". |
| AZ-12 | Treasurer and Auditor can read approval history | Accepted by design (transparency for the auditor). |
| FILE-8 | "Polyglot" files (valid image or PDF header with hidden HTML) are accepted | Accepted: the app never renders uploads as HTML (images display as images, PDFs only download), so the hidden content can't run. |
| CLIENT-1 | Session token is kept in browser sessionStorage | Accepted: there is no XSS sink (verified), and the token expires within 12 hours. |

## Accepted residual risks (cannot be fully removed on a free platform)
1. **Sign-in pause abuse**: the app can't see visitors' IP addresses, so someone who knows a login email can still pause that account for 10 minutes at a time. Mitigations: an Admin can Unlock it, the owner can reset from the editor, and you should **use login emails that are not published**. They are only login IDs and don't need to be the person's public address.
2. **The owner's Google account is the master key.** Anyone controlling it can open the Sheet directly. Use a dedicated masjid Gmail with 2-Step Verification and recovery options, and keep its password with two trustees.
3. **Admins are trusted.** They can re-open locked books and cancel vouchers, but every such action is audit-logged, cancelled vouchers stay visible, and unlocks are shown to Trustees and Auditors.
4. **Direct sheet edits by the owner** bypass the app's controls. Monthly off-site backup copies held by a second trustee make any later tampering detectable by comparison.

## Recommended operating practice
- Keep at least 2 Admins and 2 Trustees, and never share logins.
- Set the approval limit to suit the masjid (default ₹5,000).
- At month end, a Trustee reviews the Approvals history, the Audit Log (filter "CANCEL", "UNLOCK", "PASSWORD") and the Bank Reconciliation.
- At year end, lock the books and download the backup to a second trustee.

## Addendum — Community website (v1.2, 20 November 2026)
The new public website was built with these protections and tested by `tests/community.js` (56 checks) and a browser run with attack payloads in every field, in both English and Urdu:
- **Isolation.** The public site is a separate project bound to its own "Public Website Data" sheet, with only the `spreadsheets.currentonly` permission. A test confirms its code calls no other Google service (no `openById`, Drive, Mail, Calendar or Properties).
- **Publish-only data.** The private app writes a snapshot of public information only. A test confirms it contains no emails, user data, member IDs, amounts or ledger data.
- **Community Manager role** can only manage community content; every finance action is refused on the server.
- **Safe content.**
  - Links are limited to https Google Maps, WhatsApp, Telegram and Apps Script addresses; UPI IDs are validated.
  - All text is escaped on screen, and the embedded data can't break out of its script tag.
  - In the browser test, XSS payloads in every field displayed as plain text on all 18 page/language combinations.
- **Request form.** Protections:
  - A hidden honeypot field and a minimum fill time stop simple bots.
  - Limits: 3 requests per phone per day and 40 per hour site-wide, with a 5,000-row cap.
  - Strict validation; formula characters are neutralised.
  - Phone numbers are visible only to the committee.
- **Calendar.** Only an Admin can make the calendar public. Calendar items are removed when a notice is hidden.

## Owner decision — 20 November 2026
At the masjid's request, **Admins may approve their own payments, contra transfers and journals** (setting `ADMIN_SELF_APPROVE`, default YES). This relaxes finding AZ-7's maker-checker control for the Admin role only. Compensating controls:
- every Admin self-approval is labelled "[Self-approved by Admin]" in the approval record;
- each one is written to the Audit Log as `ADMIN_SELF_APPROVE`;
- a warning with the count and total amount appears on every Trustee/Auditor dashboard for 30 days.

Treasurers, Collectors and other roles still can never approve their own entries. Recommendation: keep at least two Admins and switch the setting OFF once a second approver is routinely available.
