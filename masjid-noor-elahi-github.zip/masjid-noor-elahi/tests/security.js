// Security regression suite: replays every finding from the penetration test and expects it to be BLOCKED.
// Run: node tests/security.js .
const { makeCtx } = require('./mock');
const vm = require('vm'); const fs = require('fs');
const OWNER = 'owner@gmail.com';
const C = makeCtx(OWNER);
const reset = () => vm.runInContext('_memo = { t: {}, h: {}, idx: {} };', C);
let pass = 0, failN = 0;
const ok = (c, m) => { if (c) pass++; else { failN++; console.log('  ✗', m); } };
const api = (tok, a, p) => { reset(); return C.api(tok, a, p).data; };
const err = (tok, a, p) => { reset(); try { C.api(tok, a, p); return ''; } catch (e) { return e.message; } };
const loginErr = (e, pw) => { reset(); try { C.apiLogin(e, pw); return ''; } catch (x) { return x.message; } };
const login = (e, pw) => { reset(); return C.apiLogin(e, pw); };
const PW = 'Gq7vLm2pXz';

const pw0 = /Password: (\S+)/.exec(C.setup())[1];
let A = login(OWNER, pw0).token; api(A, 'auth.changePassword', { oldPassword: pw0, newPassword: PW });
function mk(email, role, pw) {
  const u = api(A, 'users.save', { Email: email, Name: role, Role: role });
  const s = login(email, u.tempPassword); api(s.token, 'auth.changePassword', { oldPassword: u.tempPassword, newPassword: pw });
  return { token: s.token, id: u.user.UserID };
}
const TR = mk('tr@gmail.com', 'TREASURER', 'Hk4wRt9sBn'), AP = mk('ap@gmail.com', 'APPROVER', 'Km5zXa1fWq');
const CO = mk('co@gmail.com', 'COLLECTOR', 'Jp3yUe8dCv'), AU = mk('au@gmail.com', 'AUDITOR', 'Lw6cNe4tYh');
const B = api(A, 'bootstrap'), t = B.today;
const bank = api(A, 'accounts.save', { Name: 'SBI Current', Type: 'Bank', OpeningBalance: 100000 });
api(A, 'accounts.save', { AccountID: 'ACC-CASH', Name: 'Cash in Hand', Type: 'Cash', OpeningBalance: 20000 });

console.log('— Authentication');
ok(/Refused/.test(C.monthlyDuesTrigger()) && /Refused/.test(C.dailyBackupTrigger({ triggerUid: '1' })), 'AUTH-1 scheduled jobs refuse browser calls');
const msgs = [loginErr('nobody@x.com', 'abc'), loginErr(OWNER, 'wrong')];
api(A, 'users.save', { UserID: AU.id, Email: 'au@gmail.com', Name: 'AUDITOR', Role: 'AUDITOR', Status: 'Disabled' });
msgs.push(loginErr('au@gmail.com', 'Lw6cNe4tYh'));
ok(new Set(msgs).size === 1, 'AUTH-3 identical message for unknown / wrong / disabled: ' + JSON.stringify([...new Set(msgs)]));
api(A, 'users.save', { UserID: AU.id, Email: 'au@gmail.com', Name: 'AUDITOR', Role: 'AUDITOR', Status: 'Active' });
for (let i = 0; i < 5; i++) loginErr('co@gmail.com', 'bad');
ok(loginErr('co@gmail.com', 'Jp3yUe8dCv') === msgs[0], 'AUTH-2 sign-in paused (same generic message)');
api(A, 'users.unlock', { UserID: CO.id });
ok(!loginErr('co@gmail.com', 'Jp3yUe8dCv'), 'AUTH-2 admin can clear the pause immediately');
// absolute session lifetime
const sess = login('ap@gmail.com', 'Km5zXa1fWq').token, key = 'SES_' + sess, sObj = JSON.parse(C._.cache[key]);
sObj.iat = Date.now() - 13 * 3600000; C._.cache[key] = JSON.stringify(sObj);
ok(/expired/.test(err(sess, 'dashboard')), 'AUTH-4 sessions die after 12 h even when active');
// legacy hash upgrade + v2 format
reset(); const sh = Object.values(C._.store.ss)[0].getSheetByName('User Roles');
const hrow = sh.data[0].indexOf('PasswordHash');
ok(sh.data.slice(1).every(r => String(r[hrow]).startsWith('v2$2500$')), 'AUTH-5 all hashes use strengthened v2 KDF');
ok(/at least 10|easy to guess/.test(err(TR.token, 'auth.changePassword', { oldPassword: 'Hk4wRt9sBn', newPassword: 'masjid2026' })), 'AUTH-5 weak password rejected');

console.log('— Files & data exposure');
ok(!/TBL_User Roles/.test(Object.keys(C._.cache).join()) || !/"Salt":"[0-9a-f]{10,}/.test(C._.cache['TBL_User Roles'] || ''), 'FILE-7 no salts/hashes in cache');
reset(); api(A, 'dashboard'); const cu = C._.cache['TBL_User Roles'] || '';
ok(cu && !/v2\$2500\$/.test(cu), 'FILE-7 cached users hold only a fingerprint');
const filesBefore = Object.keys(C._.store.files).length;
for (let i = 0; i < 5; i++) api(AU.token, 'report.pdf', { Report: 'trialBalance' });
ok(Object.keys(C._.store.files).length === filesBefore, 'FILE-1 report PDF download creates no Drive files');
ok(/only the Treasurer or Admin/.test(err(AU.token, 'report.pdf', { Report: 'trialBalance', Save: true })), 'FILE-1 auditor cannot save PDFs to Drive');
let capHit = '';
for (let i = 0; i < 31 && !capHit; i++) capHit = err(TR.token, 'report.pdf', { Report: 'trialBalance', Save: true });
ok(/Daily limit/.test(capHit), 'FILE-1 daily cap on saved report PDFs');
api(A, 'settings.save', { settings: { EMAIL_RECEIPTS: 'YES' } });
const inc = api(CO.token, 'income.create', { Date: t, LedgerID: 'LED-D03', Amount: 100, AccountID: 'ACC-CASH' });
ok(/only email a receipt to the member/.test(err(CO.token, 'receipt.email', { ReceiptID: inc.receipt.ReceiptID, Email: 'victim@example.com' })), 'FILE-2 collector cannot email arbitrary addresses');
ok(/permission/.test(err(AU.token, 'receipt.email', { ReceiptID: inc.receipt.ReceiptID, Email: 'x@example.com' })), 'AZ-9 auditor cannot send emails');
let em = ''; for (let i = 0; i < 21 && !em; i++) em = err(TR.token, 'receipt.email', { ReceiptID: inc.receipt.ReceiptID, Email: 'donor@example.com' });
ok(/Daily limit/.test(em), 'FILE-2 daily cap on receipt emails');
const mem = api(TR.token, 'members.save', { Name: 'Yusuf', Phone: '9876543210', Email: 'y@x.com', Address: 'Secret St', Notes: 'widow, needs zakat', PlanID: 'PLN-DEFAULT', JoinDate: '2026-04-01' });
const cl = api(CO.token, 'members.list', {}).find(m => m.MemberID === mem.MemberID);
ok(cl && !cl.Email && !cl.Address && !cl.Notes && /^XXXXXX3210$/.test(cl.Phone), 'FILE-5 collector sees no member PII');
const cb = api(CO.token, 'bootstrap').accounts.find(a => a.AccountID === bank.AccountID);
ok(cb && cb.IFSC === undefined && cb.BankName === undefined, 'AZ-10 collector sees no bank details');
const wav = Buffer.concat([Buffer.from('RIFF'), Buffer.alloc(4), Buffer.from('WAVEfmt '), Buffer.alloc(20)]).toString('base64');
ok(/does not match/.test(err(CO.token, 'income.create', { Date: t, LedgerID: 'LED-D03', Amount: 1, AccountID: 'ACC-CASH', file: { mimeType: 'image/webp', data: wav } })), 'FILE-6 WAV disguised as WEBP rejected');
const jsPdf = Buffer.from('%PDF-1.4 1 0 obj << /OpenAction << /S /JavaScript /JS (app.alert(1)) >> >>').toString('base64');
ok(/contains scripts/.test(err(CO.token, 'income.create', { Date: t, LedgerID: 'LED-D03', Amount: 1, AccountID: 'ACC-CASH', file: { mimeType: 'application/pdf', data: jsPdf } })), 'FILE-x PDF with JavaScript rejected');

console.log('— Money controls (maker-checker, funds, locks)');
ok(/cannot touch cash/.test(err(TR.token, 'journal.create', { Date: t, Narration: 'steal', Lines: [{ LedgerID: 'LED-D41', Debit: 50000 }, { LedgerID: bank.AccountID, Credit: 50000 }] })), 'AZ-1 journal cannot move cash/bank');
const jz = err(TR.token, 'journal.create', { Date: t, Narration: 'move zakat', Lines: [{ LedgerID: 'LED-D04', FundID: 'FND-ZAKAT', Debit: 40000 }, { LedgerID: 'LED-D03', FundID: 'FND-GEN', Credit: 40000 }] });
ok(/below zero/.test(jz), 'AZ-1 journal cannot drain Zakat fund: ' + jz);
const j = api(TR.token, 'journal.create', { Date: t, Narration: 'adjust', Lines: [{ LedgerID: 'LED-D41', Debit: 10 }, { LedgerID: 'LED-D42', Credit: 10 }] });
ok(j.pending && j.record.Status === 'PENDING_APPROVAL', 'AZ-1 every journal needs approval');
const e1 = api(TR.token, 'expense.create', { Date: t, LedgerID: 'LED-D25', Amount: 900, AccountID: 'ACC-CASH', PayeeName: 'Mason Ali', Narration: 'Work 1' });
const results = [];
for (let i = 0; i < 6; i++) results.push(api(TR.token, 'expense.create', { Date: t, LedgerID: 'LED-D25', Amount: 900, AccountID: 'ACC-CASH', PayeeName: 'MASON  ali', Narration: 'Work ' + i }).pending);
ok(!e1.pending && results.includes(true), 'AZ-2 split payments to one payee go to approval: ' + results);
const nb = api(TR.token, 'expense.create', { Date: t, LedgerID: 'LED-D33', Amount: 2000, AccountID: 'ACC-CASH', PayeeName: 'Other person', Narration: 'misc', NoBillReason: 'no bill was given to us' });
ok(nb.pending, 'AZ-2 no-bill payment above limit needs approval');
ok(/Only an Admin/.test(err(TR.token, 'accounts.save', { Name: 'HDFC new', Type: 'Bank' })), 'AZ-3 treasurer cannot create bank accounts');
ok(api(TR.token, 'transfer.create', { Date: t, FromAccountID: bank.AccountID, ToAccountID: 'ACC-CASH', Amount: 6000 }).pending, 'AZ-3 large contra needs approval');
ok(/Only an Admin/.test(err(TR.token, 'ledgers.save', { Name: 'Land', Group: 'Fixed Assets', OpeningBalance: 9999999 })), 'AZ-4 treasurer cannot invent opening balances');
const lz = api(A, 'ledgers.save', { Name: 'Zakat Reserve', Group: 'Earmarked Funds', FundID: 'FND-ZAKAT', OpeningBalance: 100, OpeningType: 'Dr' });
ok(lz.OpeningType === 'Cr', 'AZ-4 liability opening is always Cr (cannot drain a fund)');
ok(/Only an Admin/.test(err(TR.token, 'funds.save', { FundID: 'FND-ZAKAT', Name: 'Zakat Fund', Type: 'Restricted', RestrictSpending: 'NO' })), 'AZ-5 treasurer cannot unrestrict Zakat');
ok(/must be recorded in Zakat/.test(err(CO.token, 'income.create', { Date: t, LedgerID: 'LED-D04', FundID: 'FND-GEN', Amount: 500, AccountID: 'ACC-CASH' })), 'AZ-5 Zakat cannot be received as General');
const zr = api(A, 'income.create', { Date: t, LedgerID: 'LED-D04', Amount: 60000, AccountID: bank.AccountID, Mode: 'UPI' });
ok(/restricted/.test(err(TR.token, 'expense.create', { Date: t, LedgerID: 'LED-D23', FundID: 'FND-ZAKAT', Amount: 100, AccountID: 'ACC-CASH', PayeeName: 'EB', Narration: 'power' })), 'AZ-5 electricity cannot be charged to Zakat');
const gen = api(A, 'report.run', { Report: 'funds' });
// try spending General money beyond what General holds (using Zakat cash in the bank)
const big = err(A, 'expense.create', { Date: t, LedgerID: 'LED-D25', Amount: 150000, AccountID: bank.AccountID, Mode: 'UPI', PayeeName: 'Builder X', Narration: 'repairs', NoBillReason: 'quotation pending from builder' });
ok(/holds only/.test(big), 'AZ-5 General cannot spend Zakat cash: ' + big);
api(A, 'expense.create', { Date: t, LedgerID: 'LED-D27', Amount: 59000, AccountID: bank.AccountID, Mode: 'UPI', PayeeName: 'Needy family', Narration: 'zakat', NoBillReason: 'zakat paid directly to family' });
const pend = api(AP.token, 'approvals.list', {}).find(x => x.expense.PayeeName === 'Needy family');
api(AP.token, 'expense.decide', { ApprovalID: pend.approval.ApprovalID, Decision: 'APPROVED' });
ok(/holds only|Insufficient/.test(err(A, 'voucher.cancel', { Type: 'INCOME', ID: zr.record.IncomeID, Reason: 'hide the zakat' })), 'AZ-5 cannot cancel Zakat receipt that was already spent');
// AZ-6 stale cache: put a cache entry made before a write; it must be ignored
reset(); api(A, 'users.list', {}); const stale = C._.cache['TBL_User Roles'];
api(A, 'users.save', { UserID: AU.id, Email: 'au@gmail.com', Name: 'AUDITOR', Role: 'AUDITOR', Status: 'Disabled' });
C._.cache['TBL_User Roles'] = stale; // simulate the race writing old data back
ok(/AUTH/.test(err(AU.token, 'audit.list', {})), 'AZ-6 stale cached user table is ignored (disabled user stays out)');
ok(/own login email/.test(err(A, 'users.save', { UserID: api(A, 'bootstrap').user.id, Email: 'other@gmail.com', Name: 'A', Role: 'ADMIN' })), 'AZ-7 cannot change own email to dodge maker-checker');
// AZ-8 locked period side doors
const ex = api(TR.token, 'expense.create', { Date: t, LedgerID: 'LED-D20', Amount: 7000, AccountID: bank.AccountID, Mode: 'UPI', PayeeName: 'Imam', Narration: 'salary', NoBillReason: 'monthly salary by transfer' });
const brs = api(A, 'report.run', { Report: 'brs', LedgerID: bank.AccountID });
api(A, 'settings.save', { settings: { LOCK_DATE: t } });
ok(/locked/.test(err(TR.token, 'brs.clear', { EntryIDs: [brs.items[0].EntryID], ClearedDate: t })), 'AZ-8 BRS cannot touch locked period');
ok(/locked/.test(err(AP.token, 'expense.decide', { ApprovalID: ex.record.ApprovalID, Decision: 'REJECTED', Remarks: 'x' })), 'AZ-8 locked-period voucher cannot be rejected either');
ok(/locked|Admin/.test(err(TR.token, 'ledgers.save', { LedgerID: 'LED-D25', Name: 'Electricity Charges', Group: 'Repairs & Maintenance', FundID: 'FND-GEN' })), 'AZ-8 treasurer cannot rename a ledger with history');
ok(/locked/.test(err(A, 'ledgers.save', { LedgerID: 'LED-D25', Name: 'Repairs & Maintenance', Group: 'Utilities', FundID: 'FND-GEN' })), 'AZ-8 ledger with locked entries cannot be regrouped');
api(A, 'settings.save', { settings: { LOCK_DATE: '' } });
reset(); const dw = api(AP.token, 'dashboard').warnings || [];
ok(dw.some(w => /unlocked/.test(w)), 'AZ-8 trustees see a warning when books are unlocked');
console.log('— Input validation & injection');
['true', [5], '0x10', ' 1e3', 'Infinity', '5.001'].forEach(v => ok(/number|decimal/.test(err(CO.token, 'income.create', { Date: t, LedgerID: 'LED-D03', Amount: v === 'true' ? true : v, AccountID: 'ACC-CASH' })), 'AZ-11 amount ' + JSON.stringify(v) + ' rejected'));
ok(/already exists/.test(err(A, 'ledgers.save', { Name: 'Cash in Hаnd', Group: 'Fixed Assets' })), 'INJ homoglyph name rejected');
ok(/already exists/.test(err(A, 'ledgers.save', { Name: 'Imam​ Salary', Group: 'Utilities' })), 'INJ zero-width name rejected');
const nl = api(CO.token, 'income.create', { Date: t, LedgerID: 'LED-D03', Amount: 1, AccountID: 'ACC-CASH', DonorName: 'Abdul\r=2+5\r@SUM(1)' });
ok(!/[\r\n]/.test(nl.record.DonorName), 'INJ-1 CR/LF stripped from single-line fields');
ok(/must be text/.test(err(TR.token, 'members.save', { Name: { toString: 1 } })), 'INJ object where text expected rejected');
ok(/Bad request/.test(err(TR.token, 'members.list', [1, 2])), 'INJ array payload rejected');
vm.runInContext("actions_()['users.list'].fn = function(){ return null.x; }", C);
const ie = err(A, 'users.list', {});
ok(/Something went wrong \(ref/.test(ie) && !/null|property|stack/i.test(ie), 'INJ internal errors are not leaked: ' + ie);
// CSV export hardening (client function)
const app = fs.readFileSync(process.argv[2] + '/App.html', 'utf8');
const csvSrc = /function csvCell[\s\S]*?\n}/.exec(app)[0];
const csvCell = new Function(csvSrc + '; return csvCell;')();
['=1+1', ' =1+1', '　=1+1', '+cmd', '-2+3', '@SUM(1)', 'a\r=1+1', '\t=x'].forEach(v => {
  const out = csvCell(v); ok(!/(^|\n|")[\s　]*[=+\-@\t]/.test(out.replace(/'/g, '§')) || out.includes("'"), 'INJ-1 CSV neutralised ' + JSON.stringify(v) + ' → ' + JSON.stringify(out));
});
console.log(`\nSECURITY: ${pass} passed, ${failN} failed`);
process.exit(failN ? 1 : 0);
