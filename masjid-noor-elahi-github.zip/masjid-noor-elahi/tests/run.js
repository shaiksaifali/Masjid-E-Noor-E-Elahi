const { makeCtx } = require('./mock');
const vm = require('vm');
const OWNER = 'owner@gmail.com';
const C = makeCtx(OWNER);
const reset = () => vm.runInContext('_memo = { t: {}, h: {}, idx: {} };', C);
let pass = 0, failN = 0;
function ok(cond, msg) { if (cond) { pass++; } else { failN++; console.log('  ✗ FAIL:', msg); } }
function api(tok, a, p) { reset(); return C.api(tok, a, p).data; }
function apiErr(tok, a, p) { reset(); try { C.api(tok, a, p); return null; } catch (e) { return e.message; } }
function login(e, pw) { reset(); return C.apiLogin(e, pw); }

// --- setup
const out = C.setup();
const pw = /Password: (\S+)/.exec(out)[1];
ok(C._.triggers.length === 2, 'two triggers installed');
reset(); C.setup(); // idempotent
ok(C._.triggers.length === 2, 'setup idempotent');
const ss = Object.values(C._.store.ss)[0];
ok(ss.sheets.length === 23, '23 sheets created: ' + ss.sheets.map(s => s.name).join(','));

// --- auth
ok(/Sign-in failed/.test((() => { try { login(OWNER, 'wrong'); } catch (e) { return e.message; } })()), 'bad password rejected');
let s = login(OWNER, pw); let T = s.token;
ok(s.user.mustChange, 'must change temp pw');
ok(/change your temporary password/.test(apiErr(T, 'dashboard')), 'blocked until pw change');
api(T, 'auth.changePassword', { oldPassword: pw, newPassword: 'Gq7vLm2pXz' });
ok(api(T, 'dashboard') !== null, 'dashboard after pw change');
ok(/AUTH/.test(apiErr('f'.repeat(64), 'dashboard')), 'bad token rejected');
C._.setActive('stranger@gmail.com');
ok(/owner/.test((() => { try { C.setup(); } catch (e) { return e.message; } })()), 'setup blocked for non-owner');
C._.setActive(OWNER);

const B = api(T, 'bootstrap');
ok(B.ledgers.length === 27 && B.funds.length === 5, 'defaults seeded');

// --- masters
const bank = api(T, 'accounts.save', { Name: 'SBI Current', Type: 'Bank', BankName: 'SBI', AccountNo: '123456789012', IFSC: 'SBIN0001234', OpeningBalance: 10000 });
ok(bank.AccountNoMasked === 'XXXX9012', 'account masked');
api(T, 'settings.save', { settings: { MASJID_NAME: 'Masjid-e-Noor', APPROVAL_THRESHOLD: '5000' } });
ok(/locked|future/i.test(apiErr(T, 'settings.save', { settings: { LOCK_DATE: '2099-01-01' } }) || ''), 'future lock date rejected');

// --- income
const t = api(T, 'bootstrap').today;
const inc1 = api(T, 'income.create', { Date: t, LedgerID: 'LED-D03', Amount: 5000, AccountID: 'ACC-CASH', Mode: 'Cash', DonorName: 'Abdul' });
ok(/^RV\/\d{4}-\d{2}\/00001$/.test(inc1.record.VoucherNo), 'RV numbering ' + inc1.record.VoucherNo);
ok(inc1.receipt.AmountWords === 'Rupees Five Thousand Only', 'amount words');
const zak = api(T, 'income.create', { Date: t, LedgerID: 'LED-D04', Amount: 2000, AccountID: bank.AccountID, Mode: 'UPI', DonorName: 'X' });
ok(zak.record.FundID === 'FND-ZAKAT', 'zakat fund auto');
ok(/bank account/.test(apiErr(T, 'income.create', { Date: t, LedgerID: 'LED-D03', Amount: 10, AccountID: 'ACC-CASH', Mode: 'UPI' })), 'UPI into cash rejected');
ok(/Future/.test(apiErr(T, 'income.create', { Date: '2099-01-01', LedgerID: 'LED-D03', Amount: 10, AccountID: 'ACC-CASH' })), 'future date rejected');
ok(/greater than zero/.test(apiErr(T, 'income.create', { Date: t, LedgerID: 'LED-D03', Amount: -5, AccountID: 'ACC-CASH' })), 'negative amount rejected');
ok(/cannot be used/.test(apiErr(T, 'income.create', { Date: t, LedgerID: 'LED-D23', Amount: 5, AccountID: 'ACC-CASH' })), 'expense ledger in receipt rejected');

// --- members & dues
const mem = api(T, 'members.save', { Name: 'Yusuf Khan', Phone: '9876543210', PlanID: 'PLN-DEFAULT', JoinDate: '2026-04-01' });
ok(mem.MemberNo === 'M0001', 'member no');
const g = api(T, 'schedule.generate', { Month: t.slice(0, 7) });
ok(g.created === 1, 'dues generated');
ok(api(T, 'schedule.generate', { Month: t.slice(0, 7) }).created === 0, 'dues idempotent');
const prev = vm.runInContext('addMonths_', C)(t.slice(0, 7), -1);
api(T, 'schedule.generate', { Month: prev });
const dues = api(T, 'schedule.memberDues', { MemberID: mem.MemberID });
ok(dues.length === 2, 'two open dues');
ok(/exceeds/.test(apiErr(T, 'collection.create', { MemberID: mem.MemberID, Amount: 500, AccountID: 'ACC-CASH', Date: t })), 'overpayment rejected');
const col = api(T, 'collection.create', { MemberID: mem.MemberID, Amount: 150, AccountID: 'ACC-CASH', Date: t, Mode: 'Cash' });
const d2 = api(T, 'schedule.memberDues', { MemberID: mem.MemberID });
ok(d2.length === 1 && d2[0].Status === 'Partial' && d2[0].PaidAmount === 50, 'FIFO allocation oldest first');

// --- users: treasurer + approver + collector
const tr = api(T, 'users.save', { Email: 'treasurer@gmail.com', Name: 'Treasurer', Role: 'TREASURER' });
let ts = login('treasurer@gmail.com', tr.tempPassword); api(ts.token, 'auth.changePassword', { oldPassword: tr.tempPassword, newPassword: 'Hk4wRt9sBn' });
const TT = ts.token;
const co = api(T, 'users.save', { Email: 'collector@gmail.com', Name: 'Coll', Role: 'COLLECTOR' });
let cs = login('collector@gmail.com', co.tempPassword); api(cs.token, 'auth.changePassword', { oldPassword: co.tempPassword, newPassword: 'Jp3yUe8dCv' });
const CT = cs.token;
ok(/permission/.test(apiErr(CT, 'expense.create', {})), 'collector cannot create expense');
ok(/permission/.test(apiErr(CT, 'report.run', { Report: 'trialBalance' })), 'collector cannot see reports');
ok(api(CT, 'dashboard').limited === true, 'collector limited dashboard');
api(CT, 'income.create', { Date: t, LedgerID: 'LED-D02', Amount: 1200, AccountID: 'ACC-CASH' });
ok(api(CT, 'vouchers.list', { Type: 'INCOME' }).length === 1, 'collector sees only own vouchers');
ok(/permission/.test(apiErr(TT, 'users.list', {})), 'treasurer cannot manage users');
ok(/permission/.test(apiErr(TT, 'voucher.cancel', {})), 'treasurer cannot cancel');

// --- expenses
ok(/bill/.test(apiErr(TT, 'expense.create', { Date: t, LedgerID: 'LED-D23', Amount: 1500, AccountID: 'ACC-CASH', PayeeName: 'TNEB', Narration: 'Power' })), 'bill required');
const e1 = api(TT, 'expense.create', { Date: t, LedgerID: 'LED-D23', Amount: 800, AccountID: 'ACC-CASH', PayeeName: 'TNEB', Narration: 'Power bill' });
ok(e1.pending === false && /^PV\//.test(e1.record.VoucherNo), 'small expense posted');
const pdf = { name: 'b.pdf', mimeType: 'application/pdf', data: Buffer.from('%PDF-1.4 hello').toString('base64') };
const e2 = api(TT, 'expense.create', { Date: t, LedgerID: 'LED-D20', Amount: 6000, AccountID: bank.AccountID, Mode: 'Bank Transfer', PayeeName: 'Imam', Narration: 'Salary', file: pdf });
ok(e2.pending === true && e2.record.VoucherNo === '', 'large expense pending');
ok(/does not match/.test(apiErr(TT, 'expense.create', { Date: t, LedgerID: 'LED-D20', Amount: 6000, AccountID: bank.AccountID, Mode: 'UPI', PayeeName: 'Imam', Narration: 'Salary', file: { mimeType: 'application/pdf', data: Buffer.from('MZ evil exe').toString('base64') } })), 'magic-number check');
const tAp = api(T, 'users.save', { Email: 'trustee@gmail.com', Name: 'Trustee', Role: 'APPROVER' });
let as = login('trustee@gmail.com', tAp.tempPassword); api(as.token, 'auth.changePassword', { oldPassword: tAp.tempPassword, newPassword: 'Km5zXa1fWq' });
const AT = as.token;
ok(/permission/.test(apiErr(TT, 'expense.decide', {})), 'treasurer cannot approve');
const pend = api(AT, 'approvals.list', {});
ok(pend.length === 1, 'one pending approval');
const dec = api(AT, 'expense.decide', { ApprovalID: pend[0].approval.ApprovalID, Decision: 'APPROVED' });
ok(dec.expense.Status === 'POSTED' && /^PV\/.*00002$/.test(dec.expense.VoucherNo), 'approved & posted ' + dec.expense.VoucherNo);
// maker-checker: admin enters and tries to approve own
const e3 = api(T, 'expense.create', { Date: t, LedgerID: 'LED-D25', Amount: 5000, AccountID: 'ACC-CASH', PayeeName: 'Mason', Narration: 'Wall repair', NoBillReason: 'Local labour paid in cash, no invoice' });
const p3 = api(T, 'approvals.list', {});
api(T, 'settings.save', { settings: { ADMIN_SELF_APPROVE: 'NO' } });
ok(/Maker-checker/.test(apiErr(T, 'expense.decide', { ApprovalID: p3[0].approval.ApprovalID, Decision: 'APPROVED' })), 'admin self-approval blocked when setting is NO');
api(T, 'settings.save', { settings: { ADMIN_SELF_APPROVE: 'YES' } });
const sa = api(T, 'expense.decide', { ApprovalID: p3[0].approval.ApprovalID, Decision: 'REJECTED', Remarks: 'Get quote' });
ok(/^\[Self-approved by Admin\]/.test(sa.approval.Remarks), 'admin can decide own voucher (default), clearly labelled');
ok(!(api(AT, 'dashboard').warnings || []).some(w => /same Admin who entered them/.test(w)), 'self-approval alert hidden on dashboards by default');
api(T, 'settings.save', { settings: { SELF_APPROVE_ALERT: 'YES' } });
ok((api(AT, 'dashboard').warnings || []).some(w => /same Admin who entered them/.test(w)), 'trustee dashboard shows self-approval alert when switched on');
api(T, 'settings.save', { settings: { SELF_APPROVE_ALERT: 'NO' } });
ok(api(T, 'audit.list', { Query: 'ADMIN_SELF_APPROVE' }).filter(x => x.Action === 'ADMIN_SELF_APPROVE').length === 1, 'admin self-approval in audit log');
// restricted fund
ok(/holds only/.test(apiErr(TT, 'expense.create', { Date: t, LedgerID: 'LED-D27', Amount: 3000, AccountID: bank.AccountID, Mode: 'UPI', PayeeName: 'Poor family', Narration: 'Zakat', file: pdf })), 'zakat overspend blocked');
api(TT, 'expense.create', { Date: t, LedgerID: 'LED-D27', Amount: 1500, AccountID: bank.AccountID, Mode: 'UPI', PayeeName: 'Poor family', Narration: 'Zakat', file: pdf });
// insufficient cash
ok(/Insufficient/.test(apiErr(TT, 'expense.create', { Date: t, LedgerID: 'LED-D33', Amount: 99999, AccountID: 'ACC-CASH', PayeeName: 'x', Narration: 'y', NoBillReason: 'testing the cash limit' }) || ''), 'insufficient cash blocked');

// --- contra & journal
const cv = api(TT, 'transfer.create', { Date: t, FromAccountID: 'ACC-CASH', ToAccountID: bank.AccountID, Amount: 3000, Mode: 'Cash' });
ok(/^CV\//.test(cv.record.VoucherNo), 'contra');
ok(/Insufficient/.test(apiErr(TT, 'transfer.create', { Date: t, FromAccountID: 'ACC-CASH', ToAccountID: bank.AccountID, Amount: 999999 })), 'contra overdraw blocked');
ok(/not balanced/.test(apiErr(TT, 'journal.create', { Date: t, Narration: 'x', Lines: [{ LedgerID: 'LED-D41', Debit: 100 }, { LedgerID: 'LED-D42', Credit: 90 }] })), 'unbalanced JV rejected');
ok(/cannot touch cash/.test(apiErr(TT, 'journal.create', { Date: t, Narration: 'x', Lines: [{ LedgerID: 'LED-D41', Debit: 100 }, { LedgerID: 'ACC-CASH', Credit: 100 }] })), 'JV touching cash rejected');
const jv = api(TT, 'journal.create', { Date: t, Narration: 'Advance adjusted against dues', Lines: [{ LedgerID: 'LED-D41', Debit: 500, Credit: 0 }, { LedgerID: 'LED-D42', Debit: 0, Credit: 500 }] });
ok(jv.pending && jv.record.VoucherNo === '', 'journal pending approval');
ok(/permission/.test(apiErr(TT, 'expense.decide', { ApprovalID: jv.record.ApprovalID, Decision: 'APPROVED' }) || ''), 'treasurer cannot approve JV');
const jvA = api(T, 'journal.create', { Date: t, Narration: 'Admin own journal', Lines: [{ LedgerID: 'LED-D41', Debit: 10 }, { LedgerID: 'LED-D42', Credit: 10 }] });
ok(/Self-approved by Admin/.test(api(T, 'expense.decide', { ApprovalID: jvA.record.ApprovalID, Decision: 'REJECTED', Remarks: 'not needed' }).approval.Remarks), 'admin can decide own JV (labelled)');
const jvd = api(AT, 'expense.decide', { ApprovalID: jv.record.ApprovalID, Decision: 'APPROVED' });
ok(/^JV\//.test(jvd.expense.VoucherNo), 'journal approved & posted');

// --- cancel
ok(/Insufficient/.test(apiErr(T, 'voucher.cancel', { Type: 'INCOME', ID: inc1.record.IncomeID, Reason: 'Entered twice' }) || ''), 'cancel that would make cash negative blocked');
api(T, 'income.create', { Date: t, LedgerID: 'LED-D03', Amount: 6000, AccountID: 'ACC-CASH', DonorName: 'Top-up' });
const cnl = api(T, 'voucher.cancel', { Type: 'INCOME', ID: inc1.record.IncomeID, Reason: 'Entered twice' });
ok(cnl.record.Status === 'CANCELLED', 'cancelled');
ok(/already/.test(apiErr(T, 'voucher.cancel', { Type: 'INCOME', ID: inc1.record.IncomeID, Reason: 'again!' })), 'double cancel blocked');
const colCancel = api(T, 'voucher.cancel', { Type: 'COLLECTION', ID: col.record.CollectionID, Reason: 'Wrong member' });
ok(api(T, 'schedule.memberDues', { MemberID: mem.MemberID }).length === 2, 'collection cancel restores dues');

// --- reports
const R = r => api(T, 'report.run', r);
const last = rows => rows[rows.length - 1].c;
const tb = R({ Report: 'trialBalance' });
ok(!tb.warning && last(tb.sections[0].rows)[1] === last(tb.sections[0].rows)[2], 'trial balance tallies ' + JSON.stringify(last(tb.sections[0].rows)));
const bs = R({ Report: 'balanceSheet' });
ok(!bs.warning, 'balance sheet tallies ' + (bs.warning || ''));
const rp = R({ Report: 'receiptsPayments' });
ok(!rp.warning, 'R&P tallies ' + (rp.warning || ''));
const ie = R({ Report: 'incomeExpenditure' });
const surplus = last(ie.sections[2].rows)[1];
// income: zakat 2000 + jumuah 1200 = 3200 ; exp: 800 + 6000 + 1500 = 8300 → deficit 5100
ok(surplus === 900 && /Surplus/.test(last(ie.sections[2].rows)[0]), 'I&E surplus 900 got ' + surplus);
const cashBook = R({ Report: 'ledger', LedgerID: 'ACC-CASH' });
// cash: +5000(cancelled) +1200 -800 -3000 -500 = -3100 ?? -> check value
const cb = last(cashBook.sections[0].rows)[6];
ok(!/Cr/.test(cb), 'cash never negative: ' + cb);
const fundsR = R({ Report: 'funds' });
const zrow = fundsR.sections[0].rows.find(r => r.c[0] === 'Zakat Fund');
ok(zrow.c[5] === 500, 'zakat fund closing 500 got ' + zrow.c[5]);
ok(R({ Report: 'dayBook' }).sections[0].rows.length > 5, 'day book');
ok(R({ Report: 'outstanding' }).sections[0].rows.length === 2, 'outstanding');
ok(R({ Report: 'memberStatement', MemberID: mem.MemberID }).sections.length === 2, 'member statement');
api(T, 'budgets.save', { FY: B.fy, LedgerID: 'LED-D20', Amount: 72000 });
ok(R({ Report: 'budget' }).sections[1].rows.some(r => r.c[0] === 'Imam Salary' && r.c[1] === 72000), 'budget vs actual');
const brs = R({ Report: 'brs', LedgerID: bank.AccountID });
ok(brs.items.length >= 3, 'brs items ' + brs.items.length);
api(TT, 'brs.clear', { EntryIDs: brs.items.map(i => i.EntryID), ClearedDate: t });
ok(R({ Report: 'brs', LedgerID: bank.AccountID }).items.length === 0, 'brs cleared');
const pdfR = api(T, 'report.pdf', { Report: 'trialBalance' });
ok(pdfR.mimeType === 'application/pdf', 'report pdf');

// --- receipts, files, dashboard, system
const rc = api(T, 'receipt.pdf', { ReceiptID: zak.receipt.ReceiptID });
ok(rc.data.length > 0, 'receipt pdf');
ok(api(T, 'file.get', { FileID: e2.record.BillFileID }).mimeType === 'application/pdf', 'file get');
const backupFolderFile = api(T, 'system.backup', {});
ok(/Access denied|not found/.test(apiErr(T, 'file.get', { FileID: backupFolderFile.id })), 'backup files not served via file.get');
const dsh = api(T, 'dashboard');
ok(dsh.accounts.length === 2 && dsh.pendingApprovals === 0, 'dashboard');
const sys = api(T, 'system.status');
ok(sys.cells.pct >= 0 && Array.isArray(sys.warnings), 'system status');
ok(api(T, 'audit.list', {}).length > 20, 'audit log populated');
ok(/Books are locked/.test((api(T, 'settings.save', { settings: { LOCK_DATE: vm.runInContext('addDays_', C)(t, -1) } }), apiErr(T, 'income.create', { Date: vm.runInContext('addDays_', C)(t, -1), LedgerID: 'LED-D03', Amount: 5, AccountID: 'ACC-CASH' }))), 'lock date enforced');
ok(/back|locked/.test(apiErr(TT, 'income.create', { Date: '2026-04-02', LedgerID: 'LED-D03', Amount: 5, AccountID: 'ACC-CASH' }) || ''), 'backdate/lock limit for non-admin');
// lockout
for (let i = 0; i < 5; i++) { try { login('collector@gmail.com', 'bad'); } catch (e) { } }
ok(/Sign-in failed/.test((() => { try { login('collector@gmail.com', 'Jp3yUe8dCv'); } catch (e) { return e.message; } })()), 'sign-in paused after 5 failures');
// disable user kills session
api(T, 'users.save', { UserID: as.user.id, Email: 'trustee@gmail.com', Name: 'Trustee', Role: 'APPROVER', Status: 'Disabled' });
ok(/AUTH/.test(apiErr(AT, 'dashboard')), 'disabled user session revoked');
ok(/own Admin/.test(apiErr(T, 'users.save', { UserID: s.user.id, Email: OWNER, Name: 'A', Role: 'TREASURER' })), 'cannot demote self');
// triggers
ok(/Refused/.test(C.dailyBackupTrigger()), 'backup trigger refuses browser calls');
ok(/Refused/.test(C.monthlyDuesTrigger({ triggerUid: '999' })), 'fake trigger id refused');
const uid = C._.triggers.find(x => x.getHandlerFunction() === 'monthlyDuesTrigger').getUniqueId();
reset(); ok(/dues created/.test(C.monthlyDuesTrigger({ triggerUid: uid })), 'monthly trigger runs from real trigger');
reset(); ok(/Skipped/.test(C.dailyBackupTrigger({ triggerUid: C._.triggers[0].getUniqueId() })), 'backup trigger 20h guard');
// Sheet I/O efficiency
console.log('  sheet reads/writes:', ss.reads, ss.writes);
console.log(`\n${pass} passed, ${failN} failed`);
process.exit(failN ? 1 : 0);
