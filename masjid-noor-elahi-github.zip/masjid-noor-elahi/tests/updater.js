// Tests Updater.gs flow with mocked Google services.
const fs = require('fs'), vm = require('vm');
let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : (fail++, console.log('  ✗ FAIL: ' + m)); };
function mk(active) {
  const calls = [], props = { WEBSITE_SCRIPT_ID: 'SITE_abcdefghijklmnopqrstuvwxyz' };
  const files = {};
  const ctx = {
    Session: { getEffectiveUser: () => ({ getEmail: () => 'owner@gmail.com' }), getActiveUser: () => ({ getEmail: () => active }), getScriptTimeZone: () => 'Asia/Kolkata' },
    PropertiesService: { getScriptProperties: () => ({ getProperty: k => props[k] || null }) },
    ScriptApp: { getScriptId: () => 'APP_abcdefghijklmnopqrstuvwxyz', getOAuthToken: () => 'tok' },
    DriveApp: { getFilesByName: n => { const a = files[n] ? [files[n]] : []; let i = 0; return { hasNext: () => i < a.length, next: () => a[i++] }; } },
    Utilities: { formatDate: () => '2026-11-20 23:00' }, Logger: { log: () => { } },
    UrlFetchApp: { fetch: (u, o) => { calls.push([o.method, u, o.payload]); const body = /\/versions$/.test(u) ? { versionNumber: 7 } : /\/deployments$/.test(u) && o.method === 'get' ? { deployments: [{ deploymentId: 'HEAD1', deploymentConfig: {} }, { deploymentId: 'D1', deploymentConfig: { versionNumber: 3, description: 'web' } }] } : {};
      return { getResponseCode: () => 200, getContentText: () => JSON.stringify(body) }; } }
  };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(require('path').join(process.argv[2] || '..', 'Auth.gs'), 'utf8').match(/function assertOwner_[\s\S]*?\n}\n/)[0], ctx);
  vm.runInContext(fs.readFileSync(require('path').join(process.argv[2] || '..', 'Updater.gs'), 'utf8'), ctx);
  const file = (o) => ({ isTrashed: () => false, getOwner: () => ({ getEmail: () => 'owner@gmail.com' }), getLastUpdated: () => new Date(), getBlob: () => ({ getDataAsString: () => JSON.stringify(o) }) });
  return { ctx, calls, files, file, props };
}
const man = { name: 'appsscript', type: 'JSON', source: '{}' };
{ const t = mk('owner@gmail.com');
  t.files['masjid-committee-app.json'] = t.file({ kind: 'committee', version: '1.4.0', files: [man, { name: 'Code', type: 'SERVER_JS', source: 'x' }] });
  t.files['masjid-website.json'] = t.file({ kind: 'website', version: '1.4.0', files: [man, { name: 'Public', type: 'SERVER_JS', source: 'y' }] });
  const r = t.ctx.updateEverything();
  ok(/Website updated/.test(r) && /Committee app updated/.test(r), 'updateEverything updates both: ' + r);
  ok(t.calls.some(c => c[0] === 'put' && /SITE_\w+\/content$/.test(c[1])) && t.calls.some(c => c[0] === 'put' && /APP_\w+\/content$/.test(c[1])), 'content pushed to both projects');
  ok(t.calls.filter(c => /deployments\/D1$/.test(c[1])).length === 2 && !t.calls.some(c => /HEAD1/.test(c[1])), 'only versioned deployments moved (HEAD untouched)');
  ok(JSON.parse(t.calls.find(c => /deployments\/D1$/.test(c[1]))[2]).deploymentConfig.versionNumber === 7, 'deployment points to new version');
}
{ const t = mk('owner@gmail.com');
  t.files['masjid-website.json'] = t.file({ kind: 'committee', files: [man] });
  let e = ''; try { t.ctx.updateWebsite(); } catch (x) { e = x.message; } ok(/not a website update/.test(e), 'wrong bundle kind refused');
  t.files['masjid-website.json'] = t.file({ kind: 'website', files: [{ name: '../evil', type: 'SERVER_JS', source: '' }, man] });
  e = ''; try { t.ctx.updateWebsite(); } catch (x) { e = x.message; } ok(/Bad file entry/.test(e), 'bad file name refused');
  t.files['masjid-website.json'] = t.file({ kind: 'website', files: [{ name: 'Public', type: 'SERVER_JS', source: '' }] });
  e = ''; try { t.ctx.updateWebsite(); } catch (x) { e = x.message; } ok(/no manifest/.test(e), 'bundle without manifest refused');
  ok(t.calls.length === 0, 'nothing sent when bundle invalid');
}
for (const who of ['', 'visitor@gmail.com']) { const t = mk(who);
  t.files['masjid-committee-app.json'] = t.file({ kind: 'committee', files: [man] });
  let e = ''; try { t.ctx.updateCommitteeApp(); } catch (x) { e = x.message; }
  ok(/only be run by the script owner/.test(e) && t.calls.length === 0, 'web visitor (' + (who || 'anonymous') + ') cannot run updater'); }
console.log(`UPDATER: ${pass} passed, ${fail} failed`);
