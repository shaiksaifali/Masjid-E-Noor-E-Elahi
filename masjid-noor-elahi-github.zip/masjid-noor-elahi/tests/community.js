// Community website tests (private-app side + public website project). Run: node tests/community.js .
const { makeCtx, store } = require('./mock');
const vm = require('vm'), fs = require('fs'), path = require('path');
const DIR = path.resolve(process.argv[2] || '.');
const OWNER = 'owner@gmail.com';
const C = makeCtx(OWNER, DIR);
const reset = () => vm.runInContext('_memo = { t: {}, h: {}, idx: {} };', C);
let pass = 0, failN = 0;
const ok = (c, m) => { if (c) pass++; else { failN++; console.log('  ✗', m); } };
const api = (tok, a, p) => { reset(); return C.api(tok, a, p).data; };
const err = (tok, a, p) => { reset(); try { C.api(tok, a, p); return ''; } catch (e) { return e.message; } };
const login = (e, pw) => { reset(); return C.apiLogin(e, pw); };

const pw0 = /Password: (\S+)/.exec(C.setup())[1];
const A = login(OWNER, pw0).token; api(A, 'auth.changePassword', { oldPassword: pw0, newPassword: 'Gq7vLm2pXz' });
const cu = api(A, 'users.save', { Email: 'imam@gmail.com', Name: 'Imam', Role: 'COMMUNITY' });
let s = login('imam@gmail.com', cu.tempPassword); api(s.token, 'auth.changePassword', { oldPassword: cu.tempPassword, newPassword: 'Rn4kPw8zQs' });
const M = s.token;
const t = api(A, 'bootstrap').today;

console.log('— Community Manager role is cut off from finance');
const bm = api(M, 'bootstrap');
ok(!bm.ledgers && !bm.accounts && !bm.members && bm.community === true, 'bootstrap has no financial data');
['dashboard', 'members.list', 'report.run', 'vouchers.list', 'receipts.list', 'users.list', 'audit.list'].forEach(a =>
  ok(/permission/.test(err(M, a, { Report: 'trialBalance', Type: 'INCOME' })), 'community manager denied ' + a));
ok(/permission/.test(err(M, 'income.create', {})), 'community manager cannot record money');
ok(/You cannot change/.test(err(M, 'community.settings', { settings: { APPROVAL_THRESHOLD: '1' } })), 'cannot change finance settings via community settings');

console.log('— Website settings validation');
ok(/only https links/.test(err(M, 'community.settings', { settings: { MAPS_LINK: 'javascript:alert(1)' } })), 'javascript: link rejected');
ok(/only https links/.test(err(M, 'community.settings', { settings: { WHATSAPP_LINK: 'https://evil.example.com/x' } })), 'unknown host rejected');
ok(/valid UPI/.test(err(M, 'community.settings', { settings: { UPI_ID: 'x<script>@bank' } })), 'bad UPI rejected');
ok(/out of range/.test(err(M, 'community.settings', { settings: { LATITUDE: '123.4' } })), 'bad latitude rejected');
api(M, 'community.settings', { settings: { LATITUDE: '17.385044', LONGITUDE: '78.486671', MAPS_LINK: 'https://maps.app.goo.gl/abcd', UPI_ID: 'noorelahi@sbi',
  WHATSAPP_LINK: 'https://chat.whatsapp.com/AbCdEf', JUMUAH_KHUTBAH_TIME: '13:15', JUMUAH_JAMAAT_TIME: '13:30', ABOUT_TEXT: 'Line 1\nLine 2', FORMS_ENABLED: 'YES' } });
ok(api(M, 'bootstrap').settings.LATITUDE === '17.385044', 'location saved');

console.log('— Jamaat rules, notices, events, programmes, Janazah');
api(M, 'community.jamaat', { Prayer: 'Fajr', Mode: 'FIXED', Time: '05:45', EffectiveFrom: t });
api(M, 'community.jamaat', { Prayer: 'Maghrib', Mode: 'OFFSET', OffsetMin: 5, EffectiveFrom: t });
api(M, 'community.jamaat', { Prayer: 'Fajr', Mode: 'FIXED', Time: '06:00', EffectiveFrom: vm.runInContext('addDays_', C)(t, 7) });
reset();
ok(C.jamaatFor_('Fajr', t) === 345, 'fixed Fajr jamaat 05:45 today');
reset(); ok(C.jamaatFor_('Fajr', vm.runInContext('addDays_', C)(t, 8)) === 360, 'future rule 06:00 applies from its date');
reset(); const az = C.azanFor_(t); reset(); ok(C.jamaatFor_('Maghrib', t) === az.maghrib + 5, 'Maghrib = sunset + 5 min');
const te = err(M, 'community.jamaat', { Prayer: 'Asr', Mode: 'FIXED', Time: '25:99' }); ok(/24-hour/.test(te), 'invalid time rejected: ' + te);
const XSS = '<img src=x onerror="window.__xss=1">';
const an = api(M, 'community.announce', { Title: 'Jamaat time change ' + XSS, TitleUr: 'جماعت کا وقت', Body: 'From Monday Fajr at 6:00', Priority: 'Important', StartDate: t });
const ev = api(M, 'community.event', { Category: 'Ijtema', Title: 'Ijtema ' + XSS, TitleUr: 'اجتماع', Date: vm.runInContext('addDays_', C)(t, 10), StartTime: '10:00', EndTime: '13:00', Venue: 'Main hall' });
ok(!!ev.record.CalendarEventID && !ev.warning, 'event added to Google Calendar');
const pg = api(M, 'community.program', { Category: 'Gasht', Title: 'Gasht', TitleUr: 'گشت', Days: 'Thu', TimeMode: 'AFTER', AfterPrayer: 'Asr', Venue: 'Masjid' });
ok(/^S:/.test(pg.record.CalendarEventID), 'weekly programme added as recurring series');
api(M, 'community.program', { Category: 'Taleem', Title: 'Taleem', Days: 'Daily', TimeMode: 'AFTER', AfterPrayer: 'Fajr' });
ok(/Choose at least one day/.test(err(M, 'community.program', { Title: 'x', Days: '', TimeMode: 'AFTER', AfterPrayer: 'Asr' })), 'programme needs days');
const jz = api(M, 'community.janazah', { DeceasedName: 'Haji Abdul Rahman', DeceasedNameUr: 'حاجی عبدالرحمن', Date: t, TimeMode: 'AFTER', AfterPrayer: 'Zuhr', Venue: 'Masjid', BurialPlace: 'Main Qabristan' });
ok(!!jz.record.CalendarEventID, 'Janazah added to calendar');
const cal = Object.values(C.CalendarApp._cals)[0];
const aliveBefore = Object.values(cal.evs).filter(e => e.alive).length;
api(M, 'community.event', Object.assign({}, ev.record, { Status: 'Inactive' }));
ok(Object.values(cal.evs).filter(e => e.alive).length === aliveBefore - 1, 'hiding an event removes it from the calendar');
api(M, 'community.event', Object.assign({}, ev.record, { Status: 'Active' }));
ok(Object.values(cal.evs).some(e => e.alive && /Jumu'ah/.test(e.title)), 'Jumu\'ah weekly series created');

console.log('— Ramadan');
ok(/first Roza/.test(err(M, 'community.ramadanSync', {})), 'ramadan sync needs start date');
api(M, 'community.settings', { settings: { RAMADAN_START: '2027-02-08', RAMADAN_DAYS: '30', EID_FITR_DATE: '2027-03-10', EID_FITR_TIME: '08:30', EID_VENUE: 'Eidgah' } });
const rs = api(M, 'community.ramadanSync', {});
ok(rs.events === 61, 'Sehri + Iftar for 30 days + Eid = 61 calendar events: ' + rs.events);
const rs2 = api(M, 'community.ramadanSync', {});
ok(Object.values(cal.evs).filter(e => e.alive && /Sehri ends/.test(e.title)).length === 30, 're-running replaces (no duplicates)');
ok(/permission/.test(err(M, 'community.calendarPublic', {})), 'only Admin can make calendar public');
ok(api(A, 'community.calendarPublic', {}).isPublic === true, 'Admin makes calendar public');

console.log('— Published snapshot (what the public can see)');
const pubId = C._.props.PUBLIC_SS_ID, pub = store.ss[pubId];
const snapTxt = pub.getSheetByName('Snapshot').data.map(r => r[0]).join('');
const snap = JSON.parse(snapTxt);
ok(snap.masjid.name === 'Masjid-E-Noor-Elahi' && snap.calc.lat === 17.385044 && snap.calc.asrFactor === 2, 'snapshot has masjid & Hanafi Karachi settings');
ok(snap.events.length === 1 && snap.programs.length === 2 && snap.janazah.length === 1 && snap.announcements.length === 1 && snap.jamaat.length === 3, 'snapshot content counts');
ok(snap.calendar.isPublic === true && /calendar\.google\.com/.test(snap.calendar.subscribeUrl), 'snapshot has subscribe link');
const forbidden = ['PasswordHash', 'Salt', 'Amount', 'LedgerID', 'AccountID', 'MemberID', 'CreatedBy', 'CalendarEventID', 'owner@gmail.com', 'imam@gmail.com', 'APPROVAL_THRESHOLD'];
ok(forbidden.every(k => snapTxt.indexOf(k) < 0), 'snapshot contains no private/financial fields: ' + forbidden.filter(k => snapTxt.indexOf(k) >= 0));

console.log('— Public website project (bound, currentonly)');
const pubDir = fs.existsSync(path.join(DIR, 'community')) ? path.join(DIR, 'community') : path.join(DIR, '..', 'community-website');
const src = fs.readdirSync(pubDir).filter(f => f.endsWith('.gs')).map(f => fs.readFileSync(path.join(pubDir, f), 'utf8')).join('\n');
ok(!/openById|openByUrl|DriveApp|MailApp|GmailApp|UrlFetchApp|CalendarApp|PropertiesService/.test(src), 'public code never opens other files or services');
const man = JSON.parse(fs.readFileSync(path.join(pubDir, 'appsscript.json'), 'utf8'));
ok(man.oauthScopes.length === 1 && man.oauthScopes[0] === 'https://www.googleapis.com/auth/spreadsheets.currentonly', 'public project scope is currentonly');
ok(fs.readFileSync(path.join(pubDir, 'PrayerCalcJs.html'), 'utf8') === fs.readFileSync(path.join(DIR, 'PrayerCalcJs.html'), 'utf8') &&
   fs.readFileSync(path.join(DIR, 'PrayerCalcJs.html'), 'utf8').includes(fs.readFileSync(path.join(DIR, 'PrayerCalc.gs'), 'utf8')), 'website and calendar use identical prayer-time code');
const P = makeCtx(OWNER, pubDir, () => ({
  SpreadsheetApp: { getActiveSpreadsheet: () => pub, openById: () => { throw new Error('not allowed'); }, flush: () => { } },
  HtmlService: { createTemplateFromFile: () => ({ evaluate() { this.out = this.snapJson; return { setTitle() { return this; }, addMetaTag() { return this; }, setXFrameOptionsMode() { return this; }, _t: this }; } }),
    XFrameOptionsMode: { DEFAULT: 1 }, createHtmlOutputFromFile: () => ({ getContent: () => '' }) }
}));
const pageObj = P.doGet({ parameter: { lang: 'ur', page: 'ramadan' } });
const embedded = pageObj._t.snapJson;
ok(!/<img|<\/script/i.test(embedded) && /\\u003cimg/.test(embedded), 'snapshot embedded in page with < > escaped (no script break-out)');
ok(JSON.parse(pageObj._t.initJson).lang === 'ur', 'language from URL');
ok(JSON.parse(P.doGet({ parameter: { page: '"><script>' } })._t.initJson).page === 'home', 'bad page parameter ignored');
ok(P.getSnapshot().masjid.name === 'Masjid-E-Noor-Elahi', 'public getSnapshot works');
const perr = f => { try { P.submitRequest(f); return ''; } catch (e) { return e.message; } };
const good = { type: 'Nikah', name: 'Ahmed Khan', phone: '9876543210', date: vm.runInContext('addDays_', C)(t, 30), message: 'Nikah on Friday after Asr', t: 9000 };
ok(P.submitRequest(good).ok, 'valid request accepted');
ok(P.submitRequest(Object.assign({}, good, { website: 'http://spam' })).ok && pub.getSheetByName('Requests').getLastRow() === 2, 'honeypot request silently dropped');
ok(/take a moment/.test(perr(Object.assign({}, good, { t: 500 }))), 'too-fast bot submission rejected');
ok(/valid phone/.test(perr(Object.assign({}, good, { phone: 'abc' }))), 'bad phone rejected');
ok(/past/.test(perr(Object.assign({}, good, { date: '2020-01-01' }))), 'past date rejected');
ok(/Choose a request type/.test(perr(Object.assign({}, good, { type: 'Hack' }))), 'unknown type rejected');
ok(/invalid/.test(perr(Object.assign({}, good, { name: { toString: 1 } }))), 'object injection rejected');
P.submitRequest(Object.assign({}, good, { message: '=HYPERLINK("http://evil","click")', type: 'Query / suggestion' }));
const rows = pub.getSheetByName('Requests').data;
ok(String(rows[rows.length - 1][6]).startsWith("'="), 'formula in message neutralised');
ok(P.submitRequest(Object.assign({}, good, { type: 'Volunteer' })).ok, '3rd request from same phone allowed');
ok(/already received/.test(perr(Object.assign({}, good, { type: 'Other', message: 'x' }))), 'max 3 requests per phone per day');
for (let i = 0; i < 40; i++) { try { P.submitRequest(Object.assign({}, good, { phone: '91000000' + String(i).padStart(2, '0') })); } catch (e) { } }
ok(/Many requests/.test(perr(Object.assign({}, good, { phone: '9988776655' }))), 'hourly flood limit');
api(M, 'community.settings', { settings: { FORMS_ENABLED: 'NO' } });
P._.cache && Object.keys(P._.cache).forEach(k => delete P._.cache[k]);
ok(/not accepting/.test(perr(Object.assign({}, good, { phone: '9123456789' }))), 'requests closed when disabled');

console.log('— Committee login button');
const APPURL = 'https://script.google.com/macros/s/AKfycbxTestDeployment123/exec';
ok(/only https links/.test(err(M, 'community.settings', { settings: { ADMIN_APP_URL: 'https://evil.example.com/exec' } })), 'fake login URL rejected');
api(M, 'community.settings', { settings: { ADMIN_APP_URL: APPURL } });
const snapL = () => JSON.parse(store.ss[C._.props.PUBLIC_SS_ID].getSheetByName('Snapshot').data.map(r => r[0]).join(''));
ok(snapL().masjid.appUrl === APPURL, 'website gets the committee login link');
api(M, 'community.settings', { settings: { SHOW_COMMITTEE_LOGIN: 'NO' } });
ok(snapL().masjid.appUrl === '', 'login button can be hidden');
api(M, 'community.settings', { settings: { SHOW_COMMITTEE_LOGIN: 'YES', ADMIN_APP_URL: '' } });
ok(snapL().masjid.appUrl === '', 'no URL configured or detectable → no button (never a wrong link)');
api(M, 'community.settings', { settings: { ADMIN_APP_URL: APPURL } });

console.log('— Wudu & Salah guide content');
const gsrc = fs.readFileSync(path.join(pubDir, 'PublicGuide.html'), 'utf8').replace(/<\/?script>/g, '');
const G = new Function(gsrc + '; return GUIDE;')();
const totals = {}; G.rakats.forEach(r => totals[r.p] = r.parts.reduce((a, x) => a + x[1], 0));
ok(JSON.stringify(totals) === JSON.stringify({ Fajr: 4, Zuhr: 12, Asr: 8, Maghrib: 7, Isha: 17, Jumuah: 14 }), 'Hanafi rakat totals: ' + JSON.stringify(totals));
ok(G.rakats.every(r => r.parts.filter(x => x[0] === 'F').reduce((a, x) => a + x[1], 0) === { Fajr: 2, Zuhr: 4, Asr: 4, Maghrib: 3, Isha: 4, Jumuah: 2 }[r.p]), 'Fard rakats correct');
ok(G.wudu.length === 9 && G.wudu.every(w => w.en && w.ur) && G.duas.every(d => d.ar && d.tr && d.en && d.t.en && d.t.ur), 'every Wudu step and dua has Arabic text, Roman reading, English and an Arabic title');
const DD = new Function(fs.readFileSync(path.join(pubDir, 'PublicDaily.html'), 'utf8').replace(/<\/?script>/g, '') + '; return DAILY;')();
ok(DD.hadith.length >= 30 && DD.hadith.every(h => h.ar && h.tr && h.hy && h.en && ['bukhari', 'muslim', 'tirmidhi'].includes(h.b) && h.n > 0), 'every hadith has Arabic, Roman reading, Hyderabadi + English meaning and a reference');
ok(DD.verses.length === 40 && DD.verses.every(v => v.ar && v.tr && v.hy && v.en), 'every daily ayah has Arabic, Roman reading, Hyderabadi + English');
ok(DD.duas.every(g => g.ur && g.items.every(d => d.t.ur && d.hy && d.en && d.ref && (d.ar || d.quran || d.tr === ''))), 'every daily dua has Arabic title, meanings and reference');
ok(DD.chapters.length === 114, '114 surahs listed');

console.log('— Requests inbox in the private app');
const inbox = api(M, 'community.requests', { Status: 'New' });
ok(inbox.length >= 3 && inbox[0].Phone, 'committee sees requests with phone');
api(M, 'community.requestUpdate', { ReqID: inbox[0].ReqID, Status: 'Done', Note: 'Called back' });
ok(api(M, 'community.requests', { Status: 'Done' }).length === 1, 'request marked done');
ok(/permission/.test(err(api(A, 'bootstrap') && login('owner@gmail.com', 'Gq7vLm2pXz').token, 'community.requests', {})) === false, 'admin can read requests');
console.log(`\nCOMMUNITY: ${pass} passed, ${failN} failed`);
process.exit(failN ? 1 : 0);
