// Minimal in-memory mock of Google Apps Script services for local testing.
const crypto = require('crypto');
const fs = require('fs');
const vm = require('vm');

function toSigned(buf) { return Array.from(buf).map(b => (b > 127 ? b - 256 : b)); }
function toBuf(arr) { return Buffer.from(arr.map(b => b & 0xff)); }

let idc = 0; const nid = p => p + '_' + (++idc).toString(36) + 'xxxxxxxxxx';

class Range {
  constructor(sh, r, c, nr, nc) { this.sh = sh; this.r = r; this.c = c; this.nr = nr; this.nc = nc; }
  getValues() {
    if (this.r + this.nr - 1 > this.sh.maxRows || this.c + this.nc - 1 > this.sh.maxCols) throw new Error('Range out of bounds (get)');
    const out = []; for (let i = 0; i < this.nr; i++) { const row = []; for (let j = 0; j < this.nc; j++) { const v = (this.sh.data[this.r - 1 + i] || [])[this.c - 1 + j]; row.push(v === undefined ? '' : v); } out.push(row); } return out;
  }
  setValues(v) {
    if (v.length !== this.nr || v.some(r => r.length !== this.nc)) throw new Error('setValues dimension mismatch ' + v.length + 'x' + v[0].length + ' vs ' + this.nr + 'x' + this.nc);
    if (this.r + this.nr - 1 > this.sh.maxRows || this.c + this.nc - 1 > this.sh.maxCols) throw new Error('Range out of bounds (set) ' + (this.r + this.nr - 1) + '>' + this.sh.maxRows);
    this.sh.ss.writes++;
    for (let i = 0; i < this.nr; i++) { const ri = this.r - 1 + i; this.sh.data[ri] = this.sh.data[ri] || []; for (let j = 0; j < this.nc; j++) {
      let x = v[i][j];
      if (typeof x === 'string' && x !== '' && !isNaN(Number(x)) && this.sh.textCols && !this.sh.textCols.has(this.c + j)) x = Number(x);
      this.sh.data[ri][this.c - 1 + j] = x; } }
    return this;
  }
  setNumberFormats(a) { return this; }
  setValue(v) { return this.setValues([[v]]); }
  setNumberFormat(f) { if (f === '@') { this.sh.textCols = this.sh.textCols || new Set(); this.sh.textCols.add(this.c); } return this; }
  setFontWeight() { return this; } setBackground() { return this; } setFontColor() { return this; }
}
class Sheet {
  constructor(ss, name) { this.ss = ss; this.name = name; this.data = []; this.maxRows = 1000; this.maxCols = 26; this.textCols = new Set(); }
  getName() { return this.name; }
  getLastRow() { let n = 0; this.data.forEach((r, i) => { if (r && r.some(v => v !== '' && v !== undefined)) n = i + 1; }); return n; }
  getLastColumn() { let n = 0; this.data.forEach(r => { if (r) r.forEach((v, j) => { if (v !== '' && v !== undefined) n = Math.max(n, j + 1); }); }); return n; }
  getMaxRows() { return this.maxRows; } getMaxColumns() { return this.maxCols; }
  getRange(r, c, nr, nc) { this.ss.reads++; return new Range(this, r, c, nr || 1, nc || 1); }
  insertRowsAfter(after, n) { this.maxRows += n; } insertColumnsAfter(a, n) { this.maxCols += n; }
  deleteColumns(s, n) { this.maxCols -= n; } deleteRows(s, n) { this.maxRows -= n; }
  setFrozenRows() { }
}
class SS {
  constructor(name) { this.id = nid('ss'); this.name = name; this.sheets = [new Sheet(this, 'Sheet1')]; this.reads = 0; this.writes = 0; }
  getId() { return this.id; } getUrl() { return 'https://docs.google.com/spreadsheets/d/' + this.id; }
  getSheetByName(n) { return this.sheets.find(s => s.name === n) || null; }
  insertSheet(n) { const s = new Sheet(this, n); this.sheets.push(s); return s; }
  getSheets() { return this.sheets; } deleteSheet(s) { this.sheets = this.sheets.filter(x => x !== s); }
  setSpreadsheetTimeZone() { }
}
const store = { ss: {}, files: {}, folders: {} };
class Blob {
  constructor(data, mime, name) { this.bytes = typeof data === 'string' ? toSigned(Buffer.from(data, 'utf8')) : data; this.mime = mime; this.name = name; }
  getBytes() { return this.bytes; } getContentType() { return this.mime; }
  getAs(m) { return new Blob(toSigned(Buffer.from('%PDF-1.4 mock ' + Buffer.from(toBuf(this.bytes)).toString('utf8').length)), m, this.name); }
  setName(n) { this.name = n; return this; } getName() { return this.name; }
  getDataAsString() { return toBuf(this.bytes).toString('latin1'); }
}
class File {
  constructor(blob, parent) { this.id = nid('file'); this.blob = blob; this.parents = [parent]; this.created = new Date(); this.trashed = false; store.files[this.id] = this; }
  getId() { return this.id; } getName() { return this.blob.name; } getBlob() { return this.blob; }
  getParents() { const p = this.parents.slice(); return { hasNext: () => p.length > 0, next: () => p.shift() }; }
  makeCopy(name, folder) { const f = new File(new Blob(['copy'], 'x', name), folder); return f; }
  moveTo(folder) { this.parents = [folder]; } setTrashed(t) { this.trashed = t; } getDateCreated() { return this.created; } getUrl() { return 'https://drive/' + this.id; }
}
class Folder {
  constructor(name) { this.id = nid('fld'); this.name = name; store.folders[this.id] = this; }
  getId() { return this.id; } getUrl() { return 'https://drive/folder/' + this.id; }
  createFolder(n) { return new Folder(n); }
  createFile(blob) { return new File(blob, this); }
  getFiles() { const fs = Object.values(store.files).filter(f => !f.trashed && f.parents.includes(this)); return { hasNext: () => fs.length > 0, next: () => fs.shift() }; }
}
function fmt(d, tz, f) {
  const t = new Date(d.getTime() + 330 * 60000), p = n => String(n).padStart(2, '0');
  const Y = t.getUTCFullYear(), M = p(t.getUTCMonth() + 1), D = p(t.getUTCDate()), h = p(t.getUTCHours()), m = p(t.getUTCMinutes()), s = p(t.getUTCSeconds());
  return f.replace('yyyy', Y).replace('MM', M).replace('dd', D).replace('HH', h).replace('mm', m).replace('ss', s);
}
function makeCtx(ownerEmail, dirOverride, extra) {
  const props = {}, cache = {}, logs = [], triggers = [], mails = [];
  let activeUser = ownerEmail;
  const ctx = {
    console, JSON, Math, Date, Object, Array, String, Number, isFinite, isNaN, parseInt, parseFloat, Error, RegExp,
    Logger: { log: m => logs.push(String(m)) },
    Session: { getScriptTimeZone: () => 'Asia/Kolkata', getEffectiveUser: () => ({ getEmail: () => ownerEmail }), getActiveUser: () => ({ getEmail: () => activeUser }) },
    PropertiesService: { getScriptProperties: () => ({ getProperty: k => (k in props ? props[k] : null), setProperty: (k, v) => { props[k] = String(v); }, setProperties: o => Object.assign(props, o), getProperties: () => Object.assign({}, props), deleteProperty: k => { delete props[k]; } }) },
    CacheService: { getScriptCache: () => ({ get: k => (k in cache ? cache[k] : null), put: (k, v) => { if (v.length > 100000) throw new Error('too big'); cache[k] = v; }, remove: k => { delete cache[k]; }, removeAll: ks => ks.forEach(k => delete cache[k]), getAll: ks => { const o = {}; ks.forEach(k => { if (k in cache) o[k] = cache[k]; }); return o; }, putAll: (o) => { Object.keys(o).forEach(k => { if (String(o[k]).length > 100000) throw new Error('too big'); cache[k] = String(o[k]); }); } }) },
    LockService: { getScriptLock: () => ({ tryLock: () => true, waitLock: () => { }, releaseLock: () => { } }) },
    SpreadsheetApp: { openById: id => { if (!store.ss[id]) throw new Error('no ss'); return store.ss[id]; }, create: n => { const s = new SS(n); store.ss[s.id] = s; return s; }, flush: () => { } },
    DriveApp: {
      createFolder: n => new Folder(n), getFolderById: id => { if (!store.folders[id]) throw new Error('no folder'); return store.folders[id]; },
      getFileById: id => { if (store.ss[id]) return { makeCopy: (n, f) => new File(new Blob('copy', 'x', n), f), moveTo: () => { } }; if (!store.files[id]) throw new Error('no file'); return store.files[id]; },
      getStorageUsed: () => 2e9, getStorageLimit: () => 15e9
    },
    ScriptApp: { getProjectTriggers: () => triggers, newTrigger: fn => { const ch = { timeBased: () => ch, everyDays: () => ch, atHour: () => ch, onMonthDay: () => ch, create: () => { const uid = String(100000 + triggers.length); triggers.push({ getHandlerFunction: () => fn, getUniqueId: () => uid }); } }; return ch; } },
    MailApp: { getRemainingDailyQuota: () => 100, sendEmail: o => mails.push(o) },
    CalendarApp: (function () {
      const cals = {}; let n = 0;
      function mkCal(name) {
        const id = 'cal' + (++n) + '@group.calendar.google.com', evs = {};
        const add = (kind, title, s, e, o) => { const eid = 'ev' + (++n); evs[eid] = { kind, title, s, e, o, alive: true }; return { getId: () => eid }; };
        const c = { id, evs, getId: () => id, getName: () => name,
          createEvent: (t, s, e, o) => add('E', t, s, e, o), createAllDayEvent: (t, d, o) => add('A', t, d, d, o),
          createEventSeries: (t, s, e, r, o) => { if (!r || !r._rule) throw new Error('bad recurrence'); return add('S', t, s, e, o); },
          getEventById: id2 => evs[id2] && evs[id2].alive ? { deleteEvent: () => { evs[id2].alive = false; } } : null,
          getEventSeriesById: id2 => evs[id2] && evs[id2].alive ? { deleteEventSeries: () => { evs[id2].alive = false; } } : null };
        cals[id] = c; return c;
      }
      const rule = { onlyOnWeekdays: () => rule, onlyOnWeekday: () => rule, until: () => rule };
      return { _cals: cals, createCalendar: (nm) => mkCal(nm), getCalendarById: id => cals[id] || null,
        newRecurrence: () => ({ _rule: 1, addDailyRule: () => rule, addWeeklyRule: () => rule }),
        Weekday: { MONDAY: 1, TUESDAY: 2, WEDNESDAY: 3, THURSDAY: 4, FRIDAY: 5, SATURDAY: 6, SUNDAY: 7 } };
    })(),
    Calendar: { Acl: { insert: (r, id) => ({ id: 'acl' }) } },
    Utilities: {
      formatDate: fmt, getUuid: () => crypto.randomUUID(), sleep: () => { },
      newBlob: (d, m, n) => new Blob(d, m, n),
      computeHmacSha256Signature: (v, k) => toSigned(crypto.createHmac('sha256', toBuf(k)).update(toBuf(v)).digest()),
      base64Encode: b => toBuf(b).toString('base64'), base64EncodeWebSafe: b => toBuf(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_'),
      DigestAlgorithm: { SHA_256: 'sha256' }, computeDigest: (alg, v) => toSigned(crypto.createHash(alg).update(typeof v === 'string' ? Buffer.from(v, 'utf8') : toBuf(v)).digest()), base64Decode: s => toSigned(Buffer.from(s, 'base64'))
    }
  };
  ctx._ = { props, cache, logs, triggers, mails, store, setActive: e => { activeUser = e; } };
  vm.createContext(ctx);
  const dir = dirOverride || process.argv[2];
  if (extra) Object.assign(ctx, extra(ctx));
  fs.readdirSync(dir).filter(f => f.endsWith('.gs')).sort().forEach(f => vm.runInContext(fs.readFileSync(dir + '/' + f, 'utf8'), ctx, { filename: f }));
  return ctx;
}
module.exports = { makeCtx, store };
